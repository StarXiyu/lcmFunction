scoreboard objectives add tempban trigger
scoreboard objectives add tempban.uid dummy
scoreboard objectives add tempban.uid2 dummy
scoreboard objectives add tempban.time dummy