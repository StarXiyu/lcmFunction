scoreboard players tag @s[tag=op] add tempBan.temp.allow.ban
scoreboard players tag @s[tag=admin] add tempBan.temp.allow.ban

function tempBan:choose/1 if @s[tag=tempBan.temp.allow.ban]
tellraw @s[tag=!tempBan.temp.allow.ban] [{"text":"§f[§6临时封禁§f] §7您§c没有权限§7临时封禁他人"}]

scoreboard players tag @s remove tempBan.temp.allow.ban
scoreboard players set @s tempban 0
scoreboard players enable @s tempban