execute @s[tag=op] ~ ~ ~ tellraw @a [{"text":"[","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"临时封禁","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"] ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"对该玩家的封禁已被拦截","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
scoreboard players tag @s[tag=!op] add tempBan.tempBan

execute @s[tag=tempBan.tempBan] ~ ~ ~ summon minecraft:armor_stand ~ ~1 ~ {CustomName:"§e-> 临时封禁计时盔甲架 <-",Tags:["tempBan.armor"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b,Invisible:1,ShowArms:1,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
execute @s[tag=tempBan.tempBan] ~ ~ ~ scoreboard players operation @e[tag=tempBan.armor,r=2,c=1] tempban.uid = @s uid
execute @s[tag=tempBan.tempBan] ~ ~ ~ scoreboard players set @e[tag=tempBan.armor,r=2,c=1] tempban.time 1728000
execute @s[tag=tempBan.tempBan] ~ ~ ~ tp @e[tag=tempBan.armor,r=2,c=1] 0 4 0

scoreboard players tag @s remove tempBan.temp.be.ban.allow