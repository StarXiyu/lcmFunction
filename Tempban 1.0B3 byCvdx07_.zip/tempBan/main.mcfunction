execute @a[score_tempban_min=1] ~ ~ ~ function tempBan:mainBan
execute @a[tag=tempBan.tempBan] ~ ~ ~ function tempBan:ban/main

scoreboard players remove @e[tag=tempBan.armor] tempban.time 1

## byStarXiyu
## 未经允许,禁止发布
## 出品:LightCommand
## 群号:245684797