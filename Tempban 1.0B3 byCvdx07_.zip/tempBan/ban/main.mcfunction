execute @e[tag=tempBan.armor] ~ ~ ~ scoreboard players operation @s tempban.uid2 = @s tempban.uid
scoreboard players operation @e[tag=tempBan.armor] tempban.uid2 -= @s uid
scoreboard players tag @e[tag=tempBan.armor,score_tempban.uid2=0,score_tempban.uid2_min=0] add tempBan.armor.find

execute @e[tag=tempBan.armor.find,score_tempban.time=0] ~ ~ ~ function tempBan:ban/pardon
function tempBan:ban/ban if @s[tag=tempBan.tempBan]

scoreboard players tag @s remove tempBan.armor.find