scoreboard players tag @s remove tempBan.armor.find

execute @a ~ ~ ~ scoreboard players operation @s tempban.uid2 = @s uid
scoreboard players operation @s tempban.uid2 = @s tempban.uid
scoreboard players operation @a tempban.uid2 -= @s tempban.uid2
scoreboard players tag @a[tag=tempBan.tempBan,score_tempban.uid2=0,score_tempban.uid2_min=0] add tempBan.player.find

tellraw @a[tag=tempBan.player.find] [{"text":"§f[§6临时封禁§f] §a你已重获自由"}]
scoreboard players tag @a[tag=tempBan.player.find] remove tempBan.tempBan
scoreboard players tag @a remove tempBan.player.find

kill @s