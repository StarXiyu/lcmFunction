tellraw @s [{"text":"§f[§6临时封禁§f] §c未找到该玩家§7,请重新核对UID"}]

scoreboard players tag @s remove tempBan.temp.ban