tellraw @s [{"text":"§f[§6临时封禁§f] §7你不可以§c封禁自己"}]

scoreboard players tag @s remove tempBan.temp.ban
scoreboard players tag @s remove tempBan.temp.be.ban
scoreboard players tag @s remove tempBan.temp.ban.able