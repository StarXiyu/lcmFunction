execute @a ~ ~ ~ scoreboard players operation @s tempban.uid = @s uid
scoreboard players operation @a tempban.uid -= @s tempban
scoreboard players tag @s add tempBan.temp.ban

function tempBan:choose/2