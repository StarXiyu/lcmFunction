scoreboard players tag @a[score_tempban.uid=0,score_tempban.uid_min=0] add tempBan.temp.be.ban
execute @a[tag=tempBan.temp.be.ban] ~ ~ ~ scoreboard players tag @a[tag=tempBan.temp.ban] add tempBan.temp.ban.able

function tempBan:choose/3 if @s[tag=!tempBan.temp.ban.able]
function tempBan:choose/4 if @s[tag=tempBan.temp.be.ban]
function tempBan:banDeal if @s[tag=tempBan.temp.ban.able]