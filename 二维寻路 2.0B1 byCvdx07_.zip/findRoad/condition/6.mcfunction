
	## [6] 死活判断
		## true 继续
		## false 返回上一个 重新判断

execute @e[tag=findRoad.nowFinding] ~ ~ ~ scoreboard players set @s findRoad.air 0
execute @e[tag=findRoad.nowFinding] ~ ~ ~ scoreboard players set @s findRoad.airT 0

execute @e[tag=findRoad.nowFinding] ~ ~ ~ stats entity @s set AffectedBlocks @s findRoad.air

execute @e[tag=findRoad.nowFinding] ~ ~ ~ testforblock ~1 ~ ~ air *
execute @e[tag=findRoad.nowFinding] ~ ~ ~ scoreboard players add @s[score_findRoad.air_min=1] findRoad.airT 1
execute @e[tag=findRoad.nowFinding] ~ ~ ~ testforblock ~-1 ~ ~ air *
execute @e[tag=findRoad.nowFinding] ~ ~ ~ scoreboard players add @s[score_findRoad.air_min=1] findRoad.airT 1
execute @e[tag=findRoad.nowFinding] ~ ~ ~ testforblock ~ ~ ~1 air *
execute @e[tag=findRoad.nowFinding] ~ ~ ~ scoreboard players add @s[score_findRoad.air_min=1] findRoad.airT 1
execute @e[tag=findRoad.nowFinding] ~ ~ ~ testforblock ~ ~ ~-1 air *
execute @e[tag=findRoad.nowFinding] ~ ~ ~ scoreboard players add @s[score_findRoad.air_min=1] findRoad.airT 1

execute @e[tag=findRoad.nowFinding] ~ ~ ~ stats entity @s clear AffectedBlocks

function findRoad:condition/false/6 if @e[score_findRoad.airT_min=0,score_findRoad.airT=0]