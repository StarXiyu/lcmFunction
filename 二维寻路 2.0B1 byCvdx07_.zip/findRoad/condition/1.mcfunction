
## [1] 终点起点是否存在
	## true 继续
	## false 终止

function findRoad:condition/false/1 unless @e[tag=findRoad.armor.endPoint]
function findRoad:condition/false/1 unless @e[tag=findRoad.armor.startingPoint]