scoreboard players tag @e[tag=armor.findRoad] add findRoad.ending

tellraw @a "§f[§6LCM§f] §8>> §c二维寻路报错-§7起点死路"
tellraw @a "§f[§6LCM§f] §8>> §e二维寻路系统-§7寻路终止"