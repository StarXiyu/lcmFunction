scoreboard players tag @e[tag=armor.findRoad] add findRoad.ending

tellraw @a "§f[§6LCM§f] §8>> §c二维寻路报错-§7未找到当前寻路盔甲架与终点连通的路线"
tellraw @a "§f[§6LCM§f] §8>> §e二维寻路系统-§7寻路终止"