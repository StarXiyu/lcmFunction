
## 为正在寻路的添加已返回
execute @e[tag=findRoad.nowFinding] ~ ~ ~ scoreboard players tag @s add findRoad.overBack

## 寻找上一个
execute @e[tag=findRoad.temp.findRoad] ~ ~ ~ scoreboard players operation @s findRoad.num1 = @s findRoad.num
execute @e[tag=findRoad.nowFinding] ~ ~ ~ scoreboard players operation @s findRoad.num1 -= 1 findRoad.num
scoreboard players operation @e[tag=findRoad.nowFinding] findRoad.num1 -= @e[tag=findRoad.temp.findRoad] findRoad.num1

scoreboard players tag @e[tag=findRoad.nowFinding] remove findRoad.nowFinding
scoreboard players tag @e[tag=findRoad.temp.findRoad,score_findRoad.num1_min=0,score_findRoad.num1=0] add findRoad.nowFinding

## 如果没有未添加findRoad.overBack的寻路盔甲架,结束寻路
	execute @e[tag=findRoad.temp.findRoad] ~ ~ ~ execute @s[tag=!findRoad.overBack] ~ ~ ~ scoreboard players tag @s add findRoad.temp.noBack
	function findRoad:condition/false/2 unless @e[tag=findRoad.temp.noBack]
	
## 如果有,使终点挑选上一个最近的,并重新判断死活
	function findRoad:subject/10 if @e[tag=findRoad.temp.noBack]