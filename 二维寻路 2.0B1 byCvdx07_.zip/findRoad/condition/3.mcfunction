	
## [3] 是否终点
	## true 终止
	## false 继续

execute @e[tag=findRoad.nowFinding] ~ ~ ~ execute @e[tag=findRoad.armor.endPoint,r=1] ~ ~ ~ function findRoad:condition/true/3