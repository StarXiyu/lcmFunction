
## [5] 选择最近
	execute @e[tag=findRoad.armor.endPoint] ~ ~ ~ scoreboard players tag @e[c=1,tag=findRoad.temp.findRoad] add findRoad.temp.mostClose
	
	execute @e[tag=findRoad.temp.findRoad] ~ ~ ~ kill @s[tag=!findRoad.temp.mostClose]
		
	scoreboard players tag @e[tag=findRoad.nowFinding] remove findRoad.nowFinding
	scoreboard players tag @e[tag=findRoad.temp.mostClose] add findRoad.nowFinding
	
	execute @e[tag=findRoad.nowFinding] ~ ~ ~ setblock ~ ~ ~ wool