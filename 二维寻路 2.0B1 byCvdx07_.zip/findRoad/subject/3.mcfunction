
## [3] 是否终点
	## true 终止
	## false 继续
	function findRoad:condition/3
	
## 继续寻路
	function findRoad:subject/4 unless @e[tag=findRoad.ending]