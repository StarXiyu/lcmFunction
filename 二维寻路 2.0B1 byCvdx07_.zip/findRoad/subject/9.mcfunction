
## [5] 选择最近
	execute @e[tag=findRoad.armor.endPoint] ~ ~ ~ scoreboard players tag @e[c=1,tag=findRoad.temp.findRoad] add findRoad.temp.mostClose
	
	#execute @e[tag=findRoad.temp.findRoad] ~ ~ ~ kill @s[tag=!findRoad.temp.mostClose]
		
	scoreboard players tag @e[tag=findRoad.nowFinding] remove findRoad.nowFinding
	scoreboard players tag @e[tag=findRoad.temp.mostClose] add findRoad.nowFinding
	
	## 为现在寻路盔甲架编号
	scoreboard players add num findRoad.num 1
	scoreboard players operation @e[tag=findRoad.nowFinding] findRoad.num = num findRoad.num
	
	## [6] 死活判断
		## true 继续
		## false 返回上一个 重新判断
		
	function findRoad:condition/6
	
	execute @e[tag=findRoad.nowFinding] ~ ~ ~ setblock ~ ~ ~ wool