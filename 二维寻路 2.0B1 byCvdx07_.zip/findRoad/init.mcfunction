
summon minecraft:armor_stand ~ ~ ~ {CustomName:"§earmor.findRoad §7< §fLCM二维寻路总调用盔甲架",Tags:["armor.findRoad"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}

scoreboard objectives add findRoad.air dummy
scoreboard objectives add findRoad.airT dummy
#scoreboard objectives add findRoad.num dummy
#scoreboard objectives add findRoad.num1 dummy
#scoreboard objectives set 1 findRoad.num 1
#scoreboard objectives set num findRoad.num 0