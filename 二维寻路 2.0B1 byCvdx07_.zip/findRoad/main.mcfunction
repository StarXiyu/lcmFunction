## 总起方法

## [1] 终点起点是否存在
	## true 继续
	## false 终止
	function findRoad:condition/1
	
## 将起点盔甲架添加现在寻路标签
	scoreboard players tag @e[tag=findRoad.armor.startingPoint] add findRoad.nowFinding

## 继续寻路
	function findRoad:subject/main unless @e[tag=findRoad.ending]
	
## 还原
	kill @e[tag=findRoad.armor.startingPoint]
	kill @e[tag=findRoad.armor.endPoint]
	kill @e[tag=findRoad.temp.findRoad]
	scoreboard players tag @e[tag=armor.findRoad] remove findRoad.ending