##初始化，请勿变动
scoreboard objectives add lightac.警告 dummy
scoreboard objectives add lightac.fly.test dummy
scoreboard objectives add lightac.time.fly dummy
scoreboard objectives add lightac.time.kil dummy
scoreboard objectives add lightac.time.ore dummy
scoreboard objectives add lightac.mine stat.mineBlock.minecraft.stone
scoreboard objectives add lightac.killaura dummy
scoreboard objectives add lightac.use.木 stat.useItem.minecraft.wooden_sword
scoreboard objectives add lightac.use.石 stat.useItem.minecraft.stone_sword
scoreboard objectives add lightac.use.金 stat.useItem.minecraft.golden_sword
scoreboard objectives add lightac.use.铁 stat.useItem.minecraft.iron_sword
scoreboard objectives add lightac.use.钻 stat.useItem.minecraft.diamond_sword
scoreboard objectives add lightac.diamond stat.mineBlock.minecraft.diamond_ore
scoreboard objectives add lcm.name dummy
summon minecraft:armor_stand ~ ~1 ~ {CustomName:"§b§lLIGHTAC-§e§l计时盔甲架",Tags:["lightac.time"],CustomNameVisible:1b,NoAI:1b,Invulnerable:1b,PersistenceRequired:1b,Silent:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
tellraw @a [{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTAC","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n执行:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"初始化模块","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n作者:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"夕羽","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n㪊:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"245684797","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTAC","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
playsound block.note.pling block @p
execute @e[type=armor_stand,tag=lightac.time] ~ ~ ~ setblock ~ ~-1 ~ minecraft:repeating_command_block 0 replace {display:{Name:"§b§lLIGHTAC-§e§l运行模块"},Command:"function lightac:enable",auto:true}
gamerule commandBlockOutput false