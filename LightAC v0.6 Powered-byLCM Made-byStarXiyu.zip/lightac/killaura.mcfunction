execute @a[tag=!op] ~ ~ ~ scoreboard players operation @s lightac.killaura += @s lightac.use.木
scoreboard players set @a lightac.use.木 0
execute @a[tag=!op] ~ ~ ~ scoreboard players operation @s lightac.killaura += @s lightac.use.石
scoreboard players set @a lightac.use.石 0
execute @a[tag=!op] ~ ~ ~ scoreboard players operation @s lightac.killaura += @s lightac.use.金
scoreboard players set @a lightac.use.金 0
execute @a[tag=!op] ~ ~ ~ scoreboard players operation @s lightac.killaura += @s lightac.use.铁
scoreboard players set @a lightac.use.铁 0
execute @a[tag=!op] ~ ~ ~ scoreboard players operation @s lightac.killaura += @s lightac.use.钻
scoreboard players set @a lightac.use.钻 0
execute @a[score_lightac.killaura_min=80,tag=!op] ~ ~ ~ scoreboard players add @s lightac.警告 1
execute @a[score_lightac.killaura_min=80,tag=!op] ~ ~ ~ tellraw @a[tag=op] [{"text":"[","color":"white","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"反馈日志","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"white","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTAC","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 由于疑似","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"杀戮光环","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"已被警告一次(","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"lightac.警告","name":"@s"},"color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"/10)","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute @a[score_lightac.killaura_min=80,tag=!op] ~ ~ ~ scoreboard players set @s lightac.use.木 0
execute @a[score_lightac.killaura_min=80,tag=!op] ~ ~ ~ scoreboard players set @s lightac.use.石 0
execute @a[score_lightac.killaura_min=80,tag=!op] ~ ~ ~ scoreboard players set @s lightac.use.金 0
execute @a[score_lightac.killaura_min=80,tag=!op] ~ ~ ~ scoreboard players set @s lightac.use.铁 0
execute @a[score_lightac.killaura_min=80,tag=!op] ~ ~ ~ scoreboard players set @s lightac.use.钻 0
execute @a[score_lightac.killaura_min=80,tag=!op] ~ ~ ~ scoreboard players set @s lightac.killaura 0
execute @e[type=armor_stand,tag=lightac.time,score_lightac.time.kil_min=400] ~ ~ ~ scoreboard players set * lightac.use.木 0
execute @e[type=armor_stand,tag=lightac.time,score_lightac.time.kil_min=400] ~ ~ ~ scoreboard players set * lightac.use.石 0
execute @e[type=armor_stand,tag=lightac.time,score_lightac.time.kil_min=400] ~ ~ ~ scoreboard players set * lightac.use.金 0
execute @e[type=armor_stand,tag=lightac.time,score_lightac.time.kil_min=400] ~ ~ ~ scoreboard players set * lightac.use.铁 0
execute @e[type=armor_stand,tag=lightac.time,score_lightac.time.kil_min=400] ~ ~ ~ scoreboard players set * lightac.use.钻 0
execute @e[type=armor_stand,tag=lightac.time,score_lightac.time.kil_min=400] ~ ~ ~ scoreboard players set * lightac.killrua 0
execute @e[type=armor_stand,tag=lightac.time,score_lightac.time.kil_min=400] ~ ~ ~ tellraw @a[tag=op] [{"text":"[","color":"white","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"反馈日志","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"white","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTAC","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"杀戮光环","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"统计计分板已刷新","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute @e[type=armor_stand,tag=lightac.time,score_lightac.time.kil_min=400] ~ ~ ~ scoreboard players set @s lightac.time.kil 0
##反杀戮