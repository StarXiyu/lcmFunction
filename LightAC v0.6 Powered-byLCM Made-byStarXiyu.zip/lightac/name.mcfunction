scoreboard players add @a lcm.name 0
scoreboard players tag @a[tag=!lcm.name,score_lcm.name_min=0,score_lcm.name=0] add lcm.name
scoreboard players set @a[tag=lcm.name] lcm.name 1
kill @a[tag=!lcm.name]
execute @a[tag=!lcm.name] ~ ~ ~ tellraw @s [{"text":"LightAc","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"请勿重名其他玩家!","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]