
scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main
scoreboard players operation @s math.out -= @s vampirism

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 = @s math.attack3
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 *= 5 math
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 /= 100 math

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s health += @s temp.math1
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @p[tag=LightRPG.temp.pve.hurtPlayer] health -= @s temp.math1

execute @s[score_math.out=0] ~ ~ ~ tellraw @s [{"text":"您吸取了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@p[tag=LightRPG.temp.pve.hurtPlayer]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 的 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"temp.math1","name":"@s"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "}]