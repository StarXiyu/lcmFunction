
function LightRPG:system/trigger/pvp if @s[score_§8LightRPG=1,score_§8LightRPG_min=1]
function LightRPG:system/trigger/monsterAttack01 if @s[score_§8LightRPG=2,score_§8LightRPG_min=2]

scoreboard players reset @s §8LightRPG