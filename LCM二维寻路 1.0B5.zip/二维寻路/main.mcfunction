## 寻路顺序 X+ X- Z+ Z-

## 前置
scoreboard players add @s 二维寻路标识符 0
stats entity @s set AffectedBlocks @s 二维寻路标识符
execute @s[tag=LCM_二维寻路_起点] ~ ~ ~ setblock ~ ~ ~ wool
execute @s[tag=二维寻路_temp_现在寻路] ~ ~ ~ setblock ~ ~ ~ wool
scoreboard players tag @s remove 二维寻路_temp_现在寻路

## 检测是否是终点
stats entity @s set AffectedEntities @s 二维寻路计算标识符
testfor @e[r=1,tag=LCM_二维寻路_终点]
function 二维寻路:over if @s[score_二维寻路计算标识符_min=1]
stats entity @s clear AffectedEntities

## 如果不是就继续判断
function 二维寻路:main1 unless @e[tag=二维寻路_结束计算]

## 如果根本就不是一个活路那么直接结束递归
execute @s[tag=LCM_二维寻路_起点] ~ ~ ~ function 二维寻路:over unless @s[tag=二维寻路_可继续寻路]