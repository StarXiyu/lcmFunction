## [01] 检测 X+ 通路
testforblock ~1 ~ ~ air *
function 二维寻路:X_+ if @s[score_二维寻路标识符_min=1]

## [02] 检测 X- 通路
testforblock ~-1 ~ ~ air *
function 二维寻路:X_- if @s[score_二维寻路标识符_min=1]

## [03] 检测 Z+ 通路
testforblock ~ ~ ~1 air *
function 二维寻路:Z_+ if @s[score_二维寻路标识符_min=1]

## [04] 检测 Z- 通路
testforblock ~ ~ ~-1 air *
function 二维寻路:Z_- if @s[score_二维寻路标识符_min=1]