scoreboard players tag @s add 二维寻路_结束计算

stats entity @e[tag=二维寻路_计算盔甲架] clear AffectedEntities