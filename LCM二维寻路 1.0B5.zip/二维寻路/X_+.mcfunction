## 若寻路盔甲架X+为air激活本函数
## 将在X+生成一个标识用盔甲架,并将其 二维寻路标识符 分数设置为2 用于表示此路可通
## 生成后让该盔甲架运行主方法开始递归

summon minecraft:armor_stand ~1 ~ ~ {Tags:["二维寻路_temp_现在寻路","二维寻路_计算盔甲架"],ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
scoreboard players tag @s add 二维寻路_可继续寻路
execute @e[tag=二维寻路_temp_现在寻路] ~ ~ ~ function 二维寻路:main