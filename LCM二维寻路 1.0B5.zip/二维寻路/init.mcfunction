scoreboard objectives add 二维寻路标识符 dummy
scoreboard objectives add 二维寻路计算标识符 dummy