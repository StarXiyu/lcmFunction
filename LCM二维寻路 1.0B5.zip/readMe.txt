起点:scoreboard players tag @e[r=2,c=1,type=armor_stand] add LCM_二维寻路_起点
终点:scoreboard players tag @e[r=2,c=1,type=armor_stand] add LCM_二维寻路_终点

execute @e[tag=LCM_二维寻路_起点] ~ ~ ~ function 二维寻路:main unless @e[tag=二维寻路_结束计算]
kill @e[tag=二维寻路_计算盔甲架]


byCvdx07