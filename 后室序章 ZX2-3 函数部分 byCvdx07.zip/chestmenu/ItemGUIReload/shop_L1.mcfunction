
execute @e[tag=entity.armorStand.chestmenu.shop_L1] ~ ~ ~ function chestmenu:GUI/shop_L1