
## Shop_L1
function chestmenu:ItemGUIReload/shop_L1 if @e[r=5,tag=entity.armorStand.chestmenu.shop_L1]