
## Stats
    scoreboard players add @s chestmenu.item 0
    stats entity @s set AffectedItems @s chestmenu.item

## 空白物品
    clear @s minecraft:stained_glass_pane 8 -1 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
    execute @s[score_chestmenu.item_min=1] ~ ~ ~ execute @e[tag=entity.armorStand.chestmenu.shop_L1] ~ ~ ~ function chestmenu:GUI/shop_L1


## 展示物品
    clear @s minecraft:stone_sword 0 -1 {Unbreakable:1b,HideFlags:63,Tags:["chestmenu","武器展示"],dat:{critPob:{0:0b,1:1b,2:0b,3:1b,4:0b,5:0b,6:0b,7:0b,8:0b,9:0b,10:0b},phyAttack:{0:1b,1:0b,2:1b,3:0b,4:0b,5:0b,6:0b,7:0b,8:0b,9:0b,10:0b}},display:{Lore:["§6❏§f物理武器","","§b⚝ §f基础信息","§r§7  §3§l▮ §f品质 §8废铁","§r§7    §7由致密圆石与木柄粗糙拼合的长剑","§r§7    §7刃部布满凿刻的痕迹","","§a⚝ §f武器属性","§r§7  §2§l▮ §f物理攻击 §25","§r§7  §2§l▮ §f暴击概率 §210%","","§e⚝ §f武器技能","§r§7  §e§l▮ §f常规","§r§7    §7你每次攻击目标,就攻击了一次目标"],Name:"§7<- §8石剑 §7->"}}
    tellraw @s[score_chestmenu.item_min=1] "§6§l[!] §f请点击下方的纸进行兑换哦"
    execute @s[score_chestmenu.item_min=1] ~ ~ ~ execute @e[tag=entity.armorStand.chestmenu.shop_L1] ~ ~ ~ function chestmenu:GUI/shop_L1


    clear @s minecraft:stone_axe 0 -1 {Unbreakable:1b,HideFlags:63,Tags:["chestmenu","武器展示"],dat:{critPob:{0:0b,1:1b,2:0b,3:1b,4:0b,5:0b,6:0b,7:0b,8:0b,9:0b,10:0b},phyAttack:{0:1b,1:0b,2:0b,3:1b,4:0b,5:0b,6:0b,7:0b,8:0b,9:0b,10:0b}},display:{Lore:["§6❏§f物理武器","","§b⚝ §f基础信息","§r§7  §3§l▮ §f品质 §8废铁","§r§7    §7由厚重原石与粗木绑成的原始斧刃","§r§7    §7过于笨重让使用者行动变缓","","§a⚝ §f武器属性","§r§7  §2§l▮ §f物理攻击 §29","§r§7  §2§l▮ §f暴击概率 §210%","§r§7  §4§l▮ §f移动速度 §4-30%","","§e⚝ §f武器技能","§r§7  §e§l▮ §f常规","§r§7    §7你每次攻击目标,就攻击了一次目标"],Name:"§7<- §8石斧 §7->"},AttributeModifiers:[{UUIDMost:2819483789802226917L,UUIDLeast:-4695072633667069090L,Amount:-0.3d,Slot:"mainhand",AttributeName:"generic.movementSpeed",Operation:2,Name:"generic.movementSpeed"}]}
    tellraw @s[score_chestmenu.item_min=1] "§6§l[!] §f请点击下方的纸进行兑换哦"
    execute @s[score_chestmenu.item_min=1] ~ ~ ~ execute @e[tag=entity.armorStand.chestmenu.shop_L1] ~ ~ ~ function chestmenu:GUI/shop_L1


## 兑换剑
    clear @s minecraft:paper 0 -1 {display:{Name:"§e↑ §f点此兑换 §e↑",Lore:["§f-- 兑换需求 --","§8§o钝人头颅 §7*12","§e§o猎犬肢体 §7*20","§6§o笑魇头颅 §7*15","§8§o粗制木棍 §7*4","§b§o积分 §7*20"]},Tags:["chestmenu","shop_L1_兑换剑"]}
    function system:shop/buy/item/L1_Sword/main if @s[score_chestmenu.item_min=1]


## 兑换斧
    clear @s paper 0 -1 {display:{Name:"§e↑ §f点此兑换 §e↑",Lore:["§f-- 兑换需求 --","§8§o钝人头颅 §7*8","§e§o猎犬肢体 §7*20","§6§o笑魇头颅 §7*12","§8§o粗制木棍 §7*4","§b§o积分 §7*10"]},Tags:["chestmenu","shop_L1_兑换斧"]}
    function system:shop/buy/item/L1_Axe/main if @s[score_chestmenu.item_min=1]

## 结束stats
    stats entity @s clear AffectedItems