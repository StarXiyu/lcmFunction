execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster] minecraft:coal_block 1 0 {ench:[{lvl:1s,id:70s}],HideFlags:63,display:{Lore:["§6❏§f物品","§7钝人的头部骨骼结构"],Name:"§8钝人头颅"}}
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ tellraw @p[tag=LightRPG.temp.attackMonster] "§f[§6物品获得§f] §e钝人头颅"

scoreboard players add @p[tag=LightRPG.temp.attackMonster] xp 2