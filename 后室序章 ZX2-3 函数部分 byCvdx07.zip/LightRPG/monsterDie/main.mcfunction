
## 掉落概率运算
function LightRPG:monsterDie/drop

## 死亡音效
execute @p[tag=LightRPG.temp.attackMonster] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 1 1

## 死亡怪物类型判定
#//function LightRPG:monsterDie/腐恶僵尸 if @s[tag=腐恶僵尸]
function LightRPG:monsterDie/钝人 if @s[tag=钝人]
function LightRPG:monsterDie/笑魇 if @s[tag=笑魇]
function LightRPG:monsterDie/猎犬 if @s[tag=猎犬]
function LightRPG:monsterDie/无面灵 if @s[tag=无面灵]

## 经验
execute @p[tag=LightRPG.temp.attackMonster] ~ ~ ~ function system:xp/main

kill @s