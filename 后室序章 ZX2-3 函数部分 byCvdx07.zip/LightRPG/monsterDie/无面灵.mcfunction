
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster] concrete 1 0 {ench:[{lvl:1s,id:70s}],HideFlags:63,display:{Lore:["§6❏§f材料","§7无面灵皮囊"],Name:"§7<- §f无面灵头颅 §7->"}}
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ tellraw @p[tag=LightRPG.temp.attackMonster] "§f[§6物品获得§f] §e无面灵头颅"

scoreboard players add @p[tag=LightRPG.temp.attackMonster] xp 4