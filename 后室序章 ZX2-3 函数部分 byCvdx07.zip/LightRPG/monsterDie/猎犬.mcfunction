

execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster] bone 1 0 {display:{Lore:["§6❏§f材料","§7有着奇怪生理特征"],Name:"§7<- §e猎犬肢体 §7->"}}
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ tellraw @p[tag=LightRPG.temp.attackMonster] "§f[§6物品获得§f] §e猎犬肢体"

scoreboard players add @p[tag=LightRPG.temp.attackMonster] xp 1