
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster] pumpkin 1 0 {display:{Lore:["§6❏§f材料","§7标志性的反光的双眼"],Name:"§7<- §6笑魇头颅 §7->"}}
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ tellraw @p[tag=LightRPG.temp.attackMonster] "§f[§6物品获得§f] §e笑魇头颅"

scoreboard players add @p[tag=LightRPG.temp.attackMonster] xp 2