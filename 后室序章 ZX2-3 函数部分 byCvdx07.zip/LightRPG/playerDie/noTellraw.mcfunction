
kill @s

scoreboard players operation @s health = @s maxhealth
scoreboard players set @s spirit 100