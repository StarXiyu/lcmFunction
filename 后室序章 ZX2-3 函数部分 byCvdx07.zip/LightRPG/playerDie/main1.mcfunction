
kill @s

tellraw @a [{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 被 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@e[tag=LightRPG.temp.pve.attackPlayer,c=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 击败了","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

function LightRPG:playerDie/init unless @s[score_maxhealth_min=0]
scoreboard players operation @s health = @s maxhealth
scoreboard players set @s spirit 100