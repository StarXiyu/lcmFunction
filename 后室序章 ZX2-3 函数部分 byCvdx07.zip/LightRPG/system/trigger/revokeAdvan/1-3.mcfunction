advancement revoke @s only lightrpg:monsterattack01
advancement revoke @s only lightrpg:monsterattack02
advancement revoke @s only lightrpg:monsterattack03