
advancement revoke @s only lightrpg:monsterattack02

## 选择攻击的怪物
scoreboard players tag @e[r=10,tag=笑魇] add LightRPG.temp.pve.attackPlayer

scoreboard players tag @s add LightRPG.temp.pve.hurtPlayer

execute @p[tag=LightRPG.temp.pve.hurtPlayer,r=10] ~ ~ ~ function LightRPG:system/pve/main