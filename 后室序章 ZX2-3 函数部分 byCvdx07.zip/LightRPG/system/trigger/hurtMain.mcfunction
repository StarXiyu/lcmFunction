
function LightRPG:system/trigger/pvp if @s[score_§8LightRPG=1,score_§8LightRPG_min=1]
function LightRPG:system/trigger/monsterAttack01 if @s[score_§8LightRPG=2,score_§8LightRPG_min=2]
function LightRPG:system/trigger/monsterAttack02 if @s[score_§8LightRPG=3,score_§8LightRPG_min=3]
function LightRPG:system/trigger/monsterAttack03 if @s[score_§8LightRPG=4,score_§8LightRPG_min=4]
function LightRPG:system/trigger/monsterAttack04 if @s[score_§8LightRPG=5,score_§8LightRPG_min=5]

advancement revoke @s only lightrpg:pvp
function LightRPG:system/trigger/revokeAdvan/1-3 if @s[score_§8LightRPG=2,score_§8LightRPG_min=4]
function LightRPG:system/trigger/revokeAdvan/4 if @s[score_§8LightRPG=5,score_§8LightRPG_min=5]

scoreboard players reset @s §8LightRPG