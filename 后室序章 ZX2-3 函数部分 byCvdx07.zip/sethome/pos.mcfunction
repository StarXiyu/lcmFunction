function sethome:del
kill @e[tag=sethomex]
summon area_effect_cloud ~ ~ ~ {Tags:["sethomex"]}
scoreboard objectives add sethomex dummy
scoreboard players set @s sethomex -30000000
execute @e[tag=sethomex] ~-30000000.0 ~ ~ scoreboard players add @s sethomex 30000000
tp @e[tag=sethomex] ~-30000000.0 ~ ~


execute @e[tag=sethomex] ~-15000000.0 ~ ~ scoreboard players add @s sethomex 15000000
tp @e[tag=sethomex] ~-15000000.0 ~ ~


execute @e[tag=sethomex] ~-7500000.0 ~ ~ scoreboard players add @s sethomex 7500000
tp @e[tag=sethomex] ~-7500000.0 ~ ~

execute @e[tag=sethomex] ~-3750000.0 ~ ~ scoreboard players add @s sethomex 3750000
tp @e[tag=sethomex] ~-3750000.0 ~ ~

execute @e[tag=sethomex] ~-1875000.0 ~ ~ scoreboard players add @s sethomex 1875000
tp @e[tag=sethomex] ~-1875000.0 ~ ~

execute @e[tag=sethomex] ~-937500.0 ~ ~ scoreboard players add @s sethomex 937500
tp @e[tag=sethomex] ~-937500.0 ~ ~

execute @e[tag=sethomex] ~-468750.0 ~ ~ scoreboard players add @s sethomex 468750
tp @e[tag=sethomex] ~-468750.0 ~ ~

execute @e[tag=sethomex] ~-234375.0 ~ ~ scoreboard players add @s sethomex 234375
tp @e[tag=sethomex] ~-234375.0 ~ ~

execute @e[tag=sethomex] ~-117188.0 ~ ~ scoreboard players add @s sethomex 117188
tp @e[tag=sethomex] ~-117188.0 ~ ~

execute @e[tag=sethomex] ~-58594.0 ~ ~ scoreboard players add @s sethomex 58594
tp @e[tag=sethomex] ~-58594.0 ~ ~

execute @e[tag=sethomex] ~-29297.0 ~ ~ scoreboard players add @s sethomex 29297
tp @e[tag=sethomex] ~-29297.0 ~ ~

execute @e[tag=sethomex] ~-14649.0 ~ ~ scoreboard players add @s sethomex 14649
tp @e[tag=sethomex] ~-14649.0 ~ ~

execute @e[tag=sethomex] ~-7325.0 ~ ~ scoreboard players add @s sethomex 7325
tp @e[tag=sethomex] ~-7325.0 ~ ~

execute @e[tag=sethomex] ~-3663.0 ~ ~ scoreboard players add @s sethomex 3663
tp @e[tag=sethomex] ~-3663.0 ~ ~

execute @e[tag=sethomex] ~-1832.0 ~ ~ scoreboard players add @s sethomex 1832
tp @e[tag=sethomex] ~-1832.0 ~ ~

execute @e[tag=sethomex] ~-916.0 ~ ~ scoreboard players add @s sethomex 916
tp @e[tag=sethomex] ~-916.0 ~ ~

execute @e[tag=sethomex] ~-458.0 ~ ~ scoreboard players add @s sethomex 458
tp @e[tag=sethomex] ~-458.0 ~ ~

execute @e[tag=sethomex] ~-229.0 ~ ~ scoreboard players add @s sethomex 229
tp @e[tag=sethomex] ~-229.0 ~ ~

execute @e[tag=sethomex] ~-115.0 ~ ~ scoreboard players add @s sethomex 115
tp @e[tag=sethomex] ~-115.0 ~ ~

execute @e[tag=sethomex] ~-58.0 ~ ~ scoreboard players add @s sethomex 58
tp @e[tag=sethomex] ~-58.0 ~ ~

execute @e[tag=sethomex] ~-29.0 ~ ~ scoreboard players add @s sethomex 29
tp @e[tag=sethomex] ~-29.0 ~ ~

execute @e[tag=sethomex] ~-15.0 ~ ~ scoreboard players add @s sethomex 15
tp @e[tag=sethomex] ~-15.0 ~ ~

execute @e[tag=sethomex] ~-8.0 ~ ~ scoreboard players add @s sethomex 8
tp @e[tag=sethomex] ~-8.0 ~ ~

execute @e[tag=sethomex] ~-4.0 ~ ~ scoreboard players add @s sethomex 4
tp @e[tag=sethomex] ~-4.0 ~ ~

execute @e[tag=sethomex] ~-2.0 ~ ~ scoreboard players add @s sethomex 2
tp @e[tag=sethomex] ~-2.0 ~ ~

execute @e[tag=sethomex] ~-1.0 ~ ~ scoreboard players add @s sethomex 1
tp @e[tag=sethomex] ~-1.0 ~ ~


scoreboard players operation @s sethomex += @e[tag=sethomex] sethomex
kill @e[tag=sethomex]

kill @e[tag=sethomey]
summon area_effect_cloud ~ ~ ~ {Tags:["sethomey"]}
scoreboard objectives add sethomey dummy
scoreboard players add @e[tag=sethomey] sethomey 0
execute @e[tag=sethomey] ~ ~ ~ stats entity @e[tag=sethomey] set AffectedBlocks @s sethomey
execute @e[tag=sethomey] ~ ~ ~ testforblocks ~ 0 ~ ~ ~-1 ~ ~ 0 ~
scoreboard players operation @s sethomey = @e[tag=sethomey] sethomey
kill @e[tag=sethomey]

kill @e[tag=sethomez]
summon area_effect_cloud ~ ~ ~ {Tags:["sethomez"]}
scoreboard objectives add sethomez dummy
scoreboard players set @s sethomez -30000000

execute @e[tag=sethomez] ~ ~ ~-30000000.0 scoreboard players add @s sethomez 30000000
tp @e[tag=sethomez] ~ ~ ~-30000000.0

execute @e[tag=sethomez] ~ ~ ~-15000000.0 scoreboard players add @s sethomez 15000000
tp @e[tag=sethomez] ~ ~ ~-15000000.0

execute @e[tag=sethomez] ~ ~ ~-7500000.0 scoreboard players add @s sethomez 7500000
tp @e[tag=sethomez] ~ ~ ~-7500000.0

execute @e[tag=sethomez] ~ ~ ~-3750000.0 scoreboard players add @s sethomez 3750000
tp @e[tag=sethomez] ~ ~ ~-3750000.0

execute @e[tag=sethomez] ~ ~ ~-1875000.0 scoreboard players add @s sethomez 1875000
tp @e[tag=sethomez] ~ ~ ~-1875000.0

execute @e[tag=sethomez] ~ ~ ~-937500.0 scoreboard players add @s sethomez 937500
tp @e[tag=sethomez] ~ ~ ~-937500.0

execute @e[tag=sethomez] ~ ~ ~-468750.0 scoreboard players add @s sethomez 468750
tp @e[tag=sethomez] ~ ~ ~-468750.0

execute @e[tag=sethomez] ~ ~ ~-234375.0 scoreboard players add @s sethomez 234375
tp @e[tag=sethomez] ~ ~ ~-234375.0

execute @e[tag=sethomez] ~ ~ ~-117188.0 scoreboard players add @s sethomez 117188
tp @e[tag=sethomez] ~ ~ ~-117188.0

execute @e[tag=sethomez] ~ ~ ~-58594.0 scoreboard players add @s sethomez 58594
tp @e[tag=sethomez] ~ ~ ~-58594.0

execute @e[tag=sethomez] ~ ~ ~-29297.0 scoreboard players add @s sethomez 29297
tp @e[tag=sethomez] ~ ~ ~-29297.0

execute @e[tag=sethomez] ~ ~ ~-14649.0 scoreboard players add @s sethomez 14649
tp @e[tag=sethomez] ~ ~ ~-14649.0

execute @e[tag=sethomez] ~ ~ ~-7325.0 scoreboard players add @s sethomez 7325
tp @e[tag=sethomez] ~ ~ ~-7325.0

execute @e[tag=sethomez] ~ ~ ~-3663.0 scoreboard players add @s sethomez 3663
tp @e[tag=sethomez] ~ ~ ~-3663.0

execute @e[tag=sethomez] ~ ~ ~-1832.0 scoreboard players add @s sethomez 1832
tp @e[tag=sethomez] ~ ~ ~-1832.0

execute @e[tag=sethomez] ~ ~ ~-916.0 scoreboard players add @s sethomez 916
tp @e[tag=sethomez] ~ ~ ~-916.0

execute @e[tag=sethomez] ~ ~ ~-458.0 scoreboard players add @s sethomez 458
tp @e[tag=sethomez] ~ ~ ~-458.0

execute @e[tag=sethomez] ~ ~ ~-229.0 scoreboard players add @s sethomez 229
tp @e[tag=sethomez] ~ ~ ~-229.0

execute @e[tag=sethomez] ~ ~ ~-115.0 scoreboard players add @s sethomez 115
tp @e[tag=sethomez] ~ ~ ~-115.0

execute @e[tag=sethomez] ~ ~ ~-58.0 scoreboard players add @s sethomez 58
tp @e[tag=sethomez] ~ ~ ~-58.0

execute @e[tag=sethomez] ~ ~ ~-29.0 scoreboard players add @s sethomez 29
tp @e[tag=sethomez] ~ ~ ~-29.0

execute @e[tag=sethomez] ~ ~ ~-15.0 scoreboard players add @s sethomez 15
tp @e[tag=sethomez] ~ ~ ~-15.0

execute @e[tag=sethomez] ~ ~ ~-8.0 scoreboard players add @s sethomez 8
tp @e[tag=sethomez] ~ ~ ~-8.0

execute @e[tag=sethomez] ~ ~ ~-4.0 scoreboard players add @s sethomez 4
tp @e[tag=sethomez] ~ ~ ~-4.0

execute @e[tag=sethomez] ~ ~ ~-2.0 scoreboard players add @s sethomez 2
tp @e[tag=sethomez] ~ ~ ~-2.0

execute @e[tag=sethomez] ~ ~ ~-1.0 scoreboard players add @s sethomez 1
tp @e[tag=sethomez] ~ ~ ~-1.0

scoreboard players operation @s sethomez += @e[tag=sethomez] sethomez
kill @e[tag=sethomez]

scoreboard players tag @s add hellworld {Dimension:-1}
scoreboard players tag @s add mainworld {Dimension:0}
scoreboard players tag @s add endworld {Dimension:1}

scoreboard players tag @s add havehome

tellraw @s [{"text":"[!]","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 坐标记录成功","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" [","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"sethomex","name":"@s"},"color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":",","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"sethomey","name":"@s"},"color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":",","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"sethomez","name":"@s"},"color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]