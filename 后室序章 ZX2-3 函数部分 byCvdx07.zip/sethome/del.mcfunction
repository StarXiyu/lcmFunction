scoreboard players reset @s sethomex
scoreboard players reset @s sethomey
scoreboard players reset @s sethomez
scoreboard players tag @s remove havehome
scoreboard players tag @s remove endworld
scoreboard players tag @s remove hellworld
scoreboard players tag @s remove mainworld