scoreboard objectives add home dummy
scoreboard players set 10 home 10
scoreboard players set 100 home 100
scoreboard players set 1000 home 1000
scoreboard players set 10000 home 10000
scoreboard players set 100000 home 100000
scoreboard players set 1000000 home 1000000
scoreboard players set 10000000 home 10000000
summon area_effect_cloud ~ ~ ~ {Tags:["home"]}
tp @e[tag=home] @s
tp @e[tag=home] 0 0 0

scoreboard players operation @s home = @s sethomex
scoreboard players operation @s home /= 10000000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~10000000 ~ ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~20000000 ~ ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~30000000 ~ ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~40000000 ~ ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~50000000 ~ ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~60000000 ~ ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~70000000 ~ ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~80000000 ~ ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~90000000 ~ ~
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~-10000000 ~ ~
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~-20000000 ~ ~
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~-30000000 ~ ~
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~-40000000 ~ ~
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~-50000000 ~ ~
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~-60000000 ~ ~
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~-70000000 ~ ~
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~-80000000 ~ ~
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~-90000000 ~ ~

scoreboard players operation @s home = @s sethomex
scoreboard players operation @s home /= 1000000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~1000000 ~ ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~2000000 ~ ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~3000000 ~ ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~4000000 ~ ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~5000000 ~ ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~6000000 ~ ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~7000000 ~ ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~8000000 ~ ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~9000000 ~ ~
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~-1000000 ~ ~
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~-2000000 ~ ~
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~-3000000 ~ ~
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~-4000000 ~ ~
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~-5000000 ~ ~
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~-6000000 ~ ~
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~-7000000 ~ ~
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~-8000000 ~ ~
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~-9000000 ~ ~

scoreboard players operation @s home = @s sethomex
scoreboard players operation @s home /= 100000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~100000 ~ ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~200000 ~ ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~300000 ~ ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~400000 ~ ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~500000 ~ ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~600000 ~ ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~700000 ~ ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~800000 ~ ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~900000 ~ ~
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~-100000 ~ ~
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~-200000 ~ ~
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~-300000 ~ ~
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~-400000 ~ ~
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~-500000 ~ ~
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~-600000 ~ ~
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~-700000 ~ ~
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~-800000 ~ ~
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~-900000 ~ ~

scoreboard players operation @s home = @s sethomex
scoreboard players operation @s home /= 10000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~10000 ~ ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~20000 ~ ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~30000 ~ ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~40000 ~ ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~50000 ~ ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~60000 ~ ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~70000 ~ ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~80000 ~ ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~90000 ~ ~
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~-10000 ~ ~
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~-20000 ~ ~
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~-30000 ~ ~
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~-40000 ~ ~
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~-50000 ~ ~
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~-60000 ~ ~
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~-70000 ~ ~
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~-80000 ~ ~
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~-90000 ~ ~

scoreboard players operation @s home = @s sethomex
scoreboard players operation @s home /= 1000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~1000 ~ ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~2000 ~ ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~3000 ~ ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~4000 ~ ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~5000 ~ ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~6000 ~ ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~7000 ~ ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~8000 ~ ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~9000 ~ ~
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~-1000 ~ ~
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~-2000 ~ ~
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~-3000 ~ ~
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~-4000 ~ ~
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~-5000 ~ ~
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~-6000 ~ ~
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~-7000 ~ ~
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~-8000 ~ ~
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~-9000 ~ ~

scoreboard players operation @s home = @s sethomex
scoreboard players operation @s home /= 100 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~100 ~ ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~200 ~ ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~300 ~ ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~400 ~ ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~500 ~ ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~600 ~ ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~700 ~ ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~800 ~ ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~900 ~ ~
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~-100 ~ ~
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~-200 ~ ~
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~-300 ~ ~
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~-400 ~ ~
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~-500 ~ ~
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~-600 ~ ~
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~-700 ~ ~
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~-800 ~ ~
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~-900 ~ ~

scoreboard players operation @s home = @s sethomex
scoreboard players operation @s home /= 10 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~10 ~ ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~20 ~ ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~30 ~ ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~40 ~ ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~50 ~ ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~60 ~ ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~70 ~ ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~80 ~ ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~90 ~ ~
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~-10 ~ ~
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~-20 ~ ~
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~-30 ~ ~
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~-40 ~ ~
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~-50 ~ ~
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~-60 ~ ~
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~-70 ~ ~
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~-80 ~ ~
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~-90 ~ ~

scoreboard players operation @s home = @s sethomex
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~1 ~ ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~2 ~ ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~3 ~ ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~4 ~ ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~5 ~ ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~6 ~ ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~7 ~ ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~8 ~ ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~9 ~ ~
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~-1 ~ ~
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~-2 ~ ~
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~-3 ~ ~
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~-4 ~ ~
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~-5 ~ ~
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~-6 ~ ~
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~-7 ~ ~
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~-8 ~ ~
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~-9 ~ ~

scoreboard players operation @s home = @s sethomey
scoreboard players operation @s home /= 1000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~1000 ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~2000 ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~3000 ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~4000 ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~5000 ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~6000 ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~7000 ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~8000 ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~9000 ~

scoreboard players operation @s home = @s sethomey
scoreboard players operation @s home /= 100 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~100 ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~200 ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~300 ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~400 ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~500 ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~600 ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~700 ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~800 ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~900 ~

scoreboard players operation @s home = @s sethomey
scoreboard players operation @s home /= 10 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~10 ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~20 ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~30 ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~40 ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~50 ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~60 ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~70 ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~80 ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~90 ~

scoreboard players operation @s home = @s sethomey
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~1 ~
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~2 ~
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~3 ~
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~4 ~
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~5 ~
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~6 ~
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~7 ~
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~8 ~
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~9 ~

scoreboard players operation @s home = @s sethomez
scoreboard players operation @s home /= 10000000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~ ~10000000
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~ ~20000000
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~ ~30000000
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~ ~40000000
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~ ~50000000
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~ ~60000000
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~ ~70000000
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~ ~80000000
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~ ~90000000
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~ ~ ~-10000000
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~ ~ ~-20000000
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~ ~ ~-30000000
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~ ~ ~-40000000
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~ ~ ~-50000000
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~ ~ ~-60000000
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~ ~ ~-70000000
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~ ~ ~-80000000
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~ ~ ~-90000000

scoreboard players operation @s home = @s sethomez
scoreboard players operation @s home /= 1000000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~ ~1000000
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~ ~2000000
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~ ~3000000
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~ ~4000000
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~ ~5000000
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~ ~6000000
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~ ~7000000
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~ ~8000000
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~ ~9000000
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~ ~ ~-1000000
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~ ~ ~-2000000
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~ ~ ~-3000000
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~ ~ ~-4000000
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~ ~ ~-5000000
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~ ~ ~-6000000
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~ ~ ~-7000000
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~ ~ ~-8000000
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~ ~ ~-9000000

scoreboard players operation @s home = @s sethomez
scoreboard players operation @s home /= 100000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~ ~100000
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~ ~200000
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~ ~300000
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~ ~400000
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~ ~500000
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~ ~600000
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~ ~700000
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~ ~800000
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~ ~900000
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~ ~ ~-100000
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~ ~ ~-200000
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~ ~ ~-300000
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~ ~ ~-400000
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~ ~ ~-500000
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~ ~ ~-600000
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~ ~ ~-700000
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~ ~ ~-800000
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~ ~ ~-900000

scoreboard players operation @s home = @s sethomez
scoreboard players operation @s home /= 10000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~ ~10000
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~ ~20000
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~ ~30000
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~ ~40000
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~ ~50000
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~ ~60000
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~ ~70000
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~ ~80000
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~ ~90000
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~ ~ ~-10000
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~ ~ ~-20000
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~ ~ ~-30000
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~ ~ ~-40000
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~ ~ ~-50000
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~ ~ ~-60000
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~ ~ ~-70000
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~ ~ ~-80000
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~ ~ ~-90000

scoreboard players operation @s home = @s sethomez
scoreboard players operation @s home /= 1000 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~ ~1000
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~ ~2000
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~ ~3000
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~ ~4000
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~ ~5000
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~ ~6000
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~ ~7000
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~ ~8000
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~ ~9000
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~ ~ ~-1000
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~ ~ ~-2000
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~ ~ ~-3000
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~ ~ ~-4000
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~ ~ ~-5000
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~ ~ ~-6000
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~ ~ ~-7000
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~ ~ ~-8000
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~ ~ ~-9000

scoreboard players operation @s home = @s sethomez
scoreboard players operation @s home /= 100 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~ ~100
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~ ~200
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~ ~300
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~ ~400
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~ ~500
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~ ~600
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~ ~700
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~ ~800
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~ ~900
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~ ~ ~-100
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~ ~ ~-200
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~ ~ ~-300
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~ ~ ~-400
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~ ~ ~-500
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~ ~ ~-600
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~ ~ ~-700
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~ ~ ~-800
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~ ~ ~-900

scoreboard players operation @s home = @s sethomez
scoreboard players operation @s home /= 10 home
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~ ~10
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~ ~20
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~ ~30
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~ ~40
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~ ~50
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~ ~60
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~ ~70
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~ ~80
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~ ~90
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~ ~ ~-10
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~ ~ ~-20
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~ ~ ~-30
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~ ~ ~-40
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~ ~ ~-50
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~ ~ ~-60
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~ ~ ~-70
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~ ~ ~-80
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~ ~ ~-90
scoreboard players operation @s home = @s sethomez
scoreboard players operation @s home %= 10 home
execute @s[score_home=1,score_home_min=1] ~ ~ ~ tp @e[tag=home] ~ ~ ~1
execute @s[score_home=2,score_home_min=2] ~ ~ ~ tp @e[tag=home] ~ ~ ~2
execute @s[score_home=3,score_home_min=3] ~ ~ ~ tp @e[tag=home] ~ ~ ~3
execute @s[score_home=4,score_home_min=4] ~ ~ ~ tp @e[tag=home] ~ ~ ~4
execute @s[score_home=5,score_home_min=5] ~ ~ ~ tp @e[tag=home] ~ ~ ~5
execute @s[score_home=6,score_home_min=6] ~ ~ ~ tp @e[tag=home] ~ ~ ~6
execute @s[score_home=7,score_home_min=7] ~ ~ ~ tp @e[tag=home] ~ ~ ~7
execute @s[score_home=8,score_home_min=8] ~ ~ ~ tp @e[tag=home] ~ ~ ~8
execute @s[score_home=9,score_home_min=9] ~ ~ ~ tp @e[tag=home] ~ ~ ~9
execute @s[score_home=-1,score_home_min=-1] ~ ~ ~ tp @e[tag=home] ~ ~ ~-1
execute @s[score_home=-2,score_home_min=-2] ~ ~ ~ tp @e[tag=home] ~ ~ ~-2
execute @s[score_home=-3,score_home_min=-3] ~ ~ ~ tp @e[tag=home] ~ ~ ~-3
execute @s[score_home=-4,score_home_min=-4] ~ ~ ~ tp @e[tag=home] ~ ~ ~-4
execute @s[score_home=-5,score_home_min=-5] ~ ~ ~ tp @e[tag=home] ~ ~ ~-5
execute @s[score_home=-6,score_home_min=-6] ~ ~ ~ tp @e[tag=home] ~ ~ ~-6
execute @s[score_home=-7,score_home_min=-7] ~ ~ ~ tp @e[tag=home] ~ ~ ~-7
execute @s[score_home=-8,score_home_min=-8] ~ ~ ~ tp @e[tag=home] ~ ~ ~-8
execute @s[score_home=-9,score_home_min=-9] ~ ~ ~ tp @e[tag=home] ~ ~ ~-9

execute @s[tag=!havehome] 0 0 0 kill @e[tag=home]
tellraw @s[tag=!havehome] "§4§l[!] §f您还没有设置坐标!"
scoreboard players tag @s[tag=hellworld] add wrongworld {Dimension:0}
scoreboard players tag @s[tag=hellworld] add wrongworld {Dimension:1}
scoreboard players tag @s[tag=mainworld] add wrongworld {Dimension:-1}
scoreboard players tag @s[tag=mainworld] add wrongworld {Dimension:1}
scoreboard players tag @s[tag=endworld] add wrongworld {Dimension:-1}
scoreboard players tag @s[tag=endworld] add wrongworld {Dimension:0}
execute @s[tag=wrongworld] 0 0 0 kill @e[tag=home]
tellraw @s[tag=wrongworld] [{"text":"§4§l[!] §f设置的坐标不处于同一个世界!"}]

tp @s @e[tag=home]
kill @e[tag=home]
tellraw @s[tag=havehome] [{"text":"[!]","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 坐标返回成功","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" [","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"sethomex","name":"@s"},"color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":",","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"sethomey","name":"@s"},"color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":",","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"sethomez","name":"@s"},"color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]
scoreboard objectives remove home
scoreboard players tag @s remove wrongworld