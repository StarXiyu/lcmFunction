
scoreboard objectives add uid dummy 玩家编号
scoreboard objectives add time.xrGuide1 dummy 新人引导1时间

scoreboard objectives add n.maxhealth dummy
scoreboard objectives add n.phyAttack dummy
scoreboard objectives add n.spellAttack dummy
scoreboard objectives add n.critPob dummy
scoreboard objectives add n.critAttack dummy 
scoreboard objectives add n.physicsResist dummy
scoreboard objectives add n.spellResist dummy
scoreboard objectives add n.critResist dummy
scoreboard objectives add n.physicsPene dummy
scoreboard objectives add n.spellPene dummy
scoreboard objectives add n.vampirism dummy
scoreboard objectives add n.dodge dummy
scoreboard objectives add n.seize dummy
scoreboard objectives add n.hit dummy
scoreboard objectives add n.vampirism.rate dummy

scoreboard objectives add a.maxhealth dummy
scoreboard objectives add a.phyAttack dummy
scoreboard objectives add a.spellAttack dummy
scoreboard objectives add a.critPob dummy
scoreboard objectives add a.critAttack dummy 
scoreboard objectives add a.physicsResist dummy
scoreboard objectives add a.spellResist dummy
scoreboard objectives add a.critResist dummy
scoreboard objectives add a.physicsPene dummy
scoreboard objectives add a.spellPene dummy
scoreboard objectives add a.vampirism dummy
scoreboard objectives add a.dodge dummy
scoreboard objectives add a.seize dummy
scoreboard objectives add a.hit dummy
scoreboard objectives add a.vampirism.rate dummy

scoreboard objectives add s.maxhealth dummy
scoreboard objectives add s.phyAttack dummy
scoreboard objectives add s.spellAttack dummy
scoreboard objectives add s.critPob dummy
scoreboard objectives add s.critAttack dummy 
scoreboard objectives add s.physicsResist dummy
scoreboard objectives add s.spellResist dummy
scoreboard objectives add s.critResist dummy
scoreboard objectives add s.physicsPene dummy
scoreboard objectives add s.spellPene dummy
scoreboard objectives add s.vampirism dummy
scoreboard objectives add s.dodge dummy
scoreboard objectives add s.seize dummy
scoreboard objectives add s.hit dummy
scoreboard objectives add s.vampirism.rate dummy

scoreboard objectives add math dummy
scoreboard objectives add temp1 dummy

scoreboard objectives add d.maxhealth dummy
scoreboard objectives add d.phyAttack dummy
scoreboard objectives add d.spellAttack dummy
scoreboard objectives add d.critPob dummy
scoreboard objectives add d.critAttack dummy 
scoreboard objectives add d.physicsResist dummy
scoreboard objectives add d.spellResist dummy
scoreboard objectives add d.critResist dummy
scoreboard objectives add d.physicsPene dummy
scoreboard objectives add d.spellPene dummy
scoreboard objectives add d.vampirism dummy
scoreboard objectives add d.dodge dummy
scoreboard objectives add d.seize dummy
scoreboard objectives add d.hit dummy
scoreboard objectives add d.vampirism.rate dummy

scoreboard objectives add regeneration dummy
scoreboard objectives add d.regeneration dummy

scoreboard objectives add loadAttribute trigger

scoreboard objectives add uid dummy

scoreboard objectives add time.xrGuide2 dummy

scoreboard objectives add spirit dummy 精神力

scoreboard objectives add level dummy
scoreboard objectives add xp dummy
scoreboard objectives add xp.need dummy
scoreboard objectives add jf dummy

scoreboard objectives add xp.math1 dummy
scoreboard objectives add xp.math2 dummy

scoreboard objectives add killer dummy
scoreboard objectives add kill.count dummy

scoreboard objectives add menuSneak stat.sneakTime
scoreboard objectives add sneak2 dummy
scoreboard objectives add sneakCount dummy
scoreboard objectives add sneakTime dummy

scoreboard objectives add menu trigger

scoreboard objectives add jf.get dummy

scoreboard objectives add 隐秘层级进入次数 dummy

scoreboard objectives add effect.speed dummy

scoreboard objectives add systemTime dummy

scoreboard objectives add chestTime dummy
scoreboard objectives add chestTime.math dummy

scoreboard objectives add tool.math1 dummy
scoreboard objectives add tool.math2 dummy

scoreboard objectives add drink stat.useItem.minecraft.potion
scoreboard objectives add drinkType dummy

scoreboard objectives add chest stat.chestOpened

scoreboard objectives add talk stat.talkedToVillager

scoreboard objectives add time.spirit dummy

scoreboard objectives add chestmenu.item dummy
scoreboard objectives add shop.item dummy

scoreboard objectives add shop.buyCond dummy 购买条件满足计数

scoreboard objectives add GPS dummy
scoreboard objectives add GPS.time dummy

scoreboard objectives add ban trigger
scoreboard objectives add jinggao trigger
scoreboard objectives add banuid dummy
scoreboard objectives add jinggaouid dummy
scoreboard objectives add 警告 dummy
scoreboard objectives add keepBan dummy
scoreboard objectives add pardon dummy

scoreboard objectives add hpBar.math dummy

scoreboard objectives add time.RAttribute dummy