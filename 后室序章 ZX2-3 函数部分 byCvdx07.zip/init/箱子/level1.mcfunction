
setblock ~ ~-1 ~ gold_block
summon minecraft:armor_stand ~ ~ ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:0,Tags:["entity.armorStand.chest.level1","entity.armorStand.chest"]}