
scoreboard teams add 引导区
scoreboard teams add 玩家
scoreboard teams add op

scoreboard teams add UEC
scoreboard teams add MEG
scoreboard teams add BNTG
scoreboard teams add 万神殿