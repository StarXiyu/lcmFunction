
summon minecraft:armor_stand ~ ~1 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§7§lB.N.T.G"}
summon minecraft:armor_stand ~ ~0.5 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§f主基地"}