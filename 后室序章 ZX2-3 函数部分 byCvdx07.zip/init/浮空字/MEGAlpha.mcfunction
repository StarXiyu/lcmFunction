

summon minecraft:armor_stand ~ ~1 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§e§lM.E.G"}
summon minecraft:armor_stand ~ ~0.5 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§fAlpha 基地"}