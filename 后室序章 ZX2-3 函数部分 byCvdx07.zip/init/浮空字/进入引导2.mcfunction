
summon minecraft:armor_stand ~ ~0.5 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§e§l↓ §f更新属性后尝试 §e§l↓"}