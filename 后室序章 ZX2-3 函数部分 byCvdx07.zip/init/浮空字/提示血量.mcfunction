
summon minecraft:armor_stand ~ ~1 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§4§l[!] §f请关注物品栏上方数字显示血量，而非原版血量条"}