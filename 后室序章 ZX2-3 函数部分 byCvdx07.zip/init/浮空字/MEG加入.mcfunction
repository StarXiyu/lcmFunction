
summon minecraft:armor_stand ~ ~1 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§f右键加入 §e§lM.E.G §f阵营"}
summon minecraft:armor_stand ~ ~0.5 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§f选中后§4§l不可修改,§f阵营不同§4§l效果不同"}