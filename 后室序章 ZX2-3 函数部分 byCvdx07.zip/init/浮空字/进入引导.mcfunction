
summon minecraft:armor_stand ~ ~1 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§e§l↑ §f向前走至尽头触发剧情 §e§l↑"}