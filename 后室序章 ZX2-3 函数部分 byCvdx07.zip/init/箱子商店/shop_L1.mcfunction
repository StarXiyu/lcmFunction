
setblock ~ ~ ~ chest
summon minecraft:armor_stand ~ ~1 ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§7-§f『§e兑换商店§f』§7-",Tags:["entity.armorStand.chestmenu","entity.armorStand.chestmenu.shop_L1"]}