
scoreboard players tag @s add system.itemCheck

scoreboard players tag @s add temp.item.dropTool {Item:{tag:{Tags:["item.dropTool"]}}}
function system:dropTool/main if @s[tag=temp.item.dropTool]

scoreboard players tag @s add temp.itemKilled {Item:{tag:{Tags:["chestmenu"]}}}
scoreboard players tag @s add temp.chestmenu {Item:{tag:{Tags:["chestmenu"]}}}
execute @s[tag=temp.chestmenu] ~ ~ ~ execute @p[r=5] ~ ~ ~ function chestmenu:ItemGUIReload/main if @e[r=5,tag=entity.armorStand.chestmenu,type=armor_stand]

kill @s[tag=temp.itemKilled]