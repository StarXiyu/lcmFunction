
## 已有阵营
tellraw @s[tag=player.已加入阵营] "§4§l[!] §f不可重复加入阵营"

## 加入
function system:MEG/join/join if @s[tag=!player.已加入阵营]