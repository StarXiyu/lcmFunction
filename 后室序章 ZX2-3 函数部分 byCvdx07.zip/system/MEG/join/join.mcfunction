
scoreboard players tag @s add MEG
scoreboard teams join MEG @s
scoreboard players tag @s add player.已加入阵营

tellraw @s "§a§l[!] §f你已加入阵营 §e§lM.E.G"