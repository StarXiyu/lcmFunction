tp @s 535 7 294
spawnpoint @s 535 7 294

function system:uid

scoreboard players set @s health 20

scoreboard players enable @s loadAttribute

execute @a ~ ~ ~ playsound minecraft:entity.firework.twinkle ambient @s

scoreboard players tag @s add joinGame

scoreboard teams join 玩家 @s

scoreboard players set @s time.xrGuide2 0

scoreboard players set @s jf 100
scoreboard players set @s spirit 100
scoreboard players set @s level 0
scoreboard players set @s xp 0
scoreboard players set @s xp.need 50
