
scoreboard players add @s d.phyAttack 0

## 错误
function system:guide/joinGameFall if @s[score_d.phyAttack=0]

## 正确
function system:guide/joinGame if @s[score_d.phyAttack_min=3]