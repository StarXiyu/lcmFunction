
tp @s 568 5 277
spawnpoint @s 568 5 277

effect @s blindness 4 255 true
effect @s slowness 4 255 true

title @s title "§e§l后室:序章"
title @s subtitle "§7-- ZIXIAO SERVER 2-3 --"

tellraw @s "\n\n\n§6Powered by Cvdx07_\n\n\n"