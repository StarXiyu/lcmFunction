
tellraw @s "§7[神秘人] §f本服务器所有的§e装备/武器§f都需要打开菜单点击§b属性更新§f之后才可以使用"
tellraw @s "§7[神秘人] §f正常情况下,你需要§e快速双蹲§f打开菜单,不过现在,你只需要§b拿上武器点击属性更新§f就可以了"
tellraw @s "§7[神秘人] §f更新完毕后,点击§e前方按钮§f正式开始游戏,现在快来试试吧"
tellraw @s [{"text":"\n--> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"[属性更新]","color":"light_purple","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger loadAttribute set 1"}},{"text":" <--\n","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

clear @s wooden_sword -1 -1
give @s wooden_sword 1 0 {Unbreakable:1b,HideFlags:63,dat:{critPob:{0:0b,1:1b,2:0b,3:1b,4:0b,5:0b,6:0b,7:0b,8:0b,9:0b,10:0b},phyAttack:{0:1b,1:1b,2:0b,3:0b,4:0b,5:0b}},display:{Lore:["§6❏§f物理武器","","§b⚝ §f基础信息","§r§7  §3§l▮ §f品质 §8废铁","§r§7    §7请拿着它,这是你的起点","","§a⚝ §f武器属性","§r§7  §2§l▮ §f物理攻击 §23","§r§7  §2§l▮ §f暴击概率 §210%","","§e⚝ §f武器技能","§r§7  §e§l▮ §f常规","§r§7    §7你每次攻击目标,就攻击了一次目标"],Name:"§7<- §a起点 §7->"}}