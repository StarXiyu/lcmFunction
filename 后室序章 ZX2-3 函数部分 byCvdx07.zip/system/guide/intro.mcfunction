
tp @a[tag=!xrGuide.intro] 664 4 293
spawnpoint @a[tag=!xrGuide.intro] 664 4 293

tellraw @a[tag=!xrGuide.intro] " "
tellraw @a[tag=!xrGuide.intro] "  §7---- Part0 序章 ----  "
tellraw @a[tag=!xrGuide.intro] " §f某一天,你正在高速路上开着车,你的身前突然出现一个漩涡"
tellraw @a[tag=!xrGuide.intro] " §f你好奇的走了进去"
tellraw @a[tag=!xrGuide.intro] " "

title @a[tag=!xrGuide.intro] title "§7§l-- 序章 --"
title @a[tag=!xrGuide.intro] subtitle "§f§oZIXIAO SERVER 2-3"

execute @a[tag=!xrGuide.intro] ~ ~ ~ playsound entity.elder_guardian.death ambient @s ~ ~ ~ 100 
effect @a[tag=!xrGuide.intro] blindness 5 1

scoreboard teams join 引导区 @a[tag=!xrGuide.intro]

scoreboard players tag @a[tag=!xrGuide.intro] add xrGuide.intro