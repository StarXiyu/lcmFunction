
tellraw @a[score_GPS.time_min=300] "§6§l[!] §f导航开启时间过长,已为你§c强制关闭"
scoreboard players set @a[score_GPS.time_min=300] GPS 0
scoreboard players set @a[score_GPS.time_min=300] GPS.time 0