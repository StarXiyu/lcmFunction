
tellraw @s "§d§l[!] §f请跟随红色粒子步行前往"
scoreboard players set @s GPS 1