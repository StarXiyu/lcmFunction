
execute @a[score_ban_min=1] ~ ~ ~ function system:trban