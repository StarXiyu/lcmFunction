

scoreboard players tag @s add temp.item.drinkTool {SelectedItem:{tag:{Tags:["item.drinkTool"]}}}
function system:takeTool/drinkTool/main if @s[tag=temp.item.drinkTool]

scoreboard players tag @s remove item.takeTool