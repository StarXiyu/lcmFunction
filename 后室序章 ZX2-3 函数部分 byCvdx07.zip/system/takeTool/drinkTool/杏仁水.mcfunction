
scoreboard players operation @s tool.math1 = @s maxhealth
## maxhealth * 25% = maxhealth * 25 / 100
scoreboard players set 25 math 25

scoreboard players operation @s tool.math1 *= 25 math
scoreboard players operation @s tool.math1 /= 100 math
scoreboard players operation @s health += @s tool.math1

tellraw @s [{"text":"[!] ","color":"light_purple","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"你已恢复 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"❤ ","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"tool.math1","name":"@s"},"color":"dark_red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 血量","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
tellraw @s "§d§l[!] §f你已恢复 §b✿ §3§l10 §f精神"
scoreboard players operation @s health < @s maxhealth

scoreboard players add @s spirit 10
scoreboard players set @s[score_spirit_min=101] spirit 100

scoreboard players set @s drink 0

scoreboard players tag @s remove temp.item.杏仁水

effect @s minecraft:saturation 10 1