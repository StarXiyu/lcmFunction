
execute @a[score_drink_min=1] ~ ~ ~ function system:takeTool/drinkTool/杏仁水 if @s[score_drinkType_min=1,score_drinkType=1]