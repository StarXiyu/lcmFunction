
scoreboard players set @s drinkType 1 {SelectedItem:{tag:{Tags:["item.杏仁水"]}}}

scoreboard players tag @s remove temp.item.drinkTool