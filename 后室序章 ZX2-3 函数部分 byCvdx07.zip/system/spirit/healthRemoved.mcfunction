
scoreboard players remove @a[score_spirit=0] health 1
tellraw @a[score_spirit=0] "§f[§b§l精神污染§f] §f你的血量 §4❤ §c§l-1"
effect @a[score_spirit=0] slowness 2 1
effect @a[score_spirit=0] instant_damage 1 1 true

execute @a[score_spirit=0] ~ ~ ~ function system:spirit/death if @s[score_health=0]