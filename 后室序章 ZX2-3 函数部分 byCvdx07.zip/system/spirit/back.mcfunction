
scoreboard players add @a[score_time.spirit_min=15] spirit 1
scoreboard players set @a[score_time.spirit_min=15] time.spirit 0