
tp @s[tag=MEG.Alpha基地] 158 12 346
execute @s[tag=!MEG.Alpha基地] ~ ~ ~ tp @s[tag=Level1.通用存档点] 263 4 182
execute @s[tag=!MEG.Alpha基地] ~ ~ ~ execute @s[tag=!Level1.通用存档点] ~ ~ ~ tp @s 595.926 4 468.926
execute @s[tag=!MEG.Alpha基地] ~ ~ ~ execute @s[tag=!Level1.通用存档点] ~ ~ ~ tellraw @s "§4§l[!] §f请先完成层级存档!"