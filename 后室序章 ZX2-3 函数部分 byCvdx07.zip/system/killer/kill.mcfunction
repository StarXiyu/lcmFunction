

execute @e[tag=!nk] ~ ~ ~ function system:nk if @e[tag=!system.entity.nktest]

scoreboard players set @s kill.count 0

scoreboard objectives remove killer.math
scoreboard objectives add killer.math dummy

execute @e[tag=!nk] ~ ~ ~ execute @s[tag=monster] ~ ~ ~ scoreboard players operation @s killer.math = @s health
execute @e[tag=!nk] ~ ~ ~ execute @s[tag=monster] ~ ~ ~ scoreboard players operation @s killer.math *= 100 math
execute @e[tag=!nk] ~ ~ ~ execute @s[tag=monster] ~ ~ ~ scoreboard players operation @s killer.math /= @s maxhealth

execute @e[tag=!nk] ~ ~ ~ execute @s[tag=monster,score_killer.math_min=51] ~ ~ ~ scoreboard players add @e[tag=killer] kill.count 1
execute @e[tag=!nk] ~ ~ ~ execute @s[tag=!monster] ~ ~ ~ scoreboard players add @e[tag=killer] kill.count 1

tellraw @a [{"text":"§f[§6A.E.G§f] §8>> §f实体清理完毕 §a✔"}]
tellraw @a [{"text":"§f[§6A.E.G§f]","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >> ","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"本次共计清理 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"kill.count","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 个实体","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

execute @e[tag=!nk] ~ ~ ~ kill @s[tag=!monster]
execute @e[tag=!nk] ~ ~ ~ kill @s[tag=monster,score_killer.math_min=51]
kill @e[type=item]

scoreboard players set @s killer 0