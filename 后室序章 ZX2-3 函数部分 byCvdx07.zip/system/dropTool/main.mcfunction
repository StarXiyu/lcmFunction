
scoreboard players tag @s remove temp.item.dropTool

scoreboard players tag @s add temp.item.medicalTool {Item:{tag:{Tags:["item.medicalTool"]}}}
function system:dropTool/medicalTool/main if @s[tag=temp.item.medicalTool]