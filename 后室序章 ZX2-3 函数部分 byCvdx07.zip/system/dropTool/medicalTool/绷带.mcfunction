
scoreboard players tag @s remove temp.item.绷带

execute @p[r=4] ~ ~ ~ function system:dropTool/medicalTool/player/绷带

kill @s