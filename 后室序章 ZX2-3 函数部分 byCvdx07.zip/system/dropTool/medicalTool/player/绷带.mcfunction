
scoreboard players operation @s tool.math1 = @s maxhealth
## maxhealth * 5% = maxhealth * 5 / 100
scoreboard players set 5 math 5

scoreboard players operation @s tool.math1 *= 5 math
scoreboard players operation @s tool.math1 /= 100 math
scoreboard players operation @s health += @s tool.math1

tellraw @s [{"text":"[!] ","color":"light_purple","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"你已恢复 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"❤ ","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"tool.math1","name":"@s"},"color":"dark_red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 血量","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
scoreboard players operation @s health < @s maxhealth