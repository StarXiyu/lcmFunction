
scoreboard players tag @s remove temp.item.medicalTool

scoreboard players tag @s add temp.item.绷带 {Item:{tag:{Tags:["item.绷带"]}}}
function system:dropTool/medicalTool/绷带 if @s[tag=temp.item.绷带]