
scoreboard players operation @s xp -= @s xp.need
scoreboard players add @s xp.need 50
scoreboard players add @s level 1

tellraw @s "§a§l[!] §7您的冒险等级已提升!"
playsound minecraft:entity.player.levelup ambient @s ~ ~ ~

particle totem ~ ~ ~ 1 1 1 0.002 100 force @a[r=50]

## 获取积分
scoreboard players operation @s jf.get = @s level
scoreboard players operation @s jf.get *= 10 math
scoreboard players operation @s jf += @s jf.get
tellraw @s [{"text":"[!] ","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"您已获得 ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"⛃ ","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"jf.get","name":"@s"},"color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 积分","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

## 特殊级别
scoreboard players operation @s xp.math2 = @s level
scoreboard players operation @s xp.math2 %= 5 math
function system:xp/int if @s[score_xp.math2=0,score_xp.math2_min=0]