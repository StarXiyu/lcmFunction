

scoreboard players add @s n.maxhealth 10

tellraw @s " "
tellraw @s "§b§l[!] §f您已获得冒险等级 §e30级 §f专属奖励 => §a最大生命点数+10"
tellraw @s " "