
scoreboard players add @s n.critResist 10

tellraw @s " "
tellraw @s "§b§l[!] §f您已获得冒险等级 §e65级 §f专属奖励 => §a暴击抵抗+10"
tellraw @s " "