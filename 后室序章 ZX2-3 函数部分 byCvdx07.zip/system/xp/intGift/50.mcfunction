

scoreboard players add @s n.phyAttack 10

tellraw @s " "
tellraw @s "§b§l[!] §f您已获得冒险等级 §e50级 §f专属奖励 => §a物理攻击10点"
tellraw @s " "