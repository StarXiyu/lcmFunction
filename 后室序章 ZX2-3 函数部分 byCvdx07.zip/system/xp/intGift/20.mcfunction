
scoreboard players add @s 隐秘层级进入次数 1

tellraw @s " "
tellraw @s "§b§l[!] §f您已获得冒险等级 §e20级 §f专属奖励 => §a隐秘层级进入资格*1"
tellraw @s " "