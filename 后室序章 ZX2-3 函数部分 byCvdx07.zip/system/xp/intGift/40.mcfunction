

scoreboard players add @s n.vampirism 10
scoreboard players add @s n.vampirism.rate 35

tellraw @s " "
tellraw @s "§b§l[!] §f您已获得冒险等级 §e40级 §f专属奖励 => §a吸血概率10% + 吸血倍率35%"
tellraw @s " "