

scoreboard players add @s effect.speed 1

tellraw @s " "
tellraw @s "§b§l[!] §f您已获得冒险等级 §e55级 §f专属奖励 => §a速度等级+1"
tellraw @s " "