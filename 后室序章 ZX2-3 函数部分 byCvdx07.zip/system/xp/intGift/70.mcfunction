
scoreboard players tag @s add prefix.速切玩家

tellraw @s " "
tellraw @s "§b§l[!] §f您已获得冒险等级 §e70级 §f专属奖励 => §a「速切玩家」称号"
tellraw @s " "