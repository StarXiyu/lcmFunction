
## 20级
function system:xp/intGift/20 if @s[score_level_min=20,score_level=20]

## 30级
function system:xp/intGift/30 if @s[score_level_min=30,score_level=30]

## 40级
function system:xp/intGift/40 if @s[score_level_min=40,score_level=40]

## 50级
#! 待定 等装备做出来
function system:xp/intGift/50 if @s[score_level_min=50,score_level=50]

## 55级
function system:xp/intGift/55 if @s[score_level_min=55,score_level=55]

## 60级
function system:xp/intGift/60 if @s[score_level_min=60,score_level=60]

## 65级
function system:xp/intGift/65 if @s[score_level_min=65,score_level=65]

## 70级
function system:xp/intGift/70 if @s[score_level_min=70,score_level=70]