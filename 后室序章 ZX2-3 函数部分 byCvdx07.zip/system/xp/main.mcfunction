
## 初始化
function system:xp/init if @s[tag=!xp.init]

## 计算
# 升级所需要的经验 -= 当前经验 如果最大是0则升级
scoreboard players operation @s xp.math1 = @s xp.need
scoreboard players operation @s xp.math1 -= @s xp

## 升级
function system:xp/levelUP if @s[score_xp.math1=0]

## 提示
tellraw @s [{"text":"[!] ","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"冒险等级:","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"level","name":"@s"},"color":"white","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"  经验:","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"xp","name":"@s"},"color":"white","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 升级所需经验:","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"xp.need","name":"@s"},"color":"white","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]