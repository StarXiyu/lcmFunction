
scoreboard players set @s xp.need 50
scoreboard players set @s level 0
scoreboard players tag @s add xp.init