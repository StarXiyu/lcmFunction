
tp @a[score_menu=1,score_menu_min=1] 583 6 453 0 0
execute @a[score_menu=4,score_menu_min=4] ~ ~ ~ function sethome:pos
execute @a[score_menu=5,score_menu_min=5] ~ ~ ~ function sethome:back

execute @a[score_menu=2,score_menu_min=2] ~ ~ ~ scoreboard players operation @s health = @s maxhealth
execute @a[score_menu=2,score_menu_min=2] ~ ~ ~ scoreboard players operation set @s spirit 100
execute @a[score_menu=2,score_menu_min=2] ~ ~ ~ kill @s

tp @a[score_menu=3,score_menu_min=3,tag=BNTG] 134.980 5 -53.761
tellraw @a[score_menu=3,score_menu_min=3,tag=!BNTG] "§4§l[!] §f权限不足,请私信交流㪊㪊主获得权限"

scoreboard players tag @a[score_menu=3,score_menu_min=3,tag=!BNTG] add temp.menu.failCD

title @a[score_menu_min=1,tag=!temp.menu.failCD] title "§2§l✔"
title @a[score_menu_min=1,tag=!temp.menu.failCD] subtitle "§a§l执行成功"

title @a[score_menu_min=1,tag=temp.menu.failCD] title "§4§l✘"
title @a[score_menu_min=1,tag=temp.menu.failCD] subtitle "§c§l执行失败"

execute @a[score_menu_min=1] ~ ~ ~ playsound minecraft:block.note.bell master @s ~ ~ ~

scoreboard players tag @a[tag=temp.menu.failCD] remove temp.menu.failCD
scoreboard players enable @a[score_menu_min=1] menu
scoreboard players set @a[score_menu_min=1] menu 0