
execute @a[tag=ban] ~ ~ ~ function system:ban
