
## 成就重置
advancement revoke @s only lightrpg:attackmonster
advancement revoke @s only lightrpg:pvp
advancement revoke @s only lightrpg:monsterattack01
advancement revoke @s only lightrpg:monsterattack02
advancement revoke @s only lightrpg:monsterattack03
advancement revoke @s only lightrpg:monsterattack04
advancement revoke @s only lightrpg:monsterattack05

## 重置
scoreboard players set @s a.maxhealth 0
scoreboard players set @s a.phyAttack 0
scoreboard players set @s a.spellAttack 0
scoreboard players set @s a.critPob 0
scoreboard players set @s a.critAttack 0 
scoreboard players set @s a.physicsResist 0
scoreboard players set @s a.spellResist 0
scoreboard players set @s a.critResist 0
scoreboard players set @s a.physicsPene 0
scoreboard players set @s a.spellPene 0
scoreboard players set @s a.vampirism 0
scoreboard players set @s a.dodge 0
scoreboard players set @s a.drop 0
scoreboard players set @s a.seize 0
scoreboard players set @s a.hit 0
scoreboard players set @s a.vampirism.rate 0

scoreboard players set @s d.maxhealth 20
scoreboard players set @s d.phyAttack 0
scoreboard players set @s d.spellAttack 0
scoreboard players set @s d.critPob 0
scoreboard players set @s d.critAttack 150
scoreboard players set @s d.physicsResist 0
scoreboard players set @s d.spellResist 0
scoreboard players set @s d.critResist 0
scoreboard players set @s d.physicsPene 0
scoreboard players set @s d.spellPene 0
scoreboard players set @s d.vampirism 0
scoreboard players set @s d.dodge 0
scoreboard players set @s d.drop 0
scoreboard players set @s d.seize 0
scoreboard players set @s d.hit 0
scoreboard players set @s d.vampirism.rate 0

## 获取装备属性
function API:getAttribute/main

## 加和自定义属性
scoreboard players operation @s d.maxhealth += @s n.maxhealth
scoreboard players operation @s d.phyAttack += @s n.phyAttack
scoreboard players operation @s d.spellAttack += @s n.spellAttack
scoreboard players operation @s d.critPob += @s n.critPob
scoreboard players operation @s d.critAttack += @s n.critAttack
scoreboard players operation @s d.physicsResist += @s n.physicsResist
scoreboard players operation @s d.spellResist += @s n.spellResist
scoreboard players operation @s d.critResist += @s n.critResist
scoreboard players operation @s d.physicsPene += @s n.physicsPene
scoreboard players operation @s d.spellPene += @s n.spellPene
scoreboard players operation @s d.vampirism += @s n.vampirism
scoreboard players operation @s d.dodge += @s n.dodge
scoreboard players operation @s d.seize += @s n.seize
scoreboard players operation @s d.hit += @s n.hit
scoreboard players operation @s d.vampirism.rate += @s n.vampirism

## 加和装备/武器属性
scoreboard players operation @s d.maxhealth += @s a.maxhealth
scoreboard players operation @s d.phyAttack += @s a.phyAttack
scoreboard players operation @s d.spellAttack += @s a.spellAttack
scoreboard players operation @s d.critPob += @s a.critPob
scoreboard players operation @s d.critAttack += @s a.critAttack
scoreboard players operation @s d.physicsResist += @s a.physicsResist
scoreboard players operation @s d.spellResist += @s a.spellResist
scoreboard players operation @s d.critResist += @s a.critResist
scoreboard players operation @s d.physicsPene += @s a.physicsPene
scoreboard players operation @s d.spellPene += @s a.spellPene
scoreboard players operation @s d.vampirism += @s a.vampirism
scoreboard players operation @s d.dodge += @s a.dodge
scoreboard players operation @s d.seize += @s a.seize
scoreboard players operation @s d.hit += @s a.hit
scoreboard players operation @s d.vampirism.rate += @s a.vampirism

scoreboard players operation @s maxhealth = @s d.maxhealth
scoreboard players operation @s health < @s maxhealth

## 生命恢复
scoreboard players operation @s d.regeneration += @s regeneration

## 提示
function system:tellraw_loadAttribute if @s[tag=!temp.noTellraw.loadAttribute]

scoreboard players set @s loadAttribute 0
scoreboard players enable @s loadAttribute
playsound minecraft:block.note.bell master @s ~ ~ ~
scoreboard players tag @s remove temp.noTellraw.loadAttribute
scoreboard players set @s time.RAttribute 0

## getAttribute
function system:getAttribute