
execute @a[score_talk_min=1,x=183,y=12,z=343,r=4] ~ ~ ~ function system:MEG/join/main

scoreboard players set @a[score_talk_min=1] talk 0