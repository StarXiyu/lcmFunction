
scoreboard teams join hpBar.100 @e[tag=entity.rpg.待赋值]

function system:monsterMath/赋值组1 if @e[tag=entity.rpg.赋值组1]
function system:monsterMath/赋值组2 if @e[tag=entity.rpg.赋值组2]