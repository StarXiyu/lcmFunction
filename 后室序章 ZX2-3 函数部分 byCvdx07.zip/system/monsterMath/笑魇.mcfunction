
scoreboard players set @e[tag=entity.rpg.笑魇待赋值] maxhealth 20
scoreboard players set @e[tag=entity.rpg.笑魇待赋值] health 20
scoreboard players set @e[tag=entity.rpg.笑魇待赋值] spellAttack 10
scoreboard players set @e[tag=entity.rpg.笑魇待赋值] drop 750

scoreboard players tag @e[tag=entity.rpg.笑魇待赋值] remove entity.rpg.待赋值
scoreboard players tag @e[tag=entity.rpg.笑魇待赋值] remove entity.rpg.赋值组1
scoreboard players tag @e[tag=entity.rpg.笑魇待赋值] remove entity.rpg.笑魇待赋值