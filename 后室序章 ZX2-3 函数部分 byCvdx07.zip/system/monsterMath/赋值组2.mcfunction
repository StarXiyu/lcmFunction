
## 无面灵
function system:monsterMath/无面灵 if @e[tag=entity.rpg.无面灵待赋值]