
scoreboard players set @e[tag=entity.rpg.无面灵待赋值] maxhealth 40
scoreboard players set @e[tag=entity.rpg.无面灵待赋值] health 40
scoreboard players set @e[tag=entity.rpg.无面灵待赋值] phyAttack 10
scoreboard players set @e[tag=entity.rpg.无面灵待赋值] drop 600

scoreboard players tag @e[tag=entity.rpg.无面灵待赋值] remove entity.rpg.待赋值
scoreboard players tag @e[tag=entity.rpg.无面灵待赋值] remove entity.rpg.赋值组2
scoreboard players tag @e[tag=entity.rpg.无面灵待赋值] remove entity.rpg.无面灵待赋值