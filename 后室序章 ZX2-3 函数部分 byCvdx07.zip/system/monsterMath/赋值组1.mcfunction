
## 钝人
function system:monsterMath/钝人 if @e[tag=entity.rpg.钝人待赋值]

## 笑魇
function system:monsterMath/笑魇 if @e[tag=entity.rpg.笑魇待赋值]

## 猎犬
function system:monsterMath/猎犬 if @e[tag=entity.rpg.猎犬待赋值]