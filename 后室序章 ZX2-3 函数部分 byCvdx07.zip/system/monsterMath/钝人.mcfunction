
scoreboard players set @e[tag=entity.rpg.钝人待赋值] maxhealth 30
scoreboard players set @e[tag=entity.rpg.钝人待赋值] health 30
scoreboard players set @e[tag=entity.rpg.钝人待赋值] phyAttack 8
scoreboard players set @e[tag=entity.rpg.钝人待赋值] drop 800

scoreboard players tag @e[tag=entity.rpg.钝人待赋值] remove entity.rpg.待赋值
scoreboard players tag @e[tag=entity.rpg.钝人待赋值] remove entity.rpg.赋值组1
scoreboard players tag @e[tag=entity.rpg.钝人待赋值] remove entity.rpg.钝人待赋值