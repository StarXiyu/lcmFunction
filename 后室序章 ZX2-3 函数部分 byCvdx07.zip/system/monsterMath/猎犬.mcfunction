
scoreboard players set @e[tag=entity.rpg.猎犬待赋值] maxhealth 10
scoreboard players set @e[tag=entity.rpg.猎犬待赋值] health 10
scoreboard players set @e[tag=entity.rpg.猎犬待赋值] phyAttack 3
scoreboard players set @e[tag=entity.rpg.猎犬待赋值] drop 600

scoreboard players tag @e[tag=entity.rpg.猎犬待赋值] remove entity.rpg.待赋值
scoreboard players tag @e[tag=entity.rpg.猎犬待赋值] remove entity.rpg.赋值组1
scoreboard players tag @e[tag=entity.rpg.猎犬待赋值] remove entity.rpg.猎犬待赋值