
## Level1 : 物资箱
execute @s[tag=entity.armorStand.chest.level1] ~ ~ ~ function system:chest/Level1/main if @p[r=4]