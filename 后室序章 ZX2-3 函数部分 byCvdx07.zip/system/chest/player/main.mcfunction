
execute @a[score_chest_min=1] ~ ~ ~ function system:chest/player/getItem if @e[r=4,type=armor_stand,tag=entity.armorStand.chest.待开启]


scoreboard players set @a[score_chest_min=1] chest 0