
function system:chest/Level1/getItem if @e[r=5,type=armor_stand,tag=entity.armorStand.chest.level1]