
scoreboard players operation @e[r=5,c=1,tag=entity.armorStand.chest.level1] chestTime = systemTick tempBanT1
scoreboard players add @e[r=5,c=1,tag=entity.armorStand.chest.level1] chestTime 3600
execute @e[r=5,c=1,tag=entity.armorStand.chest.level1] ~ ~ ~ setblock ~ ~ ~ air
scoreboard players tag @e[r=5,c=1,tag=entity.armorStand.chest.level1] remove entity.armorStand.chest.待开启

scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main

# 15% 杏仁水 (你会在后室发现的主要饮品) —————— 饱和10s 回血25% 精神10
# 25% 线条
# 25% 蜘蛛眼
# 20% 绷带 ———— 回血5%
# 15% 粗制木棍

give @s[score_math.out_min=1,score_math.out=25] spider_eye 1 0
give @s[score_math.out_min=26,score_math.out=50] string 1 0
give @s[score_math.out_min=51,score_math.out=71] paper 1 0 {ench:[{lvl:1s,id:70s}],HideFlags:63b,display:{Lore:["§6❏§f道具","§7§o按Q键丢出使用:§c§o回血5%"],Name:"§7<- §e绷带 §7->"},Tags:["item.dropTool","item.medicalTool","item.绷带"]}
give @s[score_math.out_min=72,score_math.out=86] stick 1 0 {display:{Lore:["§6❏§f材料","§7§o可用于合成精致木棍等物品"],Name:"§7<- §8粗制木棍 §7->"}}
give @s[score_math.out_min=87,score_math.out=100] potion 1 0 {CustomPotionEffects:[{Duration:200,Id:23,Amplifier:1}],Potion:"CBC",HideFlags:63,display:{Lore:["§6❏§f道具","","§b⚝ §f药水效果","§r§7  §3§l▮ §f饱和 §810秒","§r§7  §3§l▮ §f恢复血量 §825%","§r§7  §3§l▮ §f增加精神值 §810",""],Name:"§7<- §a杏仁水 §7->"},Tags:["item.takeTool","item.drinkTool","item.杏仁水"]}
scoreboard players tag @e[r=5,type=item,c=1] add system.itemCheck