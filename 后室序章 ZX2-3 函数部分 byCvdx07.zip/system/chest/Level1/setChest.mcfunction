
setblock ~ ~ ~ minecraft:chest 0 replace {CustomName:"§7§lLevel1物资箱",Lock:"§e§l物资箱钥匙",LootTable:"chests/empty"}
scoreboard players tag @s add entity.armorStand.chest.待开启