
## CD 3600tick
    scoreboard players add @s chestTime 0
	scoreboard players operation @s chestTime.math = @s chestTime
	scoreboard players operation @s chestTime.math -= systemTick tempBanT1

	## True
	function system:chest/Level1/setChest if @s[score_chestTime.math=0]