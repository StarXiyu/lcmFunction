
scoreboard players remove @s health 3
tellraw @s "§f[§b§l坍塌陷阱§f] §f你的血量 §4❤ §c§l-3"
effect @s instant_damage 1 1 true

function system:Level0.2陷阱Death if @s[score_health=0]