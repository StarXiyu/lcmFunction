
scoreboard players set 20 math 20
scoreboard players set -1 math -1
scoreboard players operation @s shop.item -= 20 math
scoreboard players operation @s shop.item *= -1 math

tellraw @s [{"text":"§c>> §f缺少 §8§o积分 §7* "},{"score":{"objective":"shop.item","name":"@s"}}]

scoreboard players set @s shop.item 0