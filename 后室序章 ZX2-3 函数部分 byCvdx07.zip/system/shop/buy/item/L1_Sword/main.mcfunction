
## Stats
    stats entity @s clear AffectedItems
    scoreboard players add @s shop.item 0
    stats entity @s set AffectedItems @s shop.item

## 计数清零
scoreboard players set @s shop.buyCond 0

## 提示头
tellraw @s " "

## §8§o钝人头颅 §7*12
clear @s coal_block 0 0 {ench:[{lvl:1s,id:70s}],HideFlags:63,display:{Lore:["§6❏§f物品","§7钝人的头部骨骼结构"],Name:"§8钝人头颅"}}
function system:shop/buy/item/L1_Sword/钝人头颅不足 if @s[score_shop.item=11]
scoreboard players add @s[score_shop.item_min=12] shop.buyCond 1

## §e§o猎犬肢体 §7*20
clear @s bone 0 0 {display:{Lore:["§6❏§f材料","§7有着奇怪生理特征"],Name:"§7<- §e猎犬肢体 §7->"}}
function system:shop/buy/item/L1_Sword/猎犬肢体不足 if @s[score_shop.item=19]
scoreboard players add @s[score_shop.item_min=20] shop.buyCond 1

## §6§o笑魇头颅 §7*15
clear @s pumpkin 0 0 {display:{Lore:["§6❏§f材料","§7标志性的反光的双眼"],Name:"§7<- §6笑魇头颅 §7->"}}
function system:shop/buy/item/L1_Sword/笑魇头颅不足 if @s[score_shop.item=14]
scoreboard players add @s[score_shop.item_min=15] shop.buyCond 1

## §8§o粗制木棍 §7*4
clear @s stick 0 0 {display:{Lore:["§6❏§f材料","§7§o可用于合成精致木棍等物品"],Name:"§7<- §8粗制木棍 §7->"}}
function system:shop/buy/item/L1_Sword/粗制木棍不足 if @s[score_shop.item=3]
scoreboard players add @s[score_shop.item_min=4] shop.buyCond 1

## 积分
scoreboard players operation @s shop.item = @s jf
function system:shop/buy/item/L1_Sword/积分不足 if @s[score_shop.item=19]
scoreboard players add @s[score_shop.item_min=20] shop.buyCond 1

## 满足条件
function system:shop/buy/item/L1_Sword/条件满足 if @s[score_shop.buyCond_min=5]

## 条件不满足提示
playsound minecraft:entity.villager.no ambient @s[score_shop.buyCond=4]

## 提示尾
tellraw @s " "

## 结束stats
    stats entity @s clear AffectedItems
    stats entity @s set AffectedItems @s chestmenu.item
    scoreboard players set @s chestmenu.item 0