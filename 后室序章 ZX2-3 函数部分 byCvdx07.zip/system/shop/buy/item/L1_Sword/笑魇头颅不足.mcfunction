
scoreboard players set 15 math 15
scoreboard players set -1 math -1
scoreboard players operation @s shop.item -= 15 math
scoreboard players operation @s shop.item *= -1 math

tellraw @s [{"text":"§c>> §f缺少 §6§o笑魇头颅 §7* "},{"score":{"objective":"shop.item","name":"@s"}}]

scoreboard players set @s shop.item 0