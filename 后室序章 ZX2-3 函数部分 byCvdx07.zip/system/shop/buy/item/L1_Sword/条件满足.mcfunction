
tellraw @s "§a>> §f购买成功"
playsound entity.arrow.hit_player master @s ~ ~ ~ 80 1 0

clear @s coal_block 0 12 {ench:[{lvl:1s,id:70s}],HideFlags:63,display:{Lore:["§6❏§f物品","§7钝人的头部骨骼结构"],Name:"§8钝人头颅"}}
clear @s bone 0 20 {display:{Lore:["§6❏§f材料","§7有着奇怪生理特征"],Name:"§7<- §e猎犬肢体 §7->"}}
clear @s pumpkin 0 15 {display:{Lore:["§6❏§f材料","§7标志性的反光的双眼"],Name:"§7<- §6笑魇头颅 §7->"}}
clear @s stick 0 4 {display:{Lore:["§6❏§f材料","§7§o可用于合成精致木棍等物品"],Name:"§7<- §8粗制木棍 §7->"}}
scoreboard players remove @s jf 20

give @s stone_sword 1 0 {Unbreakable:1b,HideFlags:63,dat:{critPob:{0:0b,1:1b,2:0b,3:1b,4:0b,5:0b,6:0b,7:0b,8:0b,9:0b,10:0b},phyAttack:{0:1b,1:0b,2:1b,3:0b,4:0b,5:0b,6:0b,7:0b,8:0b,9:0b,10:0b}},display:{Lore:["§6❏§f物理武器","","§b⚝ §f基础信息","§r§7  §3§l▮ §f品质 §8废铁","§r§7    §7由致密圆石与木柄粗糙拼合的长剑","§r§7    §7刃部布满凿刻的痕迹","","§a⚝ §f武器属性","§r§7  §2§l▮ §f物理攻击 §25","§r§7  §2§l▮ §f暴击概率 §210%","","§e⚝ §f武器技能","§r§7  §e§l▮ §f常规","§r§7    §7你每次攻击目标,就攻击了一次目标"],Name:"§7<- §8石剑 §7->"}}