
scoreboard players set 12 math 12
scoreboard players set -1 math -1
scoreboard players operation @s shop.item -= 12 math
scoreboard players operation @s shop.item *= -1 math

tellraw @s [{"text":"§c>> §f缺少 §6§o笑魇头颅 §7* "},{"score":{"objective":"shop.item","name":"@s"}}]

scoreboard players set @s shop.item 0