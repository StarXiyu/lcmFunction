
scoreboard players set 8 math 8
scoreboard players set -1 math -1
scoreboard players operation @s shop.item -= 8 math
scoreboard players operation @s shop.item *= -1 math

tellraw @s [{"text":"§c>> §f缺少 §8§o钝人头颅 §7* "},{"score":{"objective":"shop.item","name":"@s"}}]

scoreboard players set @s shop.item 0