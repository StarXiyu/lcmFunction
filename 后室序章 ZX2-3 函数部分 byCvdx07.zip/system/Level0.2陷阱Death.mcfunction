
tellraw @a [{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 因墙壁坍塌而死亡","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

function LightRPG:playerDie/noTellraw