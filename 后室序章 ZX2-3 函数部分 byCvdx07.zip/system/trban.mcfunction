scoreboard players tag @s[tag=admin] add 封禁成功
scoreboard players tag @s[tag=op] add 封禁成功

tellraw @s[tag=!封禁成功] [{"text":"§f[§6协管系统§f] §7您没权限搁着封禁谁呢"}]
scoreboard players set @s[tag=!封禁成功] ban 0

execute @s[tag=封禁成功] ~ ~ ~ execute @a ~ ~ ~ scoreboard players operation @s banuid = @s uid
execute @s[tag=封禁成功] ~ ~ ~ scoreboard players operation @a banuid -= @s ban
execute @s[tag=封禁成功] ~ ~ ~ scoreboard players tag @a[score_banuid=0,score_banuid_min=0] add bban
execute @s[tag=封禁成功] ~ ~ ~ scoreboard players tag @a[tag=bban] add ban
execute @s[tag=封禁成功] ~ ~ ~ tellraw @a [{"text":"[","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"协管系统","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"] ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 发送了封禁数据给 ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[tag=bban]","color":"aqua","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute @s[tag=封禁成功] ~ ~ ~ scoreboard players tag @a remove bban
execute @s[tag=封禁成功] ~ ~ ~ scoreboard players reset @a banuid
execute @s[tag=封禁成功] ~ ~ ~ scoreboard players set @a ban 0
scoreboard players tag @s remove 封禁成功

scoreboard players enable @s ban