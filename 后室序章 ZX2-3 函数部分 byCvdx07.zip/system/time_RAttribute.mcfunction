
scoreboard players tag @s add temp.noTellraw.loadAttribute
scoreboard players set @s time.RAttribute 0
tellraw @s "\n§6§l[!] §f已为您自动更新属性\n"

function system:loadAttribute