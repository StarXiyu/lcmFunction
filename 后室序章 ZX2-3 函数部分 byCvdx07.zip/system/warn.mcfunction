scoreboard players tag @s[tag=admin] add 警告成功
scoreboard players tag @s[tag=op] add 警告成功

tellraw @s[tag=!警告成功] [{"text":"§f[§6协管系统§f] §7您没权限搁着警告谁呢"}]
scoreboard players set @s[tag=!警告成功] jinggao 0

execute @s[tag=警告成功] ~ ~ ~ execute @a ~ ~ ~ scoreboard players operation @s jinggaouid = @s uid
execute @s[tag=警告成功] ~ ~ ~ scoreboard players operation @a jinggaouid -= @s jinggao
execute @s[tag=警告成功] ~ ~ ~ scoreboard players tag @a[score_jinggaouid=0,score_jinggaouid_min=0] add bjinggao
execute @s[tag=警告成功] ~ ~ ~ scoreboard players add @a[tag=bjinggao] 警告 1
execute @s[tag=警告成功] ~ ~ ~ tellraw @a [{"text":"[","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"协管系统","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"] ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"警告了玩家","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[tag=bjinggao]","color":"aqua","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"一次,如果警告达到10次该玩家将被封禁(","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"警告","name":"@a[tag=bjinggao]"},"color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"/10)","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute @s[tag=警告成功] ~ ~ ~ scoreboard players tag @a remove bjinggao
execute @s[tag=警告成功] ~ ~ ~ scoreboard players reset @a jinggaouid
execute @s[tag=警告成功] ~ ~ ~ scoreboard players set @a jinggao 0
scoreboard players tag @s remove 警告成功

scoreboard players enable @s jinggao