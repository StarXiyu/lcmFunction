scoreboard players set @s main 0

effect @a night_vision 9999 255 true
weather clear

## 修复PVP
advancement revoke @a only lightrpg:pvp

## 锁定展示框
entitydata @e[tag=entity.itemFrame.LockRotation0,type=item_frame] {ItemRotation:0b}
entitydata @e[tag=entity.itemFrame.LockRotation4,type=item_frame] {ItemRotation:4b}

## 精神值回复
scoreboard players add @a[score_spirit=99] time.spirit 5
function system:spirit/back if @p[score_spirit_min=15]

## 驯服的怪物狗死亡
scoreboard players tag @e[type=wolf,tag=monster] add dogKilled {Attributes:[{Base:20.0d,Name:"generic.maxHealth"}]}
kill @e[tag=dogKilled,type=wolf]

## 村民
effect @e[type=villager] resistance 9999 255 true

## GPS导航
scoreboard players add @a[score_GPS_min=1] GPS.time 5
function system:GPS/timeout if @p[score_GPS.time_min=300]