
## [01] 新玩家登录 => 剧情引导
    function system:guide/intro if @p[tag=!xrGuide.intro]
    execute @a[tag=xrGuide.1] ~ ~ ~ function system:guide/1

scoreboard players add @s killer 1
function system:killer/main if @s[score_killer_min=289]

## 箱子
execute @e[tag=entity.armorStand.chest] ~ ~ ~ execute @s[tag=!entity.armorStand.chest.待开启] ~ ~ ~ function system:chest/main if @p[r=10]

## 饮品
function system:takeTool/drinkTool/drinkMain if @p[score_drink_min=1]
scoreboard players set @a[score_drinkType_min=1] drinkType 0

## 精神值扣血
function system:spirit/healthRemoved if @p[score_spirit=0]

## GPS
function GPS:main if @p[score_GPS_min=1]

## 警告
scoreboard players enable @a[tag=admin] jinggao
execute @a[score_jinggao_min=1] ~ ~ ~ function system:warn
execute @a[score_警告_min=10] ~ ~ ~ function system:warnBan

## 5分钟刷新属性
scoreboard players add @a time.RAttribute 1
execute @p[score_time.RAttribute_min=600] ~ ~ ~ function system:time_RAttribute