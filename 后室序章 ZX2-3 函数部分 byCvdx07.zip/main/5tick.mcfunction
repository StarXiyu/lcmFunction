scoreboard players set @s main 0

scoreboard players add @e[tag=10tick,type=armor_stand] main 5
execute @e[tag=10tick] ~ ~ ~ function main:10tick if @s[score_main_min=10,score_main=20]

## 赋值
function system:monsterMath/main if @e[tag=entity.rpg.待赋值]

## 粒子
particle fallingdust 506 3 266 100 7 100 0.2 400 force @a[x=506,y=3,z=266,r=100] 3

## LightRPG
    effect @a minecraft:regeneration 10 255 true
    effect @a minecraft:resistance 10 3 true

## 丢出物品
execute @e[tag=item,tag=!system.itemCheck] ~ ~ ~ function system:itemCheck/main

## Talk
function system:talk/main if @p[score_talk_min=1]