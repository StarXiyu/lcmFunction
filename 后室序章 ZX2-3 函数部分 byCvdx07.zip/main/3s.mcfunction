scoreboard players set @s main 0

## 花园段精神污染
scoreboard players remove @a[x=306,y=4,z=112,r=55] spirit 1

## 标签自动增加
scoreboard players tag @a[tag=op] add admin
scoreboard players tag @a[tag=万神殿] add BNTG
scoreboard players tag @a[tag=BNTG] add MEG
scoreboard players tag @a[tag=BNTG] add UEC
scoreboard players tag @a[tag=BNTG] add player.已加入阵营