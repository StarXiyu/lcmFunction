scoreboard players add @e[tag=5tick,type=armor_stand] main 1

execute @e[tag=5tick] ~ ~ ~ function main:5tick if @s[score_main_min=5,score_main=10]

## 反刷物
    execute @a ~ ~ ~ scoreboard players tag @e[r=15,type=item] add keep
    kill @e[tag=!keep,type=item]
    scoreboard players tag @e[tag=keep,type=item] remove keep

## LightRPG
    scoreboard players enable @a §7LightRPG
    scoreboard players enable @a §8LightRPG
    execute @a[score_§7LightRPG_min=1] ~ ~ ~ function LightRPG:system/trigger/attackMain
    execute @a[score_§8LightRPG_min=1] ~ ~ ~ function LightRPG:system/trigger/hurtMain
    effect @e[tag=monster] minecraft:resistance 10 4 true

## 菜单触发
	function system:menu/sneak/main if @p[score_menuSneak_min=1]
	scoreboard players remove @a[score_sneak2_min=0] sneak2 1

	scoreboard players add @a[score_sneak2_min=0,score_sneak2=0] sneakCount 1
	function system:menu/sneak/count if @p[score_sneakCount_min=1]

## [01] 检测是否有已被封禁的玩家登录
	execute @a[tag=tempban.ban] ~ ~ ~ function tempban:ban/main

## [04] 增加服务器刻
	scoreboard players add systemTick tempBanT1 1

## 道具
scoreboard players tag @a[tag=joinGame] add temp.item.takeTool {SelectedItem:{tag:{Tags:["item.takeTool"]}}}
execute @a[tag=temp.item.takeTool] ~ ~ ~ function system:takeTool/main

## 封禁:永久
scoreboard players enable @a[tag=admin] ban
function system:trban触发 if @p[score_ban_min=1]
function system:ban触发 if @a[tag=ban]