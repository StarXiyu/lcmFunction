scoreboard players set @s main 0

scoreboard players add @e[tag=20tick,type=armor_stand] main 10
execute @e[tag=20tick] ~ ~ ~ function main:20tick if @s[score_main_min=20,score_main=40]

## 属性更新
execute @a[score_loadAttribute_min=1] ~ ~ ~ function system:loadAttribute

## actionbar
execute @a[tag=joinGame] ~ ~ ~ title @s actionbar [{"text":">> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"生命","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"❤ ","color":"dark_red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"/","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"maxhealth","name":"@s"},"color":"dark_red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"   精神","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"✿ ","color":"aqua","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"spirit","name":"@s"},"color":"dark_aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"   积分","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"⛃ ","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"jf","name":"@s"},"color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"   编号","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"Ν ","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"uid","name":"@s"},"color":"dark_green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"   冒险等级","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"ε ","color":"light_purple","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"level","name":"@s"},"color":"dark_purple","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <<","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

## menu
function system:menu/cd if @p[score_menu_min=1]

## TempBan

    ## [02] 检测是否有人启动tempban程序
        scoreboard players enable @a tempban
        execute @p[score_tempban_min=1] ~ ~ ~ function tempban:setPlayer/main

    ## [03] 检测是否有人设定时间
        execute @p[score_tempban.time_min=1] ~ ~ ~ function tempban:setTime/main

## 开箱子
function system:chest/player/main if @p[score_chest_min=1]

## Level0.2陷阱
execute @a[x=508,y=11,z=120,r=90] ~ ~ ~ detect ~ ~-1 ~ sand 1 function system:Level0.2陷阱