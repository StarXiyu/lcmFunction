scoreboard players tag @e[tag=花园段L2入口] add benoted
summon area_effect_cloud ~0.0000 1000 ~0.010000 {Tags:["thenote","thenote1"]}
summon area_effect_cloud ~-0.0017 1000 ~0.009848 {Tags:["thenote","thenote2"]}
summon area_effect_cloud ~-0.0034 1000 ~0.009397 {Tags:["thenote","thenote3"]}
summon area_effect_cloud ~-0.0050 1000 ~0.008660 {Tags:["thenote","thenote4"]}
summon area_effect_cloud ~-0.0064 1000 ~0.007660 {Tags:["thenote","thenote5"]}
summon area_effect_cloud ~-0.0077 1000 ~0.006428 {Tags:["thenote","thenote6"]}
summon area_effect_cloud ~-0.0087 1000 ~0.005000 {Tags:["thenote","thenote7"]}
summon area_effect_cloud ~-0.0094 1000 ~0.003420 {Tags:["thenote","thenote8"]}
summon area_effect_cloud ~-0.0098 1000 ~0.001736 {Tags:["thenote","thenote9"]}
summon area_effect_cloud ~-0.0100 1000 ~0.000000 {Tags:["thenote","thenote10"]}
summon area_effect_cloud ~-0.0098 1000 ~-0.001736 {Tags:["thenote","thenote11"]}
summon area_effect_cloud ~-0.0094 1000 ~-0.003420 {Tags:["thenote","thenote12"]}
summon area_effect_cloud ~-0.0087 1000 ~-0.005000 {Tags:["thenote","thenote13"]}
summon area_effect_cloud ~-0.0077 1000 ~-0.006428 {Tags:["thenote","thenote14"]}
summon area_effect_cloud ~-0.0064 1000 ~-0.007660 {Tags:["thenote","thenote15"]}
summon area_effect_cloud ~-0.0050 1000 ~-0.008660 {Tags:["thenote","thenote16"]}
summon area_effect_cloud ~-0.0034 1000 ~-0.009397 {Tags:["thenote","thenote17"]}
summon area_effect_cloud ~-0.0017 1000 ~-0.009848 {Tags:["thenote","thenote18"]}
summon area_effect_cloud ~-0.0000 1000 ~-0.010000 {Tags:["thenote","thenote19"]}
summon area_effect_cloud ~0.0017 1000 ~-0.009848 {Tags:["thenote","thenote20"]}
summon area_effect_cloud ~0.0034 1000 ~-0.009397 {Tags:["thenote","thenote21"]}
summon area_effect_cloud ~0.0050 1000 ~-0.008660 {Tags:["thenote","thenote22"]}
summon area_effect_cloud ~0.0064 1000 ~-0.007660 {Tags:["thenote","thenote23"]}
summon area_effect_cloud ~0.0077 1000 ~-0.006428 {Tags:["thenote","thenote24"]}
summon area_effect_cloud ~0.0087 1000 ~-0.005000 {Tags:["thenote","thenote25"]}
summon area_effect_cloud ~0.0094 1000 ~-0.003420 {Tags:["thenote","thenote26"]}
summon area_effect_cloud ~0.0098 1000 ~-0.001736 {Tags:["thenote","thenote27"]}
summon area_effect_cloud ~0.0100 1000 ~-0.000000 {Tags:["thenote","thenote28"]}
summon area_effect_cloud ~0.0098 1000 ~0.001736 {Tags:["thenote","thenote29"]}
summon area_effect_cloud ~0.0094 1000 ~0.003420 {Tags:["thenote","thenote30"]}
summon area_effect_cloud ~0.0087 1000 ~0.005000 {Tags:["thenote","thenote31"]}
summon area_effect_cloud ~0.0077 1000 ~0.006428 {Tags:["thenote","thenote32"]}
summon area_effect_cloud ~0.0064 1000 ~0.007660 {Tags:["thenote","thenote33"]}
summon area_effect_cloud ~0.0050 1000 ~0.008660 {Tags:["thenote","thenote34"]}
summon area_effect_cloud ~0.0034 1000 ~0.009397 {Tags:["thenote","thenote35"]}
summon area_effect_cloud ~0.0017 1000 ~0.009848 {Tags:["thenote","thenote36"]}
execute @e[tag=benoted] ~ ~ ~ /entitydata @e[tag=thenote,c=1] {CustomName:"choose"}
function GPS:particle/0 if @e[tag=thenote1,name=choose]
function GPS:particle/10 if @e[tag=thenote2,name=choose]
function GPS:particle/20 if @e[tag=thenote3,name=choose]
function GPS:particle/30 if @e[tag=thenote4,name=choose]
function GPS:particle/40 if @e[tag=thenote5,name=choose]
function GPS:particle/50 if @e[tag=thenote6,name=choose]
function GPS:particle/60 if @e[tag=thenote7,name=choose]
function GPS:particle/70 if @e[tag=thenote8,name=choose]
function GPS:particle/80 if @e[tag=thenote9,name=choose]
function GPS:particle/90 if @e[tag=thenote10,name=choose]
function GPS:particle/100 if @e[tag=thenote11,name=choose]
function GPS:particle/110 if @e[tag=thenote12,name=choose]
function GPS:particle/120 if @e[tag=thenote13,name=choose]
function GPS:particle/130 if @e[tag=thenote14,name=choose]
function GPS:particle/140 if @e[tag=thenote15,name=choose]
function GPS:particle/150 if @e[tag=thenote16,name=choose]
function GPS:particle/160 if @e[tag=thenote17,name=choose]
function GPS:particle/170 if @e[tag=thenote18,name=choose]
function GPS:particle/180 if @e[tag=thenote19,name=choose]
function GPS:particle/190 if @e[tag=thenote20,name=choose]
function GPS:particle/200 if @e[tag=thenote21,name=choose]
function GPS:particle/210 if @e[tag=thenote22,name=choose]
function GPS:particle/220 if @e[tag=thenote23,name=choose]
function GPS:particle/230 if @e[tag=thenote24,name=choose]
function GPS:particle/240 if @e[tag=thenote25,name=choose]
function GPS:particle/250 if @e[tag=thenote26,name=choose]
function GPS:particle/260 if @e[tag=thenote27,name=choose]
function GPS:particle/270 if @e[tag=thenote28,name=choose]
function GPS:particle/280 if @e[tag=thenote29,name=choose]
function GPS:particle/290 if @e[tag=thenote30,name=choose]
function GPS:particle/300 if @e[tag=thenote31,name=choose]
function GPS:particle/310 if @e[tag=thenote32,name=choose]
function GPS:particle/320 if @e[tag=thenote33,name=choose]
function GPS:particle/330 if @e[tag=thenote34,name=choose]
function GPS:particle/340 if @e[tag=thenote35,name=choose]
function GPS:particle/350 if @e[tag=thenote36,name=choose]
scoreboard players tag @e[tag=benoted] remove benoted
kill @e[tag=thenote]