#此为低频函数（1秒1次）
#每个函数文件对应一个npc，函数文件里面有第一条指令是给npc上标签

execute @a[score_GPS_min=1,score_GPS=1] ~ ~ ~ function GPS:花园段L2入口

execute @e[tag=GPS.point] ~ ~ ~ scoreboard players set @a[r=4,score_GPS_min=1] GPS.time 0
execute @e[tag=GPS.point] ~ ~ ~ scoreboard players set @a[r=4,score_GPS_min=1] GPS 0

# jq代表触发分数，固定分数触发固定引导

# execute @a[score_jq_min=1] ~ ~ ~ function GPS:main