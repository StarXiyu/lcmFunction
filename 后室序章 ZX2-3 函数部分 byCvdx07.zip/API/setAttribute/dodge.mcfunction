
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{0:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{1:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{2:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{3:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{4:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{5:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{6:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{7:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{8:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{9:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 

    scoreboard players operation @s temp1 = @s s.dodge
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{dodge:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{dodge:{10:0b}}}}}
    scoreboard players operation @s s.dodge /= 2 math 
