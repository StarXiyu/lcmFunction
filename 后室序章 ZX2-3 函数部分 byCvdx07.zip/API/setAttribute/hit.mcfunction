
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{0:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{1:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{2:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{3:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{4:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{5:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{6:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{7:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{8:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{9:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 

    scoreboard players operation @s temp1 = @s s.hit
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{hit:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{hit:{10:0b}}}}}
    scoreboard players operation @s s.hit /= 2 math 
