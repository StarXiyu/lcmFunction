
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{0:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{1:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{2:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{3:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{4:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{5:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{6:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{7:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{8:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{9:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.phyAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{phyAttack:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{phyAttack:{10:0b}}}}}
    scoreboard players operation @s s.phyAttack /= 2 math 
