
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{0:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{1:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{2:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{3:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{4:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{5:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{6:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{7:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{8:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{9:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsResist:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsResist:{10:0b}}}}}
    scoreboard players operation @s s.physicsResist /= 2 math 
