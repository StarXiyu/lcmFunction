
## 设置值

    # 清空属性
    entitydata @e[r=2,c=1,type=item] {Item:{tag:{dat:{}}}}

    # maxhealth
    execute @s[score_s.maxhealth_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.maxhealth = @s s.maxhealth
    execute @s[score_s.maxhealth_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/maxhealth

    # phyAttack
    execute @s[score_s.phyAttack_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.phyAttack = @s s.phyAttack
    execute @s[score_s.phyAttack_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/phyAttack

    # spellAttack
    execute @s[score_s.spellAttack_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.spellAttack = @s s.spellAttack
    execute @s[score_s.spellAttack_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/spellAttack

    # critPob
    execute @s[score_s.critPob_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.critPob = @s s.critPob
    execute @s[score_s.critPob_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/critPob

    # critAttack
    execute @s[score_s.critAttack_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.critAttack = @s s.critAttack
    execute @s[score_s.critAttack_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/critAttack

    # physicsResist
    execute @s[score_s.physicsResist_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.physicsResist = @s s.physicsResist
    execute @s[score_s.physicsResist_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/physicsResist

    # spellResist
    execute @s[score_s.spellResist_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.spellResist = @s s.spellResist
    execute @s[score_s.spellResist_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/spellResist

    # critResist
    execute @s[score_s.critResist_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.critResist = @s s.critResist
    execute @s[score_s.critResist_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/critResist

    # physicsPene
    execute @s[score_s.physicsPene_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.physicsPene = @s s.physicsPene
    execute @s[score_s.physicsPene_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/physicsPene

    # spellPene
    execute @s[score_s.spellPene_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.spellPene = @s s.spellPene
    execute @s[score_s.spellPene_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/spellPene

    # vampirism
    execute @s[score_s.vampirism_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.vampirism = @s s.vampirism
    execute @s[score_s.vampirism_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/vampirism

    # dodge
    execute @s[score_s.dodge_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.dodge = @s s.dodge
    execute @s[score_s.dodge_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/dodge

    # seize
    execute @s[score_s.seize_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.seize = @s s.seize
    execute @s[score_s.seize_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/seize

    # hit
    execute @s[score_s.hit_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.hit = @s s.hit
    execute @s[score_s.hit_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/hit

    # vampirism.rate
    execute @s[score_s.vampirism.rate_min=1] ~ ~ ~ scoreboard players operation @e[r=2,c=1,type=item] s.vampirism.rate = @s s.vampirism.rate
    execute @s[score_s.vampirism.rate_min=1] ~ ~ ~ execute @e[r=2,c=1,type=item] ~ ~ ~ function API:setAttribute/vampirism.rate