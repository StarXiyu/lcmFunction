
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{0:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{1:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{2:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{3:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{4:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{5:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{6:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{7:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{8:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{9:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 

    scoreboard players operation @s temp1 = @s s.seize
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{seize:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{seize:{10:0b}}}}}
    scoreboard players operation @s s.seize /= 2 math 
