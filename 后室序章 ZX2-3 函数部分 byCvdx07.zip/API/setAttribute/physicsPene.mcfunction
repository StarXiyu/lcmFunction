
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{0:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{1:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{2:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{3:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{4:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{5:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{6:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{7:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{8:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{9:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 

    scoreboard players operation @s temp1 = @s s.physicsPene
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{physicsPene:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{physicsPene:{10:0b}}}}}
    scoreboard players operation @s s.physicsPene /= 2 math 
