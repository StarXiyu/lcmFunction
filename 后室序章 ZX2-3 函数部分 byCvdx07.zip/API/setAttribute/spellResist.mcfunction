
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{0:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{1:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{2:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{3:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{4:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{5:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{6:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{7:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{8:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{9:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 

    scoreboard players operation @s temp1 = @s s.spellResist
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellResist:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellResist:{10:0b}}}}}
    scoreboard players operation @s s.spellResist /= 2 math 
