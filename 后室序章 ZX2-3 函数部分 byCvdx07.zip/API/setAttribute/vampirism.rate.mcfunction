
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{0:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{1:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{2:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{3:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{4:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{5:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{6:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{7:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{8:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{9:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 

    scoreboard players operation @s temp1 = @s s.vampirism.rate
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism.rate:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism.rate:{10:0b}}}}}
    scoreboard players operation @s s.vampirism.rate /= 2 math 
