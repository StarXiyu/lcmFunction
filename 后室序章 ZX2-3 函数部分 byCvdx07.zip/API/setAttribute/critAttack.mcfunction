
scoreboard players set 2 math 2

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{0:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{0:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{1:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{1:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{2:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{2:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{3:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{3:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{4:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{4:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{5:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{5:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{6:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{6:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{7:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{7:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{8:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{8:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{9:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{9:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 

    scoreboard players operation @s temp1 = @s s.critAttack
    scoreboard players operation @s temp1 %= 2 math
    entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critAttack:{10:1b}}}}}
    entitydata @s[score_temp1=0] {Item:{tag:{dat:{critAttack:{10:0b}}}}}
    scoreboard players operation @s s.critAttack /= 2 math 
