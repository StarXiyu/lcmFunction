

# 检测黑色玻璃数量 把黑色玻璃替换成钻石块 以黑色玻璃检测方块数量
function API:AntiRegion/SeaCheat1


# 如果范围内黑色玻璃小于8个则在原地放9个方块 其为正方形 
# X  X  X
# X  X  X
# X  X  X
execute @s[score_blockcount=8] ~ ~ ~ function API:AntiRegion/SeaBlock

# 把上述的钻石块重新替换成黑色玻璃 无感变化
function API:AntiRegion/SeaCheat2

# 防止黑客敲掉玻璃 强制把0格的空气方块替换成黑色玻璃
function API:AntiRegion/SeaAntiBlock

