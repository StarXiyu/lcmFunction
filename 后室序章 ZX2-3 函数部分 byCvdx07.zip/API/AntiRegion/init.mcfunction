
# 创建计分板
scoreboard objectives add blockcount dummy
execute @a ~ ~ ~ function API:AntiRegion/SeaAnti

# 删除计分板缓存
scoreboard objectives remove blockcount