
##原理详解:
#部分方块在一个区块里面会强制刷新这个区块的光照 这样可以让复制失效
#各颜色玻璃 箱子 海晶灯萤石都可以 还有一些可以自己研究 
#如果使用这个系统务必让服务器主城第0格改成黑色玻璃或者其他可刷新方块
#区块的定义是16*255*16的小区块 按下F3后再按下H键可以查看区块
#如果使用这个系统可以弃用所有其他防刷措施包括成书刷物资也可以进行防御
#! 总结:用光照刷新强制刷新区块

# stats绑定
stats entity @s set AffectedBlocks @s blockcount

# 初始化
scoreboard players set @s blockcount 0
scoreboard players set @s gamerule 0
scoreboard players set @s gamerule 1 {Dimension:-1}
scoreboard players set @s gamerule 2 {Dimension:1}

# 检测黑色玻璃数量 把黑色玻璃替换成基岩 以黑色玻璃检测方块数量
function API:AntiRegion/SeaCheat1

# 明文
#tellraw @s [{"text":"§f[§cBlackHawkAnti-CheatExpert§f] "},{"score":{"objective":"blockcount","name":"@s"},"color":"white","bold":true},{"text":" SEA "}]

# 主城范围不启用防刷init 防止同行看出来
#scoreboard players set @s[x=-1015,y=5000,z=-502,dx=1495,dy=-9000,dz=970,score_gamerule=0] blockcount 900

# 如果范围内黑色玻璃小于8个则在原地放9个方块 其为正方形 
# X  X  X
# X  X  X
# X  X  X
execute @s[score_blockcount=8] ~ ~ ~ function API:AntiRegion/SeaBlock
execute @s[score_gamerule_min=1,score_gamerule=2] ~ ~ ~ function API:AntiRegion/otherworld/SeaAnti

# 把上述的钻石块重新替换成黑色玻璃 无感变化
function API:AntiRegion/SeaCheat2

# 防止黑客敲掉玻璃 强制把0格的空气方块替换成黑色玻璃
function API:AntiRegion/SeaAntiBlock

# 删除stats绑定
stats entity @s clear AffectedBlocks


