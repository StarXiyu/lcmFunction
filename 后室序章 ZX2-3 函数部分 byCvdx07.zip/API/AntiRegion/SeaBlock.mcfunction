setblock ~ 0 ~ stained_glass 15
setblock ~16 0 ~ stained_glass 15
setblock ~-16 0 ~ stained_glass 15
setblock ~ 0 ~-16 stained_glass 15
setblock ~ 0 ~16 stained_glass 15

setblock ~16 0 ~16 stained_glass 15
setblock ~16 0 ~-16 stained_glass 15

setblock ~-16 0 ~16 stained_glass 15
setblock ~-16 0 ~-16 stained_glass 15
