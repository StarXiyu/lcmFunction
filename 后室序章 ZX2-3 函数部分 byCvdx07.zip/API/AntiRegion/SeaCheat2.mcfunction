fill ~-16 0 ~-16 ~16 0 ~16 minecraft:stained_glass 15 replace minecraft:bedrock 0
