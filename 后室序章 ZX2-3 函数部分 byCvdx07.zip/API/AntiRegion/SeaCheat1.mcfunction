fill ~-16 0 ~-16 ~16 0 ~16 minecraft:bedrock 0 replace minecraft:stained_glass 15
