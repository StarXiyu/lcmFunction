
scoreboard players set §7uid uid 0