scoreboard objectives remove 公告

scoreboard objectives add 公告 dummy §4§l后室:序章

scoreboard objectives setdisplay sidebar 公告

scoreboard players set §9 公告 10
scoreboard players set §f§l|𝓼𝓼§3§l服务器交流㪊 公告 9
scoreboard players set §7§l|𝓼𝓼§f935469067 公告 8
scoreboard players set §7 公告 7
scoreboard players set §f§l|𝓼𝓼§6§l服务器菜单 公告 6
scoreboard players set §7§l|𝓼𝓼§f快速双蹲唤出菜单 公告 5
scoreboard players set §3 公告 4
scoreboard players set §f§l|𝓼𝓼§2§l服务器服主 公告 3
scoreboard players set §7§l|𝓼𝓼§fzixiao 公告 2
scoreboard players set §1 公告 1
scoreboard players set §8Powered_by_Cvdx07 公告 0