
## LightAC 被动防御边界检测
function LagCheck:start if @s[score_antiCrasher_min=1]
worldborder get
scoreboard players operation @s antiCrasher -= worldborder antiCrasher

## 延迟提示及记录
function LagCheck:xxxx if @s[score_antiCrasher_min=10]

# 上面那个自己加吧，这个就是延迟检测了