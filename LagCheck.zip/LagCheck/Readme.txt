
我觉得有些东西不应该锁在少部分人手里，反正我也准备退圈了，正巧时光也在B站发了视频，就把检测延迟的方法教给大家吧
我决定开源LightAC的延迟检测部分，具体的原理解释我会给大家推b站时光的教程

!! 请大家记住，租赁服第一个发现这个东西的人叫小小白ds !!
!! 加以完善改进的人叫绅士的白熊 !!
!! 我下面挂的详细教程的作者叫时光 !!
以后看见他们别不认识他们

初始化 function LagCheck:init
开始检测 execute @e[tag=antiCrasher.armor] ~ ~ ~ function LagCheck:start
循环执行 execute @e[tag=antiCrasher.armor] ~ ~ ~ function LagCheck:main

上面的是从 LightAC-AntiCrasher v5 扒下来的

详细原理教程 https://www.bilibili.com/video/BV1rb4UeaE3Y/?spm_id_from=333.337.search-card.all.click
(作者：时光)

2025.2.23 Cvdx07