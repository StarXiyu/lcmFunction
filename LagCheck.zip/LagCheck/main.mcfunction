

## 主入口

## 被动检测入口
function LagCheck:check

## execute @e[tag=antiCrasher.armor] ~ ~ ~ function LagCheck:main