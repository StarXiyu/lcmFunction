
LIGHTCOMMAND MCFUNCTION RELEASE INFROMATION
 - Dev Cvdx07_
 - Release LIGHTCOMMAND
 - QQGroup 228229419
 - Function NewTpa
 - Version 2.0B2(1.0Rebuild)

[0] 欢迎使用 LIGHTCOMMAND-NewTpa-System 这是一个完全免费的系统
[1] 这是一个完整的函数功能包,如果您不知道函数如何使用,还请学习后再来使用本系统
[2] 本函数可实现输入玩家UID传送功能 可多人同时使用
[3] 默认玩家编号计分板 uid
[4] 函数初始化命令 function tpa:init
[5] 函数默认执行频率 1tick 如需修改执行频率,请在 tpa:condition/selectSubjectSuccess 中修改 tpaTime计分板的 600 为其他数值
[6] 函数主包 tpa 文件夹请放置于 functions 文件夹第一层
[7] 函数思路设计 欢欣
[8] NewTpa 1.0 原作者:欢欣 重构:Cvdx07