
scoreboard players reset @e[tag=tpa.armor,type=armor_stand] tpa.nop
execute @a ~ ~ ~ scoreboard players add @e[tag=tpa.armor,type=armor_stand] tpa.nop 1

function tpa:condition/nopDeficiency unless @e[tag=tpa.armor,type=armor_stand,score_tpa.nop_min=2]
function tpa:condition/nopEnough if @e[tag=tpa.armor,type=armor_stand,score_tpa.nop_min=2]