
scoreboard players tag @s remove tpa.tping

scoreboard players reset @s tpaID
scoreboard players reset @s tpaID2
scoreboard players reset @s tpaUID1
scoreboard players reset @s tpaTime

scoreboard players set @s tpa.left 0
tellraw @s "§b§l[Tpa] §f传送申请重置完成"