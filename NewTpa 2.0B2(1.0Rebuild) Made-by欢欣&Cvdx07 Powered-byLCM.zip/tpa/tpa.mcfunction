
tellraw @s[tag=tpa.tping] "§b§l[Tpa] §7难道你想拆成两半传送吗?"
scoreboard players set @s[tag=tpa.tping] tpa 0

function tpa:tpaStart if @s[tag=!tpa.tping]

scoreboard players enable @s tpa