
tellraw @s "§b§l[Tpa] §7您的传送请求已超时"

scoreboard players tag @s remove tpa.tping

scoreboard players reset @s tpaID2
scoreboard players reset @s tpaUID1
scoreboard players reset @s tpaTime