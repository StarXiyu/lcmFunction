
function tpa:noNumber if @s[score_tpaID=0]

function tpa:numberList if @s[score_tpaID_min=1]