
tellraw @s "§b§l[Tpa] §7你想原地传送吗?"
scoreboard players tag @s remove temp.tpa.selected