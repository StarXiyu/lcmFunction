
tellraw @s "§b§l[Tpa] §7孤独的朋友啊,你想传送到哪里去啊"

scoreboard players set @s tpa 0