## 执行者:传送申请者
## 将传送被申请者的uid储存到传送申请者的计分板上,并赋值传送序列

scoreboard players operation @s tpaUID1 = @a[tag=temp.tpa.selected] uid

scoreboard players add @a[tag=temp.tpa.selected] tpaID 1
scoreboard players operation @s tpaID2 = @a[tag=temp.tpa.selected] tpaID

tellraw @s [{"text":"[Tpa]","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 您已成功向 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[tag=temp.tpa.selected]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 发送传送申请,请耐心等待对方处理","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"(时间限制:30s)","color":"yellow","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]

tellraw @a[tag=temp.tpa.selected] [{"text":"[","color":"dark_gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"tpaID2","name":"@s"},"color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"dark_gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":">> ","color":"dark_gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 申请传送到您的身边","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" [同意]","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger tda set 1"},"hoverEvent":{"action":"show_text","value":"点击同意传送申请"}},{"text":"  [拒绝]","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger tda set 2"},"hoverEvent":{"action":"show_text","value":"点此拒绝传送申请"}},{"text":"\n(每次处理请求将会从列表最后一个处理,依次向上)","color":"gray","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard players enable @a[tag=temp.tpa.selected] tda

scoreboard players tag @a[tag=temp.tpa.selected] remove temp.tpa.selected
scoreboard players tag @s add tpa.tping

scoreboard players set @s tpaTime 600