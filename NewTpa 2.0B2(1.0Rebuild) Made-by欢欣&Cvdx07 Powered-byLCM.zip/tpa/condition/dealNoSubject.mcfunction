
tellraw @s "§b§l[Tpa] §7未查找到该序列所对应的玩家"

scoreboard players tag @a[tag=temp.tpa.deal.flagA] remove temp.tpa.deal.flagA
scoreboard players remove @s tpaID 1

function tpa:nextNumber