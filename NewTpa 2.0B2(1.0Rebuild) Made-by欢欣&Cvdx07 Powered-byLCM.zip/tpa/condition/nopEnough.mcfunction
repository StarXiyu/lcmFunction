
execute @a ~ ~ ~ scoreboard players operation @s tpauid = @s uid
scoreboard players operation @a tpauid -= @s tpa
scoreboard players tag @a[score_tpauid=0,score_tpauid_min=0] add temp.tpa.selected

function tpa:condition/selectNoSubject unless @a[tag=temp.tpa.selected]
function tpa:condition/selectSubjectMyself if @s[tag=temp.tpa.selected]
function tpa:condition/selectSubjectSuccess if @p[tag=temp.tpa.selected]

scoreboard players set @s tpa 0