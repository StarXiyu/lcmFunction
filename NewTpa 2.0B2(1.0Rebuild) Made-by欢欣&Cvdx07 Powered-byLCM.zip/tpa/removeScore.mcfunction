
scoreboard players remove @a[score_tpaTime_min=1] tpaTime 1
execute @a[score_tpaTime=0] ~ ~ ~ function tpa:timeOut