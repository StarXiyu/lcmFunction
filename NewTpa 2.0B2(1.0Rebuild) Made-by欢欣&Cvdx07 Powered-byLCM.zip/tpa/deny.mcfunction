
tellraw @s [{"text":"[Tpa]","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 您已拒绝 ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@p[tag=temp.tpa.deal.flagB]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 的传送申请","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

tellraw @a[tag=temp.tpa.deal.flagB] [{"text":"[Tpa] ","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 拒绝了您的传送申请","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard players remove @s tpaID 1

scoreboard players reset @a[tag=temp.tpa.deal.flagB] tpaTime
scoreboard players reset @a[tag=temp.tpa.deal.flagB] tpaID2
scoreboard players reset @a[tag=temp.tpa.deal.flagB] tpaUID1

scoreboard players tag @a[tag=temp.tpa.deal.flagB] remove tpa.tping

scoreboard players tag @a[tag=temp.tpa.deal.flagA] remove temp.tpa.deal.flagA
scoreboard players tag @a[tag=temp.tpa.deal.flagB] remove temp.tpa.deal.flagB

function tpa:nextNumber