
execute @a[tag=tpa.tping] ~ ~ ~ scoreboard players operation @s tpaid = @s tpaID2
scoreboard players operation @a[tag=tpa.tping] tpaid -= @s tpaID
scoreboard players tag @a[tag=tpa.tping,score_tpaid=0,score_tpaid_min=0] add temp.tpa.list.flagA

execute @a[tag=temp.tpa.list.flagA] ~ ~ ~ scoreboard players operation @s tpauid = @s tpaUID1
scoreboard players operation @a[tag=temp.tpa.list.flagA] tpauid -= @s uid
scoreboard players tag @a[tag=temp.tpa.list.flagA,score_tpauid=0,score_tpauid_min=0] add temp.tpa.list.flagB

function tpa:nextNumber_noExist unless @a[tag=temp.tpa.list.flagB]
function tpa:nextNumber_Exist if @a[tag=temp.tpa.list.flagB]