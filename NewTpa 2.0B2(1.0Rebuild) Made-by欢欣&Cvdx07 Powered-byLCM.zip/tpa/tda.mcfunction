
## 寻找该序列所对应的玩家
	## 被申请者: tpaID
	## 申请者: tpaID2
	
execute @a[tag=tpa.tping] ~ ~ ~ scoreboard players operation @s tpaid = @s tpaID2
scoreboard players operation @a[tag=tpa.tping] tpaid -= @s tpaID
scoreboard players tag @a[tag=tpa.tping,score_tpaid=0,score_tpaid_min=0] add temp.tpa.deal.flagA

execute @a[tag=temp.tpa.deal.flagA] ~ ~ ~ scoreboard players operation @s tpauid = @s tpaUID1
scoreboard players operation @a[tag=temp.tpa.deal.flagA] tpauid -= @s uid
scoreboard players tag @a[tag=temp.tpa.deal.flagA,score_tpauid=0,score_tpauid_min=0] add temp.tpa.deal.flagB

function tpa:condition/dealNoSubject unless @a[tag=temp.tpa.deal.flagB]

execute @s[score_tda_min=1,score_tda=1] ~ ~ ~ function tpa:accept if @p[tag=temp.tpa.deal.flagB]
execute @s[score_tda_min=2,score_tda=2] ~ ~ ~ function tpa:deny if @p[tag=temp.tpa.deal.flagB]

scoreboard players set @s tda 0
scoreboard players enable @s tda