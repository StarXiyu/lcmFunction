
tellraw @s "§b§l[Tpa] §f您的传送序列已结束"

scoreboard players reset @s tpaID