
scoreboard objectives add tpa trigger
scoreboard objectives add tda trigger
scoreboard objectives add tpa.nop dummy
scoreboard objectives add tpauid dummy
scoreboard objectives add tpaid dummy
scoreboard objectives add tpaTime dummy

scoreboard objectives add tpaUID1 dummy
scoreboard objectives add tpaID dummy
scoreboard objectives add tpaID2 dummy

scoreboard objectives add tpa.left stat.leaveGame

summon minecraft:armor_stand ~ ~1 ~ {CustomName:"§ftpa.armor §e此盔甲架用于调用函数,请勿切除!",Tags:["tpa.armor"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}

tellraw @a " "
tellraw @a "§f§l| LIGHTCOMMAND FUNCTION"
tellraw @a "§7 - Thank you for you choosing LIGHTCOMMAND_FUNCTION"
tellraw @a "§7 - FUNCTION §e§lNewTpa"
tellraw @a "§7 - Design §e§l欢欣"
tellraw @a "§7 - Dev §e§lCvdx07"
tellraw @a "§7 - Version §e§l2.0B2(1.0Rebuild)"
tellraw @a " "