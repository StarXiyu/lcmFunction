
scoreboard players tag @a[tag=temp.tpa.list.flagB] remove temp.tpa.list.flagB
scoreboard players tag @a[tag=temp.tpa.list.flagA] remove temp.tpa.list.flagA

scoreboard players remove @s tpaID 1
function tpa:nextNumber