
execute @p[score_tpa.left_min=1] ~ ~ ~ function tpa:left

execute @p[score_tpa_min=1] ~ ~ ~ function tpa:tpa
execute @p[score_tda_min=1] ~ ~ ~ function tpa:tda

function tpa:removeScore if @p[score_tpaTime_min=1]