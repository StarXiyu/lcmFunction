scoreboard objectives add ldgx trigger
scoreboard objectives add ldgx.ap trigger
scoreboard objectives add ldgxmin dummy
scoreboard objectives add ldgxuid dummy
scoreboard objectives add ldgx人数检测 dummy
scoreboard objectives add ldgx.left dummy
summon minecraft:armor_stand ~ ~1 ~ {CustomName:"ldgx.armor §e此盔甲架用于调用系统,切勿清除!",Tags:["ldgx.armor"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
tellraw @a [{"text":"§aTpa初始化完成 §ebyStarXiyu"}]
setblock ~ ~ ~ minecraft:repeating_command_block 0 replace {Command:"function ldgx:main",auto:true}