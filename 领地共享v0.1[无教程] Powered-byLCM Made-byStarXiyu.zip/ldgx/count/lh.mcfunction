scoreboard players reset @e[tag=ldgx.armor] ldgx
execute @a ~ ~ ~ scoreboard players add @e[tag=ldgx.armor] ldgx人数检测 1

function ldgx:count/pun unless @e[tag=ldgx.armor,score_ldgx人数检测_min=2]
function ldgx:count/penough if @e[tag=ldgx.armor,score_ldgx人数检测_min=2]

scoreboard players set @s ldgx 0