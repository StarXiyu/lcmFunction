scoreboard players set @a ldgx.ap 0
execute @a ~ ~ ~ scoreboard players operation @s ldgxuid = @s uid
scoreboard players operation @a ldgxuid -= @s ldgx
scoreboard players tag @s add 共享者
scoreboard players set @s ldgxmin 2

function ldgx:chose/1