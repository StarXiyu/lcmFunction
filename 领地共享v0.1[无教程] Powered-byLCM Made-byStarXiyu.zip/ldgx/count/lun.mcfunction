tellraw @s [{"text":"§b领地共享 §8>> §c你还没有领地呢!"}]

scoreboard players set @s ldgx 0