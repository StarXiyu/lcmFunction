execute @s ~ ~ ~ function ldgx:count/lh if @s[tag=主人]

execute @s ~ ~ ~ function ldgx:count/lun unless @s[tag=主人]