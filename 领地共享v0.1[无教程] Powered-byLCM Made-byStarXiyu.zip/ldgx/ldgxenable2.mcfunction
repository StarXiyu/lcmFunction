execute @s[score_ldgxmin_min=2] ~ ~ ~ scoreboard players remove @e[tag=ldgx.armor] ldgxmin 1

execute @e[tag=ldgx.armor] ~ ~ ~ function ldgx:time unless @s[score_ldgxmin_min=0]

scoreboard players add @e[tag=ldgx.armor] ldgx.left 1