scoreboard objectives add ldgx.temp.i dummy

execute @e[tag=ldgx.armor] ~ ~ ~ scoreboard players add @s ldgx.temp.i 1

function ldgx:information/1 if @e[score_ldgx.temp.i_min=1]
function ldgx:information/2 unless @e[score_ldgx.temp.i_min=1]

scoreboard objectives remove ldgx.temp.i