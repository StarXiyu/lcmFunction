scoreboard players enable @a ldgx
scoreboard players enable @a ldgx.ap

execute @a[score_ldgx_min=1] ~ ~ ~ function ldgx:ldgx
execute @a[score_ldgxmin=1,score_ldgxmin_min=1] ~ ~ ~ execute @s[score_ldgx.ap_min=1] ~ ~ ~ function ldgx:chose/4

function ldgx:ldgxenable

# byStarXiyu
# 未经允许,禁止发布
# 出品:LightCommand
# 群号:245684797