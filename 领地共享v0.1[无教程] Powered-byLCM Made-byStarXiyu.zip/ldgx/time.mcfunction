tellraw @a[score_ldgxmin=2,score_ldgxmin_min=2] [{"text":"§b领地共享 §8>> §7你的领地共享请求已§c超时"}]

function ldgx:reset