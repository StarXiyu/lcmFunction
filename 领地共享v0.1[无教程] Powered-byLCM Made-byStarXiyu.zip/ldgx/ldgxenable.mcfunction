scoreboard players reset @e[tag=ldgx.armor] ldgx.left
execute @a[score_ldgxmin_min=1] ~ ~ ~ function ldgx:ldgxenable2

execute @e[tag=ldgx.armor,score_ldgxmin_min=0] ~ ~ ~ function ldgx:reset2 unless @s[score_ldgx.left_min=2,score_ldgx.left=2]