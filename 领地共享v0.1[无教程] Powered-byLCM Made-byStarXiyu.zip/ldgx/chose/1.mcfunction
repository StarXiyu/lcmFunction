scoreboard players tag @a[score_ldgxuid=0,score_ldgxuid_min=0] add 被共享者
scoreboard players set @a[tag=被共享者] ldgxmin 1
execute @a[tag=被共享者] ~ ~ ~ scoreboard players tag @a[tag=共享者] add 共享匹配成功

function ldgx:chose/3 if @s[tag=!共享匹配成功]
function ldgx:chose/2 if @s[tag=被共享者]
function ldgx:ldgx2 if @s[tag=共享匹配成功]