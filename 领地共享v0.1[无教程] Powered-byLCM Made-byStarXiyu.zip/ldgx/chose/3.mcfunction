tellraw @s [{"text":"§b领地共享 §8>> §c查无此人!"}]

scoreboard players set @s ldgxmin 0
scoreboard players tag @s remove 共享者