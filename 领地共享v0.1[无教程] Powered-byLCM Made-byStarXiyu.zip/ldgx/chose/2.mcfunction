tellraw @s [{"text":"§b领地共享 §8>> §e您搁这原地共享呢?"}]
scoreboard players set @s ldgxmin 0
scoreboard players tag @s remove 共享者
scoreboard players tag @s remove 被共享者
scoreboard players tag @s remove 共享匹配成功