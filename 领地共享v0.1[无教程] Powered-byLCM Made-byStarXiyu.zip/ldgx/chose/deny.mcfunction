tellraw @s [{"text":"§b领地共享 §8>> §7您已成功§c拒绝 "},{"selector":"@a[score_ldgxmin=2,score_ldgxmin_min=2]","color":"yellow"},{"text":"§7 的领地共享请求"}]
tellraw @a[score_ldgxmin=2,score_ldgxmin_min=2] [{"text":"§b领地共享 §8>> "},{"selector":"@s","color":"yellow"},{"text":"§c 拒绝§7了你的传送请求并向你丢了一只§a夕羽"}]

function ldgx:reset