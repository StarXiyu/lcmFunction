tp @a[score_ldgxmin_min=2,score_ldgxmin=2] @s
tellraw @s [{"text":"§b领地共享 §8>> §7您已成功§a接受 "},{"selector":"@a[score_ldgxmin=2,score_ldgxmin_min=2]","color":"yellow"},{"text":"§7 的领地共享请求"}]
tellraw @a[score_ldgxmin=2,score_ldgxmin_min=2] [{"text":"§bTpa §8>> "},{"selector":"@s","color":"yellow"},{"text":"§7 已§a接受§7你的领地共享请求"}]
scoreboard players operation @s lcm.领地进程 = StarCloud_Xiyu lcm.领地进程
function ldgx:reset