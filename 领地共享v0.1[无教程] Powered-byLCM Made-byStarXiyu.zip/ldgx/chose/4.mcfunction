function ldgx:chose/deny if @s[score_ldgx.ap_min=2,score_ldgx.ap=2]
function ldgx:chose/accept if @s[score_ldgx.ap_min=1,score_ldgx.ap=1]

scoreboard players set @s ldgx.ap 0