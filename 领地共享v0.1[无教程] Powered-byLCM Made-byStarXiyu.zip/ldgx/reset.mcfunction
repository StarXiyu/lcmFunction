scoreboard players reset * ldgxmin
scoreboard objectives add ldgx trigger
scoreboard players reset @a ldgxuid
tellraw @a [{"text":"§b领地共享 §8>> §7上一位领地共享者已经§e结束使用§7,现在互传可以§a正常使用"}]