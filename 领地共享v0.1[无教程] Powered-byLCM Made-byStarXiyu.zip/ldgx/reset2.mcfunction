tellraw @a [{"text":"§b领地共享 §8>> §7由于§e多人同时使用互传§7或§c互传任意一方离线§7,互传已被截停!"}]

scoreboard players reset * ldgxmin
scoreboard objectives add ldgx trigger
scoreboard players reset * ldgxuid
tellraw @a [{"text":"§b领地共享 §8>> §7上一位领地共享者已经§e结束使用§7,现在互传可以§a正常使用"}]