scoreboard players operation @s bantime = main_time bantime
scoreboard players operation @s bantime += 2m bantime
function system:admin/tempban/kick