scoreboard players operation @s bantime = main_time bantime
scoreboard players operation @s bantime += 1m bantime
function system:admin/tempban/kick