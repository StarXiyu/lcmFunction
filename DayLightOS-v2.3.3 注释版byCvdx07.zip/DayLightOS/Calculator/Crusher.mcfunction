
scoreboard players add @s[score_ServerLag_min=25] Crusher 8
scoreboard players add @s[score_ServerLag_min=30] Crusher 2
scoreboard players add @s[score_ServerLag_min=35] Crusher 5
scoreboard players add @s[score_ServerLag_min=40] Crusher 5
scoreboard players add @s[score_ServerLag_min=45] Crusher 5
function DayLightOS:AntiCrusher/main if @s[score_Crusher_min=30]
function DayLightOS:AntiCrusher/main if @s[score_ServerLag_min=50]

# 对于崩服者检测的策略判定这里不做展开分析
# 值得一提的是DayLightOS对于短时间内多延迟的崩服也有预案
# 不愧是我xiyu教出来的呵呵
# 但是我觉得逻辑没我写得好