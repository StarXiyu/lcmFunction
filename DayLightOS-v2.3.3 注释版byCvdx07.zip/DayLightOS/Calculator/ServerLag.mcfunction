
## 计算
scoreboard players operation @s ServerLag = @s border
# border = 200w+20
scoreboard players operation @s ServerLag -=  border
# ticks一直在主循环内增加，而边界达到20格后才会进入这个函数，也就是说1秒后这个函数执行，每秒计算一次边界和tick的差值，以此来判定卡顿延迟

## 校准时间
scoreboard players operation @s time.tick += @s ServerLag
# 时间校准

##! 不得不说此处对于北京时间校准的处理比LightOS的逻辑好

## 提醒
function DayLightOS:Calculator/info if @s[score_ServerLag_min=20]
# 延迟提醒

## 检测崩服
function DayLightOS:Calculator/Crusher if @s[score_ServerLag_min=25]
# 延迟超过25tick检测崩服

## 计算TPS
scoreboard players set TPS ServerLag 20
function DayLightOS:Calculator/TPSCalculator if @s[score_ServerLag_min=1]
# TPS计算

## 初始化
function DayLightOS:ServerLagTest/init
# 重置边界