
# @param
#   ticks: 实际经过的tick数
#   Original: 标记的边界初始格数
#   Border: 现在的边界格数

scoreboard players operation Border ServerLag = @s border
# border
scoreboard players operation Border ServerLag -= Original ServerLag
# Original在import中被定义为200w

scoreboard players operation ticks ServerLag = ticks border
scoreboard players operation ticks ServerLag -= Original ServerLag
# ticks在主循环中被增加 从200w开始站在主循环内+1 每次都会被init重置回200w

scoreboard players operation TPS ServerLag *= ticks ServerLag
scoreboard players operation TPS ServerLag /= Border ServerLag
# 利用计划刻数除以当前刻数得到TPS [这是从定义出发获取的TPS]
# 实际利用相减运算是同样的结果
# 但是需要在负数结果的基础上进行*-1操作