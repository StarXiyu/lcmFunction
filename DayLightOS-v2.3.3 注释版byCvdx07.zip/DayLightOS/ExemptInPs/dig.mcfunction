scoreboard players add @a[score_DigCount_min=500] ExemptInPs 1
scoreboard players remove @a[score_DigCount_min=500] DigCount 500s