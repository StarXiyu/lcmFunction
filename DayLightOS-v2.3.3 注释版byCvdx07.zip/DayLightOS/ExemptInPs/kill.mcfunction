scoreboard players add @a[score_KillEntity_min=50] ExemptInPs 1
scoreboard players remove @a[score_KillEntity_min=50] KillEntity 50