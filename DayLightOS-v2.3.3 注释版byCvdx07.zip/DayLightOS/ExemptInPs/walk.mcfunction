scoreboard players add @a[score_Movement_min=70000] ExemptInPs 1
scoreboard players remove @a[score_Movement_min=70000] Monement 70000
# 每到7w移动值加ExemptInPs 1