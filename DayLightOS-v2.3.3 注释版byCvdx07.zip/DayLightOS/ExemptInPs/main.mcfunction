
function DayLightOS:ExemptInPs/walk if @a[score_Movement_min=70000]
function DayLightOS:ExemptInPs/kill if @a[score_KillEntity_min=50]
function DayLightOS:ExemptInPs/dig if @a[score_DigCount_min=500]
# 策略判定 - 活跃值检测

scoreboard players tag @a[score_ExemptInPs_min=10,tag=!pb] add pb
scoreboard players tag @a[score_PlayTimeTK_min=360000,tag=!pb] add pb
# 游戏时间5h / 活跃值达到10+白名单