
## 2025.9.1
## DayLightOS-Cracked byCvdx07

## 现实时间
function DayLightOS:ServerLagTest/get

## 计算延迟
execute @e[type=armor_stand,tag=datatps,score_border_min=20000020] ~ ~ ~ function DayLightOS:Calculator/ServerLag
# 检测到延迟增幅超过20格，即过去1秒后，还原边界并开始判定

scoreboard players remove @e[type=armor_stand,tag=datatps,score_Crusher_min=1] Crusher 1
scoreboard players remove @e[type=armor_stand,tag=datatps,score_LagTimeDelta_min=1] LagTimeDelta 1

function DayLightOS:ExemptInPs/main
# 策略判定