﻿##现实时间.
scoreboard objectives add border dummy 
##崩服点.
scoreboard objectives add Crusher dummy 
##延迟.
scoreboard objectives add ServerLag dummy
##玩家数量.
scoreboard objectives add ToTalCount dummy
##计算延迟时差.
scoreboard objectives add LagTimeDelta dummy
##免检计算
scoreboard objectives add Movement stat.sprintOneCm
scoreboard objectives add KillEntity stat.mobKills
scoreboard objectives add DigCount stat.mineBlock.minecraft.diamond_ore
scoreboard objectives add PlayTimeTK stat.playOneMinute
##免检分
scoreboard objectives add ExemptInPs dummy
##计算最低
scoreboard objectives add LastSelect dummy
scoreboard objectives add SelectSave dummy
##计算挂机
scoreboard objectives add WalkDelta stat.walkOneCm
scoreboard objectives add LeaveTime dummy
##延迟秒
scoreboard objectives add Lag.1 dummy 
scoreboard objectives add Lag.2 dummy

summon minecraft:armor_stand ~1 ~ ~ {CustomName:"§e§lBORDER§7(此盔甲架用于调用系统，请勿清除)",Tags:["datatps"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
setblock ~ ~0 ~ minecraft:repeating_command_block 1 replace {Command:"/function DayLightOS:main",CustomName:"§4§lOS",auto:true}
scoreboard players set ticks border 20000001
scoreboard players set @e[tag=datatps] border 1
scoreboard players set NorMalTPS ServerLag 20
scoreboard players set Original ServerLag 20000000
scoreboard players set n5 ServerLag 5
scoreboard players set 1m bantime 1200
scoreboard players set 2m bantime 2400
scoreboard players set 3m bantime 3600