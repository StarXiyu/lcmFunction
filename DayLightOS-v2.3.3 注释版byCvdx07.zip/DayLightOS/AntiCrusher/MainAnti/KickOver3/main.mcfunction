execute @a[score_ExemptInPs=3] ~ ~ ~ function DayLightOS:TempBanTimeSet/3
function DayLightOS:AntiCrusher/MainAnti/KickOver3/LastExemptInPsSelect/main if @a[tag=!排除,score_PlayTimeTK_min=2400]