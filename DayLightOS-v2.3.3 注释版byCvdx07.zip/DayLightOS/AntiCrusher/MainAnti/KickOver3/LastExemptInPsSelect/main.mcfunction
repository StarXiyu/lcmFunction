scoreboard players reset @a SelectSave
execute @a[tag=!排除,score_PlayTimeTK_min=2400] ~ ~ ~ scoreboard players operation @s SelectSave = @s ExemptInPs
function DayLightOS:AntiCrusher/MainAnti/KickOver3/LastExemptInPsSelect/Select
function DayLightOS:AntiCrusher/MainAnti/KickOver3/LastExemptInPsSelect/Select
function DayLightOS:AntiCrusher/MainAnti/KickOver3/LastExemptInPsSelect/Select