scoreboard players reset @a LastSelect
execute @a[tag=!排除,score_PlayTimeTK_min=2400] ~ ~ ~ scoreboard players operation WorldLastScore LastSelect > @s SelectSave
execute @a[tag=!排除,score_PlayTimeTK_min=2400] ~ ~ ~ scoreboard players operation @s LastSelect = @s SelectSave
execute @a[tag=!排除,score_PlayTimeTK_min=2400] ~ ~ ~ scoreboard players operation @s LastSelect -= WorldLastScore LastSelect
execute @a[tag=!排除,score_PlayTimeTK_min=2400,score_LastSelect=0,score_LastSelect_min=0] ~ ~ ~ function DayLightOS:AntiCrusher/MainAnti/KickOver3/LastExemptInPsSelect/Complete 