scoreboard players reset @s SelectSave
scoreboard players reset @s LastSelect
function DayLightOS:TempBanTimeSet/3