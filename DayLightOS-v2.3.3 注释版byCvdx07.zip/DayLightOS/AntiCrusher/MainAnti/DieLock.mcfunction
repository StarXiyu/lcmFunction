##踢在线时间2~40min的所有人封3分钟 40~80min的封2分钟 80~150min的封1分钟 150~300min的纯踢(白名单无法防踢)
execute @a[score_PlayTimeTK_min=2401,score_PlayTimeTK=48000] ~ ~ ~ function DayLightOS:TempBanTimeSet/3
execute @a[score_PlayTimeTK_min=48001,score_PlayTimeTK=96000] ~ ~ ~ function DayLightOS:TempBanTimeSet/2
execute @a[score_PlayTimeTK_min=96001,score_PlayTimeTK=180000] ~ ~ ~ function DayLightOS:TempBanTimeSet/1
execute @a[score_PlayTimeTK_min=180001,score_PlayTimeTK=360000] ~ ~ ~ function system:admin/tempban/kick
