function DayLightOS:AntiCrusher/MainAnti/playerCount
function DayLightOS:AntiCrusher/MainAnti/KickL2 if @s[score_ToTalCount=2]
function DayLightOS:AntiCrusher/MainAnti/KickOver3/main

