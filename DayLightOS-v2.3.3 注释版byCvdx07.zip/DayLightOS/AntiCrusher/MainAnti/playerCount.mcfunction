scoreboard players set @s ToTalCount 0
execute @a[tag=!排除,score_PlayTimeTK_min=2400] ~ ~ ~ scoreboard players add @e[tag=datatps,type=armor_stand] ToTalCount 1