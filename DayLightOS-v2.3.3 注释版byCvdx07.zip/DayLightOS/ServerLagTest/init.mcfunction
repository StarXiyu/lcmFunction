worldborder set 20000000 0
worldborder add 6000 300
scoreboard players set ticks border 20000000