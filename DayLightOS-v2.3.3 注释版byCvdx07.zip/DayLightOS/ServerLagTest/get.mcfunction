

stats entity @e[type=armor_stand,tag=datatps] set QueryResult @e[type=armor_stand,tag=datatps] border
# 绑定stas
execute @e[type=armor_stand,tag=datatps] ~ ~ ~ worldborder get
# 运行边界
scoreboard players add ticks border 1
# 增加ticks值1