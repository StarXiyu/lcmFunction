1.尊重知识产权,切勿私自传播,仅供学习参考使用
2.系统设计者欢欣
3.cracked实质是对DayLightOS系统的部分函数加以注释方便理解
4.cracked by Cvdx07(LightOS-Dev)
5.DayLightOS实质是LightOS的孪生版本