scoreboard players add @s[score_time.tick_min=20] time.second 1
scoreboard players remove @s[score_time.tick_min=20] time.tick 20