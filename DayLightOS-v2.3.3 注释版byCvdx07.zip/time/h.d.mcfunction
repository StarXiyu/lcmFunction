scoreboard players add @s[score_time.hour_min=24] time.day 1
scoreboard players remove @s[score_time.hour_min=24] time.hour 24