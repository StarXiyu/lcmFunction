function time:t.s if @s[score_time.tick_min=20]
function time:s.min if @s[score_time.second_min=60]
function time:min.h if @s[score_time.minute_min=60]
function time:h.d if @s[score_time.hour_min=24]
function time:d.m/main
function time:m.y if @s[score_time.month_min=12]