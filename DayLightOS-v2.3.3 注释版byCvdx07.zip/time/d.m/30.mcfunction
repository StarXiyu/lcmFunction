scoreboard players add @s[score_time.day_min=30,score_time.day=30] time.month 1
scoreboard players remove @s[score_time.day_min=30,score_time.day=30] time.day 30