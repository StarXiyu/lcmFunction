scoreboard players add @s[score_time.day_min=28,score_time.day=28] time.month 1
scoreboard players remove @s[score_time.day_min=28,score_time.day=28] time.day 28