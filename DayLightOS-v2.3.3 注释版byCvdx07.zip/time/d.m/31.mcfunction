scoreboard players add @s[score_time.day_min=31,score_time.day=31] time.month 1
scoreboard players remove @s[score_time.day_min=31,score_time.day=31] time.day 31