scoreboard players set @e[tag=datatps,type=armor_stand] time.hour 23
scoreboard players set @e[tag=datatps,type=armor_stand] time.minute 59
scoreboard players set @e[tag=datatps,type=armor_stand] time.second 59
scoreboard players set @e[tag=datatps,type=armor_stand] time.tick 18
scoreboard players reset * ExemptInPs
