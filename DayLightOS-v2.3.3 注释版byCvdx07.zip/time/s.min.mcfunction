scoreboard players add @s[score_time.second_min=60] time.minute 1
scoreboard players remove @s[score_time.second_min=60] time.second 60
