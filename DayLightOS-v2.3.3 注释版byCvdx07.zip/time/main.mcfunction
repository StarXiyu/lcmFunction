scoreboard players add @e[tag=datatps,type=armor_stand] time.tick 1
execute @e[tag=datatps,type=armor_stand] ~ ~ ~ function time:transfer