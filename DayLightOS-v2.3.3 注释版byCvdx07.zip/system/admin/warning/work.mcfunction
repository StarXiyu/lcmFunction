execute @a[score_warning_min=1] ~ ~ ~ execute @a ~ ~ ~ scoreboard players operation @s uid_choose = @s uid
execute @a[score_warning_min=1] ~ ~ ~ scoreboard players operation @a uid_choose -= @s warning
function system:admin/warning/warn if @a[score_uid_choose_min=0,score_uid_choose=0]
function system:admin/warning/lost unless @a[score_uid_choose_min=0,score_uid_choose=0]