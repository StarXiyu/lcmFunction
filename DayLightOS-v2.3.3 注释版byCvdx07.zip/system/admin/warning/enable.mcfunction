scoreboard players enable @a[tag=admin] warning
function system:admin/warning/work if @a[score_warning_min=1]