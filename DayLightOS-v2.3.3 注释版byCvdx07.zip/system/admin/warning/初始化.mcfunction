scoreboard players reset @a warning
scoreboard players reset @a uid_choose
scoreboard players tag @a remove 被警告