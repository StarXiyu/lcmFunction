scoreboard players operation @s uid_choose = @s bantime
scoreboard players operation @s uid_choose -= main_time bantime
function system:admin/tempban/auto_pardon if @s[score_uid_choose=0]
function system:admin/tempban/ban unless @s[score_uid_choose=0]


