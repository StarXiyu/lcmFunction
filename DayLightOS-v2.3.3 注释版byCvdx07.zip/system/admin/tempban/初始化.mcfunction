scoreboard players reset @s tempban
scoreboard players reset @s uid_choose
scoreboard players reset @s tempset
scoreboard players reset @s settime
scoreboard players tag @s remove 输入中
trigger tempset set 0