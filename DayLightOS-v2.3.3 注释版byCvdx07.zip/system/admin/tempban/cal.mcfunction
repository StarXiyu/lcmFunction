function system:admin/tempban/text
scoreboard players set n1200 tempset 1200
scoreboard players operation @a[score_uid_choose_min=0,score_uid_choose=0] bantime = main_time bantime
scoreboard players operation @s tempset *= n1200 tempset
scoreboard players operation @a[score_uid_choose_min=0,score_uid_choose=0] bantime += @s tempset
function system:admin/tempban/初始化