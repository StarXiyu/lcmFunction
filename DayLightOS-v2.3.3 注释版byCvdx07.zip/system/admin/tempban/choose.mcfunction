execute @a[score_tempban_min=1] ~ ~ ~ execute @a ~ ~ ~ scoreboard players operation @s uid_choose = @s uid
execute @a[score_tempban_min=1] ~ ~ ~ scoreboard players operation @a uid_choose -= @s tempban
execute @a[score_tempban_min=1] ~ ~ ~ function system:admin/tempban/lost unless @a[score_uid_choose_min=0,score_uid_choose=0]
execute @a[score_tempban_min=1,tag=!输入中] ~ ~ ~ function system:admin/tempban/set if @a[score_uid_choose_min=0,score_uid_choose=0]
