scoreboard players enable @a[tag=admin] tempban
function system:admin/tempban/choose if @a[score_tempban_min=1]