scoreboard players add @a[tag=输入中] settime 1
function system:admin/warning/ban if @a[score_warning_count_min=10]
execute @a[score_bantime_min=-2147483647] ~ ~ ~ function system:admin/tempban/test
function system:admin/warning/enable if @a[tag=admin]
function system:admin/tempban/enable if @a[tag=admin]
execute @a[tag=输入中,score_tempset=-1] ~ ~ ~ function system:admin/tempban/false
execute @a[tag=输入中,score_tempset_min=1] ~ ~ ~ function system:admin/tempban/cal
execute @a[tag=输入中,score_settime_min=60] ~ ~ ~ function system:admin/tempban/notype
scoreboard players add main_time bantime 1