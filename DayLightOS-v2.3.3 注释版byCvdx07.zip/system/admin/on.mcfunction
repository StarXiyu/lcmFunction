scoreboard objectives add warning trigger
scoreboard objectives add uid_choose dummy
scoreboard objectives add warning_count dummy
scoreboard objectives add tempban trigger
scoreboard objectives add tempset trigger
scoreboard objectives add bantime dummy
scoreboard objectives add settime dummy
setblock ~ ~1 ~ minecraft:repeating_command_block 0 replace {Command:"/function system:admin/main",CustomName:"§e§ladmin_",auto:true}

tellraw @a [{"text":"§7§lWelcome to use §e§l§oADMIN-SYSTEM"}]
tellraw @a [{"text":"§7§lMade BY: §d§l§oHuanxin_miao"}]
tellraw @a [{"text":"§7§lQun: §3§l7-1-4-8-3-3-6-9-8"}]
tellraw @a [{"text":"§7§lType:"},{"text":"/scoreboard players tag @s add admin","color":"green","bold":true,"italic":false,"underlined":true,"strikethrough":false,"obfuscated":false,"insertion":"/scoreboard players tag @s add admin","hoverEvent":{"action":"show_text","value":"§a§ltype and copy"}},{"text":" §7§l 获取指令使用权限"}]
tellraw @a [{"text":"§7§lType:"},{"text":"/scoreboard players tag @s add op","color":"green","bold":true,"italic":false,"underlined":true,"strikethrough":false,"obfuscated":false,"insertion":"/scoreboard players tag @s add op","hoverEvent":{"action":"show_text","value":"§a§ltype and copy"}},{"text":" §7§l 防止自己被其他op封禁"}]
