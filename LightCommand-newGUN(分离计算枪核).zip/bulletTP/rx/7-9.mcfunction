function gun:bulletTP/rx/7-8 if @s[score_rx=8,score_rx_min=7]
function gun:bulletTP/rx/9-9 if @s[score_rx=9,score_rx_min=9]