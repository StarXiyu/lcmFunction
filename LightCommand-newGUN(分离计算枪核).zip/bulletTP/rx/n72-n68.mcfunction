function gun:bulletTP/rx/n72-n70 if @s[score_rx=-70,score_rx_min=-72]
function gun:bulletTP/rx/n69-n68 if @s[score_rx=-68,score_rx_min=-69]