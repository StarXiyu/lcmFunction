function gun:bulletTP/rx/exact/n32 if @s[score_rx=-32,score_rx_min=-32]
function gun:bulletTP/rx/exact/n31 if @s[score_rx=-31,score_rx_min=-31]