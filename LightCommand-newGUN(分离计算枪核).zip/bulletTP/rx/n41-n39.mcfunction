function gun:bulletTP/rx/n41-n40 if @s[score_rx=-40,score_rx_min=-41]
function gun:bulletTP/rx/n39-n39 if @s[score_rx=-39,score_rx_min=-39]