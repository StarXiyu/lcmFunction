function gun:bulletTP/rx/n32-n31 if @s[score_rx=-31,score_rx_min=-32]
function gun:bulletTP/rx/n30-n30 if @s[score_rx=-30,score_rx_min=-30]