function gun:bulletTP/rx/exact/n26 if @s[score_rx=-26,score_rx_min=-26]
function gun:bulletTP/rx/exact/n25 if @s[score_rx=-25,score_rx_min=-25]