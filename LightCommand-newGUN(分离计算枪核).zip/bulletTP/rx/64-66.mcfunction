function gun:bulletTP/rx/64-65 if @s[score_rx=65,score_rx_min=64]
function gun:bulletTP/rx/66-66 if @s[score_rx=66,score_rx_min=66]