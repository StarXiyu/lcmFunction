function gun:bulletTP/rx/exact/n15 if @s[score_rx=-15,score_rx_min=-15]
function gun:bulletTP/rx/exact/n14 if @s[score_rx=-14,score_rx_min=-14]