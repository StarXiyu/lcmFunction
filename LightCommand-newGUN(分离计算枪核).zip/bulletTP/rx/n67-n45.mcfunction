function gun:bulletTP/rx/n67-n56 if @s[score_rx=-56,score_rx_min=-67]
function gun:bulletTP/rx/n55-n45 if @s[score_rx=-45,score_rx_min=-55]