function gun:bulletTP/rx/exact/n7 if @s[score_rx=-7,score_rx_min=-7]
function gun:bulletTP/rx/exact/n6 if @s[score_rx=-6,score_rx_min=-6]