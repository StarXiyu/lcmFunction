function gun:bulletTP/rx/n4-n2 if @s[score_rx=-2,score_rx_min=-4]
function gun:bulletTP/rx/n1-0 if @s[score_rx=0,score_rx_min=-1]