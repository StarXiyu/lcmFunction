function gun:bulletTP/rx/exact/69 if @s[score_rx=69,score_rx_min=69]
function gun:bulletTP/rx/exact/70 if @s[score_rx=70,score_rx_min=70]