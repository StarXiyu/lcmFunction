function gun:bulletTP/rx/13-15 if @s[score_rx=15,score_rx_min=13]
function gun:bulletTP/rx/16-18 if @s[score_rx=18,score_rx_min=16]