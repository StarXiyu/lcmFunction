function gun:bulletTP/rx/n78-n76 if @s[score_rx=-76,score_rx_min=-78]
function gun:bulletTP/rx/n75-n73 if @s[score_rx=-73,score_rx_min=-75]