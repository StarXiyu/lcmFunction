function gun:bulletTP/rx/exact/n61 if @s[score_rx=-61,score_rx_min=-61]
function gun:bulletTP/rx/exact/n60 if @s[score_rx=-60,score_rx_min=-60]