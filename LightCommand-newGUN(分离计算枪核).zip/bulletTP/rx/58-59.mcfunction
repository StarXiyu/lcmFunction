function gun:bulletTP/rx/exact/58 if @s[score_rx=58,score_rx_min=58]
function gun:bulletTP/rx/exact/59 if @s[score_rx=59,score_rx_min=59]