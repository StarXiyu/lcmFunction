function gun:bulletTP/rx/58-60 if @s[score_rx=60,score_rx_min=58]
function gun:bulletTP/rx/61-63 if @s[score_rx=63,score_rx_min=61]