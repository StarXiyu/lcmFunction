function gun:bulletTP/rx/41-43 if @s[score_rx=43,score_rx_min=41]
function gun:bulletTP/rx/44-45 if @s[score_rx=45,score_rx_min=44]