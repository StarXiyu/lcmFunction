function gun:bulletTP/rx/n44-n42 if @s[score_rx=-42,score_rx_min=-44]
function gun:bulletTP/rx/n41-n39 if @s[score_rx=-39,score_rx_min=-41]