function gun:bulletTP/rx/64-66 if @s[score_rx=66,score_rx_min=64]
function gun:bulletTP/rx/67-68 if @s[score_rx=68,score_rx_min=67]