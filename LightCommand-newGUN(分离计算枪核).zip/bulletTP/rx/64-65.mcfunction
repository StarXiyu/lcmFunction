function gun:bulletTP/rx/exact/64 if @s[score_rx=64,score_rx_min=64]
function gun:bulletTP/rx/exact/65 if @s[score_rx=65,score_rx_min=65]