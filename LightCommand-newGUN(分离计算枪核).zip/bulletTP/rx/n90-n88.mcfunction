function gun:bulletTP/rx/n90-n89 if @s[score_rx=-89,score_rx_min=-90]
function gun:bulletTP/rx/n88-n88 if @s[score_rx=-88,score_rx_min=-88]