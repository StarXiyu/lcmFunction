function gun:bulletTP/rx/86-87 if @s[score_rx=87,score_rx_min=86]
function gun:bulletTP/rx/88-88 if @s[score_rx=88,score_rx_min=88]