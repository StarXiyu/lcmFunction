function gun:bulletTP/rx/55-56 if @s[score_rx=56,score_rx_min=55]
function gun:bulletTP/rx/57-57 if @s[score_rx=57,score_rx_min=57]