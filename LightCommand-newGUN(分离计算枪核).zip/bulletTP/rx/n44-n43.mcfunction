function gun:bulletTP/rx/exact/n44 if @s[score_rx=-44,score_rx_min=-44]
function gun:bulletTP/rx/exact/n43 if @s[score_rx=-43,score_rx_min=-43]