function gun:bulletTP/rx/52-53 if @s[score_rx=53,score_rx_min=52]
function gun:bulletTP/rx/54-54 if @s[score_rx=54,score_rx_min=54]