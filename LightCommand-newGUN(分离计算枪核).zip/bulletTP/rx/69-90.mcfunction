function gun:bulletTP/rx/69-79 if @s[score_rx=79,score_rx_min=69]
function gun:bulletTP/rx/80-90 if @s[score_rx=90,score_rx_min=80]