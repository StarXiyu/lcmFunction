function gun:bulletTP/rx/exact/n78 if @s[score_rx=-78,score_rx_min=-78]
function gun:bulletTP/rx/exact/n77 if @s[score_rx=-77,score_rx_min=-77]