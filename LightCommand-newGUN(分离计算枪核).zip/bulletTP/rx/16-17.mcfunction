function gun:bulletTP/rx/exact/16 if @s[score_rx=16,score_rx_min=16]
function gun:bulletTP/rx/exact/17 if @s[score_rx=17,score_rx_min=17]