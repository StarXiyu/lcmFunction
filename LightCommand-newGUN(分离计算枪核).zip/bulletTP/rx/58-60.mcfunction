function gun:bulletTP/rx/58-59 if @s[score_rx=59,score_rx_min=58]
function gun:bulletTP/rx/60-60 if @s[score_rx=60,score_rx_min=60]