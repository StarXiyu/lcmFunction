function gun:bulletTP/rx/exact/n12 if @s[score_rx=-12,score_rx_min=-12]
function gun:bulletTP/rx/exact/n11 if @s[score_rx=-11,score_rx_min=-11]