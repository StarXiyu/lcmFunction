function gun:bulletTP/rx/n61-n59 if @s[score_rx=-59,score_rx_min=-61]
function gun:bulletTP/rx/n58-n56 if @s[score_rx=-56,score_rx_min=-58]