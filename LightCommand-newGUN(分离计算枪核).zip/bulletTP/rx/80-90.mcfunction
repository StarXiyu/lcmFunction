function gun:bulletTP/rx/80-85 if @s[score_rx=85,score_rx_min=80]
function gun:bulletTP/rx/86-90 if @s[score_rx=90,score_rx_min=86]