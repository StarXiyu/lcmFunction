function gun:bulletTP/rx/n58-n57 if @s[score_rx=-57,score_rx_min=-58]
function gun:bulletTP/rx/n56-n56 if @s[score_rx=-56,score_rx_min=-56]