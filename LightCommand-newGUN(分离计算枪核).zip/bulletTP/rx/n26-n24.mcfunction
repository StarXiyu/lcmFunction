function gun:bulletTP/rx/n26-n25 if @s[score_rx=-25,score_rx_min=-26]
function gun:bulletTP/rx/n24-n24 if @s[score_rx=-24,score_rx_min=-24]