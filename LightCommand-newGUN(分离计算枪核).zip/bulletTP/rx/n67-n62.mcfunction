function gun:bulletTP/rx/n67-n65 if @s[score_rx=-65,score_rx_min=-67]
function gun:bulletTP/rx/n64-n62 if @s[score_rx=-62,score_rx_min=-64]