function gun:bulletTP/rx/4-5 if @s[score_rx=5,score_rx_min=4]
function gun:bulletTP/rx/6-6 if @s[score_rx=6,score_rx_min=6]