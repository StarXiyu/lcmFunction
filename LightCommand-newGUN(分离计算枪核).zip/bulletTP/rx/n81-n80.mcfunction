function gun:bulletTP/rx/exact/n81 if @s[score_rx=-81,score_rx_min=-81]
function gun:bulletTP/rx/exact/n80 if @s[score_rx=-80,score_rx_min=-80]