function gun:bulletTP/rx/80-81 if @s[score_rx=81,score_rx_min=80]
function gun:bulletTP/rx/82-82 if @s[score_rx=82,score_rx_min=82]