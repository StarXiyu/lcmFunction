function gun:bulletTP/rx/exact/61 if @s[score_rx=61,score_rx_min=61]
function gun:bulletTP/rx/exact/62 if @s[score_rx=62,score_rx_min=62]