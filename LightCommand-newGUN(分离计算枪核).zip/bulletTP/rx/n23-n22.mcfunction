function gun:bulletTP/rx/exact/n23 if @s[score_rx=-23,score_rx_min=-23]
function gun:bulletTP/rx/exact/n22 if @s[score_rx=-22,score_rx_min=-22]