function gun:bulletTP/rx/n38-n36 if @s[score_rx=-36,score_rx_min=-38]
function gun:bulletTP/rx/n35-n33 if @s[score_rx=-33,score_rx_min=-35]