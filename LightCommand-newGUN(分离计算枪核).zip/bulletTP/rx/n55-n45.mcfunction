function gun:bulletTP/rx/n55-n50 if @s[score_rx=-50,score_rx_min=-55]
function gun:bulletTP/rx/n49-n45 if @s[score_rx=-45,score_rx_min=-49]