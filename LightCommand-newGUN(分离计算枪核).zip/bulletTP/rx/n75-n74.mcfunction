function gun:bulletTP/rx/exact/n75 if @s[score_rx=-75,score_rx_min=-75]
function gun:bulletTP/rx/exact/n74 if @s[score_rx=-74,score_rx_min=-74]