function gun:bulletTP/rx/exact/35 if @s[score_rx=35,score_rx_min=35]
function gun:bulletTP/rx/exact/36 if @s[score_rx=36,score_rx_min=36]