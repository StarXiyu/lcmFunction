function gun:bulletTP/rx/35-36 if @s[score_rx=36,score_rx_min=35]
function gun:bulletTP/rx/37-37 if @s[score_rx=37,score_rx_min=37]