function gun:bulletTP/rx/exact/55 if @s[score_rx=55,score_rx_min=55]
function gun:bulletTP/rx/exact/56 if @s[score_rx=56,score_rx_min=56]