function gun:bulletTP/rx/exact/7 if @s[score_rx=7,score_rx_min=7]
function gun:bulletTP/rx/exact/8 if @s[score_rx=8,score_rx_min=8]