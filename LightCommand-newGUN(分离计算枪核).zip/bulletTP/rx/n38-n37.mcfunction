function gun:bulletTP/rx/exact/n38 if @s[score_rx=-38,score_rx_min=-38]
function gun:bulletTP/rx/exact/n37 if @s[score_rx=-37,score_rx_min=-37]