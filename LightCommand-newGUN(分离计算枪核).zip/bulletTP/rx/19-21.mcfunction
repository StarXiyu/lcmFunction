function gun:bulletTP/rx/19-20 if @s[score_rx=20,score_rx_min=19]
function gun:bulletTP/rx/21-21 if @s[score_rx=21,score_rx_min=21]