function gun:bulletTP/rx/exact/52 if @s[score_rx=52,score_rx_min=52]
function gun:bulletTP/rx/exact/53 if @s[score_rx=53,score_rx_min=53]