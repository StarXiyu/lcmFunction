function gun:bulletTP/rx/exact/n1 if @s[score_rx=-1,score_rx_min=-1]
function gun:bulletTP/rx/exact/0 if @s[score_rx=0,score_rx_min=0]