function gun:bulletTP/rx/86-88 if @s[score_rx=88,score_rx_min=86]
function gun:bulletTP/rx/89-90 if @s[score_rx=90,score_rx_min=89]