function gun:bulletTP/rx/n32-n30 if @s[score_rx=-30,score_rx_min=-32]
function gun:bulletTP/rx/n29-n27 if @s[score_rx=-27,score_rx_min=-29]