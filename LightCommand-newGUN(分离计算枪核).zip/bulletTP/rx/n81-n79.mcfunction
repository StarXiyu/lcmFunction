function gun:bulletTP/rx/n81-n80 if @s[score_rx=-80,score_rx_min=-81]
function gun:bulletTP/rx/n79-n79 if @s[score_rx=-79,score_rx_min=-79]