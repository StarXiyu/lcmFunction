function gun:bulletTP/rx/n90-n68 if @s[score_rx=-68,score_rx_min=-90]
function gun:bulletTP/rx/n67-n45 if @s[score_rx=-45,score_rx_min=-67]