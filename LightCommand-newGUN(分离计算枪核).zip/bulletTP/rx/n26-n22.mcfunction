function gun:bulletTP/rx/n26-n24 if @s[score_rx=-24,score_rx_min=-26]
function gun:bulletTP/rx/n23-n22 if @s[score_rx=-22,score_rx_min=-23]