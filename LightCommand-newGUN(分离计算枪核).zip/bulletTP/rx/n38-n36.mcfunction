function gun:bulletTP/rx/n38-n37 if @s[score_rx=-37,score_rx_min=-38]
function gun:bulletTP/rx/n36-n36 if @s[score_rx=-36,score_rx_min=-36]