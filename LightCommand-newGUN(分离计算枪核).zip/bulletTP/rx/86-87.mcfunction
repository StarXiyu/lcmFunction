function gun:bulletTP/rx/exact/86 if @s[score_rx=86,score_rx_min=86]
function gun:bulletTP/rx/exact/87 if @s[score_rx=87,score_rx_min=87]