function gun:bulletTP/rx/exact/27 if @s[score_rx=27,score_rx_min=27]
function gun:bulletTP/rx/exact/28 if @s[score_rx=28,score_rx_min=28]