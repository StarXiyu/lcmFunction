function gun:bulletTP/rx/exact/n29 if @s[score_rx=-29,score_rx_min=-29]
function gun:bulletTP/rx/exact/n28 if @s[score_rx=-28,score_rx_min=-28]