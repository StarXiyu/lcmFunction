function gun:bulletTP/rx/n49-n48 if @s[score_rx=-48,score_rx_min=-49]
function gun:bulletTP/rx/n47-n47 if @s[score_rx=-47,score_rx_min=-47]