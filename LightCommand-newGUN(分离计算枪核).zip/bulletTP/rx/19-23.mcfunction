function gun:bulletTP/rx/19-21 if @s[score_rx=21,score_rx_min=19]
function gun:bulletTP/rx/22-23 if @s[score_rx=23,score_rx_min=22]