function gun:bulletTP/rx/10-11 if @s[score_rx=11,score_rx_min=10]
function gun:bulletTP/rx/12-12 if @s[score_rx=12,score_rx_min=12]