function gun:bulletTP/rx/30-32 if @s[score_rx=32,score_rx_min=30]
function gun:bulletTP/rx/33-34 if @s[score_rx=34,score_rx_min=33]