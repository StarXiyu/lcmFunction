function gun:bulletTP/rx/exact/n52 if @s[score_rx=-52,score_rx_min=-52]
function gun:bulletTP/rx/exact/n51 if @s[score_rx=-51,score_rx_min=-51]