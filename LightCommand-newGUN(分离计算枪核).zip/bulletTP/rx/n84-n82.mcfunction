function gun:bulletTP/rx/n84-n83 if @s[score_rx=-83,score_rx_min=-84]
function gun:bulletTP/rx/n82-n82 if @s[score_rx=-82,score_rx_min=-82]