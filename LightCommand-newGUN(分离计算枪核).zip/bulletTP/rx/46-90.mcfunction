function gun:bulletTP/rx/46-68 if @s[score_rx=68,score_rx_min=46]
function gun:bulletTP/rx/69-90 if @s[score_rx=90,score_rx_min=69]