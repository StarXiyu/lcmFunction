function gun:bulletTP/rx/exact/75 if @s[score_rx=75,score_rx_min=75]
function gun:bulletTP/rx/exact/76 if @s[score_rx=76,score_rx_min=76]