function gun:bulletTP/rx/n87-n86 if @s[score_rx=-86,score_rx_min=-87]
function gun:bulletTP/rx/n85-n85 if @s[score_rx=-85,score_rx_min=-85]