function gun:bulletTP/rx/exact/n58 if @s[score_rx=-58,score_rx_min=-58]
function gun:bulletTP/rx/exact/n57 if @s[score_rx=-57,score_rx_min=-57]