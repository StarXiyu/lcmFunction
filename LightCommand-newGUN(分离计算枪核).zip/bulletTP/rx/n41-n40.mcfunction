function gun:bulletTP/rx/exact/n41 if @s[score_rx=-41,score_rx_min=-41]
function gun:bulletTP/rx/exact/n40 if @s[score_rx=-40,score_rx_min=-40]