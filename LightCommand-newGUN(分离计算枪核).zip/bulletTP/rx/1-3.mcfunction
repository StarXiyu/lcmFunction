function gun:bulletTP/rx/1-2 if @s[score_rx=2,score_rx_min=1]
function gun:bulletTP/rx/3-3 if @s[score_rx=3,score_rx_min=3]