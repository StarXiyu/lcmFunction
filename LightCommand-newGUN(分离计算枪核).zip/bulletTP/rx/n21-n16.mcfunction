function gun:bulletTP/rx/n21-n19 if @s[score_rx=-19,score_rx_min=-21]
function gun:bulletTP/rx/n18-n16 if @s[score_rx=-16,score_rx_min=-18]