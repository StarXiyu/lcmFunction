function gun:bulletTP/rx/13-14 if @s[score_rx=14,score_rx_min=13]
function gun:bulletTP/rx/15-15 if @s[score_rx=15,score_rx_min=15]