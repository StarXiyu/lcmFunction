function gun:bulletTP/rx/n35-n34 if @s[score_rx=-34,score_rx_min=-35]
function gun:bulletTP/rx/n33-n33 if @s[score_rx=-33,score_rx_min=-33]