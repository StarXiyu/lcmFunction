function gun:bulletTP/rx/80-82 if @s[score_rx=82,score_rx_min=80]
function gun:bulletTP/rx/83-85 if @s[score_rx=85,score_rx_min=83]