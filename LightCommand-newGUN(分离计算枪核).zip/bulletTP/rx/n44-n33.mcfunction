function gun:bulletTP/rx/n44-n39 if @s[score_rx=-39,score_rx_min=-44]
function gun:bulletTP/rx/n38-n33 if @s[score_rx=-33,score_rx_min=-38]