function gun:bulletTP/rx/n15-n14 if @s[score_rx=-14,score_rx_min=-15]
function gun:bulletTP/rx/n13-n13 if @s[score_rx=-13,score_rx_min=-13]