function gun:bulletTP/rx/61-62 if @s[score_rx=62,score_rx_min=61]
function gun:bulletTP/rx/63-63 if @s[score_rx=63,score_rx_min=63]