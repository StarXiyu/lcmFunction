function gun:bulletTP/rx/35-40 if @s[score_rx=40,score_rx_min=35]
function gun:bulletTP/rx/41-45 if @s[score_rx=45,score_rx_min=41]