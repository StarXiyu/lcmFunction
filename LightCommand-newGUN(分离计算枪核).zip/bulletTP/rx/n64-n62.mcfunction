function gun:bulletTP/rx/n64-n63 if @s[score_rx=-63,score_rx_min=-64]
function gun:bulletTP/rx/n62-n62 if @s[score_rx=-62,score_rx_min=-62]