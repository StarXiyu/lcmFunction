function gun:bulletTP/rx/n67-n66 if @s[score_rx=-66,score_rx_min=-67]
function gun:bulletTP/rx/n65-n65 if @s[score_rx=-65,score_rx_min=-65]