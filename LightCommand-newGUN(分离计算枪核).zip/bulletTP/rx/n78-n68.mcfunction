function gun:bulletTP/rx/n78-n73 if @s[score_rx=-73,score_rx_min=-78]
function gun:bulletTP/rx/n72-n68 if @s[score_rx=-68,score_rx_min=-72]