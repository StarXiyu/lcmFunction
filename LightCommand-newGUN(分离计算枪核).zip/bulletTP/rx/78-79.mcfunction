function gun:bulletTP/rx/exact/78 if @s[score_rx=78,score_rx_min=78]
function gun:bulletTP/rx/exact/79 if @s[score_rx=79,score_rx_min=79]