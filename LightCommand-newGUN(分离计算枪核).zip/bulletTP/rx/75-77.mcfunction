function gun:bulletTP/rx/75-76 if @s[score_rx=76,score_rx_min=75]
function gun:bulletTP/rx/77-77 if @s[score_rx=77,score_rx_min=77]