function gun:bulletTP/rx/exact/30 if @s[score_rx=30,score_rx_min=30]
function gun:bulletTP/rx/exact/31 if @s[score_rx=31,score_rx_min=31]