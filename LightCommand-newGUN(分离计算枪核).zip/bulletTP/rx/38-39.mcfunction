function gun:bulletTP/rx/exact/38 if @s[score_rx=38,score_rx_min=38]
function gun:bulletTP/rx/exact/39 if @s[score_rx=39,score_rx_min=39]