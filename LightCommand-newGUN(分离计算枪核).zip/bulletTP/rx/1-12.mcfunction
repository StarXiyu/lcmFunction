function gun:bulletTP/rx/1-6 if @s[score_rx=6,score_rx_min=1]
function gun:bulletTP/rx/7-12 if @s[score_rx=12,score_rx_min=7]