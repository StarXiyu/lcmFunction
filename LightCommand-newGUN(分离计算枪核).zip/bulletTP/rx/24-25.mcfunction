function gun:bulletTP/rx/exact/24 if @s[score_rx=24,score_rx_min=24]
function gun:bulletTP/rx/exact/25 if @s[score_rx=25,score_rx_min=25]