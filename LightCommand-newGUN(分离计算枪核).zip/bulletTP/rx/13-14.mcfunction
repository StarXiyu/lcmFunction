function gun:bulletTP/rx/exact/13 if @s[score_rx=13,score_rx_min=13]
function gun:bulletTP/rx/exact/14 if @s[score_rx=14,score_rx_min=14]