function gun:bulletTP/rx/24-26 if @s[score_rx=26,score_rx_min=24]
function gun:bulletTP/rx/27-29 if @s[score_rx=29,score_rx_min=27]