function gun:bulletTP/rx/exact/80 if @s[score_rx=80,score_rx_min=80]
function gun:bulletTP/rx/exact/81 if @s[score_rx=81,score_rx_min=81]