function gun:bulletTP/rx/n75-n74 if @s[score_rx=-74,score_rx_min=-75]
function gun:bulletTP/rx/n73-n73 if @s[score_rx=-73,score_rx_min=-73]