function gun:bulletTP/rx/n10-n9 if @s[score_rx=-9,score_rx_min=-10]
function gun:bulletTP/rx/n8-n8 if @s[score_rx=-8,score_rx_min=-8]