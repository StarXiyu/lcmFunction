function gun:bulletTP/rx/exact/n90 if @s[score_rx=-90,score_rx_min=-90]
function gun:bulletTP/rx/exact/n89 if @s[score_rx=-89,score_rx_min=-89]