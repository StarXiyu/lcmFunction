function gun:bulletTP/rx/46-48 if @s[score_rx=48,score_rx_min=46]
function gun:bulletTP/rx/49-51 if @s[score_rx=51,score_rx_min=49]