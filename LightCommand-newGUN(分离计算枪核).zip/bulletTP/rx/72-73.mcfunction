function gun:bulletTP/rx/exact/72 if @s[score_rx=72,score_rx_min=72]
function gun:bulletTP/rx/exact/73 if @s[score_rx=73,score_rx_min=73]