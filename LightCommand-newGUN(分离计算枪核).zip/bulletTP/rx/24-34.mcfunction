function gun:bulletTP/rx/24-29 if @s[score_rx=29,score_rx_min=24]
function gun:bulletTP/rx/30-34 if @s[score_rx=34,score_rx_min=30]