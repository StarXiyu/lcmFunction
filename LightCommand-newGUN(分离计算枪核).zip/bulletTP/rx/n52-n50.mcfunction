function gun:bulletTP/rx/n52-n51 if @s[score_rx=-51,score_rx_min=-52]
function gun:bulletTP/rx/n50-n50 if @s[score_rx=-50,score_rx_min=-50]