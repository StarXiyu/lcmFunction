function gun:bulletTP/rx/exact/19 if @s[score_rx=19,score_rx_min=19]
function gun:bulletTP/rx/exact/20 if @s[score_rx=20,score_rx_min=20]