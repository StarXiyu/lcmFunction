function gun:bulletTP/rx/1-45 if @s[score_rx=45,score_rx_min=1]
function gun:bulletTP/rx/46-90 if @s[score_rx=90,score_rx_min=46]