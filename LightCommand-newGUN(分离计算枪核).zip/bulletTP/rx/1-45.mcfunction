function gun:bulletTP/rx/1-23 if @s[score_rx=23,score_rx_min=1]
function gun:bulletTP/rx/24-45 if @s[score_rx=45,score_rx_min=24]