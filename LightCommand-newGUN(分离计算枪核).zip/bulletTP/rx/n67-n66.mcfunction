function gun:bulletTP/rx/exact/n67 if @s[score_rx=-67,score_rx_min=-67]
function gun:bulletTP/rx/exact/n66 if @s[score_rx=-66,score_rx_min=-66]