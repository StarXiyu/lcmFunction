function gun:bulletTP/rx/n67-n62 if @s[score_rx=-62,score_rx_min=-67]
function gun:bulletTP/rx/n61-n56 if @s[score_rx=-56,score_rx_min=-61]