function gun:bulletTP/rx/n44-n22 if @s[score_rx=-22,score_rx_min=-44]
function gun:bulletTP/rx/n21-0 if @s[score_rx=0,score_rx_min=-21]