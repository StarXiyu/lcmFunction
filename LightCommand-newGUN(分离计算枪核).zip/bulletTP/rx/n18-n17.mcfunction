function gun:bulletTP/rx/exact/n18 if @s[score_rx=-18,score_rx_min=-18]
function gun:bulletTP/rx/exact/n17 if @s[score_rx=-17,score_rx_min=-17]