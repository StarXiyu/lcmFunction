function gun:bulletTP/rx/n78-n77 if @s[score_rx=-77,score_rx_min=-78]
function gun:bulletTP/rx/n76-n76 if @s[score_rx=-76,score_rx_min=-76]