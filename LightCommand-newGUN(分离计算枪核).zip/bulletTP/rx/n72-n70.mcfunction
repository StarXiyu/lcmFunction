function gun:bulletTP/rx/n72-n71 if @s[score_rx=-71,score_rx_min=-72]
function gun:bulletTP/rx/n70-n70 if @s[score_rx=-70,score_rx_min=-70]