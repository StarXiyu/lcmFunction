function gun:bulletTP/rx/n21-n20 if @s[score_rx=-20,score_rx_min=-21]
function gun:bulletTP/rx/n19-n19 if @s[score_rx=-19,score_rx_min=-19]