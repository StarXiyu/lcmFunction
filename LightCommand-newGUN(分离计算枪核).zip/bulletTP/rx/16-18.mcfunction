function gun:bulletTP/rx/16-17 if @s[score_rx=17,score_rx_min=16]
function gun:bulletTP/rx/18-18 if @s[score_rx=18,score_rx_min=18]