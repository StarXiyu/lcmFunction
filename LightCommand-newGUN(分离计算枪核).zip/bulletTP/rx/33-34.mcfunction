function gun:bulletTP/rx/exact/33 if @s[score_rx=33,score_rx_min=33]
function gun:bulletTP/rx/exact/34 if @s[score_rx=34,score_rx_min=34]