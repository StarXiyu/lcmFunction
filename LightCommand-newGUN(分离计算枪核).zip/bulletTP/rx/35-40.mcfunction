function gun:bulletTP/rx/35-37 if @s[score_rx=37,score_rx_min=35]
function gun:bulletTP/rx/38-40 if @s[score_rx=40,score_rx_min=38]