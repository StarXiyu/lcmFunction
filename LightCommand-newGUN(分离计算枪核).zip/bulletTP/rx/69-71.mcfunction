function gun:bulletTP/rx/69-70 if @s[score_rx=70,score_rx_min=69]
function gun:bulletTP/rx/71-71 if @s[score_rx=71,score_rx_min=71]