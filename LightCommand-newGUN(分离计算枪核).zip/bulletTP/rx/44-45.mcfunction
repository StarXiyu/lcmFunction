function gun:bulletTP/rx/exact/44 if @s[score_rx=44,score_rx_min=44]
function gun:bulletTP/rx/exact/45 if @s[score_rx=45,score_rx_min=45]