function gun:bulletTP/rx/n18-n17 if @s[score_rx=-17,score_rx_min=-18]
function gun:bulletTP/rx/n16-n16 if @s[score_rx=-16,score_rx_min=-16]