function gun:bulletTP/rx/exact/41 if @s[score_rx=41,score_rx_min=41]
function gun:bulletTP/rx/exact/42 if @s[score_rx=42,score_rx_min=42]