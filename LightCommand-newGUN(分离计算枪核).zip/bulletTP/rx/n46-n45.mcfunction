function gun:bulletTP/rx/exact/n46 if @s[score_rx=-46,score_rx_min=-46]
function gun:bulletTP/rx/exact/n45 if @s[score_rx=-45,score_rx_min=-45]