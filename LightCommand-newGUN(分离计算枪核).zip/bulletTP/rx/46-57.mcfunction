function gun:bulletTP/rx/46-51 if @s[score_rx=51,score_rx_min=46]
function gun:bulletTP/rx/52-57 if @s[score_rx=57,score_rx_min=52]