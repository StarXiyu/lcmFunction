function gun:bulletTP/rx/49-50 if @s[score_rx=50,score_rx_min=49]
function gun:bulletTP/rx/51-51 if @s[score_rx=51,score_rx_min=51]