function gun:bulletTP/rx/n29-n28 if @s[score_rx=-28,score_rx_min=-29]
function gun:bulletTP/rx/n27-n27 if @s[score_rx=-27,score_rx_min=-27]