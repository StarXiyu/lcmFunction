function gun:bulletTP/rx/n15-n13 if @s[score_rx=-13,score_rx_min=-15]
function gun:bulletTP/rx/n12-n11 if @s[score_rx=-11,score_rx_min=-12]