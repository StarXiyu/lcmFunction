function gun:bulletTP/rx/n49-n47 if @s[score_rx=-47,score_rx_min=-49]
function gun:bulletTP/rx/n46-n45 if @s[score_rx=-45,score_rx_min=-46]