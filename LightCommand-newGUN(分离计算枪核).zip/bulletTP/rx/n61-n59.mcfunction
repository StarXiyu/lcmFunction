function gun:bulletTP/rx/n61-n60 if @s[score_rx=-60,score_rx_min=-61]
function gun:bulletTP/rx/n59-n59 if @s[score_rx=-59,score_rx_min=-59]