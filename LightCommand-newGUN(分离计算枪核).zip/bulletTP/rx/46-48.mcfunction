function gun:bulletTP/rx/46-47 if @s[score_rx=47,score_rx_min=46]
function gun:bulletTP/rx/48-48 if @s[score_rx=48,score_rx_min=48]