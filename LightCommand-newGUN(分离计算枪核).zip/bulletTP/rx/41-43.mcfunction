function gun:bulletTP/rx/41-42 if @s[score_rx=42,score_rx_min=41]
function gun:bulletTP/rx/43-43 if @s[score_rx=43,score_rx_min=43]