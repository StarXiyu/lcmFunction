function gun:bulletTP/rx/58-63 if @s[score_rx=63,score_rx_min=58]
function gun:bulletTP/rx/64-68 if @s[score_rx=68,score_rx_min=64]