function gun:bulletTP/rx/n44-n33 if @s[score_rx=-33,score_rx_min=-44]
function gun:bulletTP/rx/n32-n22 if @s[score_rx=-22,score_rx_min=-32]