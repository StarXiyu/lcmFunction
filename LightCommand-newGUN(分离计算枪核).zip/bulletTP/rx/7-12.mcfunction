function gun:bulletTP/rx/7-9 if @s[score_rx=9,score_rx_min=7]
function gun:bulletTP/rx/10-12 if @s[score_rx=12,score_rx_min=10]