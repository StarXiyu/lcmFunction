function gun:bulletTP/rx/exact/67 if @s[score_rx=67,score_rx_min=67]
function gun:bulletTP/rx/exact/68 if @s[score_rx=68,score_rx_min=68]