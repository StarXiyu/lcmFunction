function gun:bulletTP/rx/n32-n27 if @s[score_rx=-27,score_rx_min=-32]
function gun:bulletTP/rx/n26-n22 if @s[score_rx=-22,score_rx_min=-26]