function gun:bulletTP/rx/1-3 if @s[score_rx=3,score_rx_min=1]
function gun:bulletTP/rx/4-6 if @s[score_rx=6,score_rx_min=4]