function gun:bulletTP/rx/n90-n85 if @s[score_rx=-85,score_rx_min=-90]
function gun:bulletTP/rx/n84-n79 if @s[score_rx=-79,score_rx_min=-84]