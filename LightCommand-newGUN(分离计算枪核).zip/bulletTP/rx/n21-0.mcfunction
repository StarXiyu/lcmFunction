function gun:bulletTP/rx/n21-n11 if @s[score_rx=-11,score_rx_min=-21]
function gun:bulletTP/rx/n10-0 if @s[score_rx=0,score_rx_min=-10]