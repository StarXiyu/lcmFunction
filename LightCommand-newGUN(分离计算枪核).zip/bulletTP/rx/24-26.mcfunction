function gun:bulletTP/rx/24-25 if @s[score_rx=25,score_rx_min=24]
function gun:bulletTP/rx/26-26 if @s[score_rx=26,score_rx_min=26]