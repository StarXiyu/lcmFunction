function gun:bulletTP/rx/n84-n82 if @s[score_rx=-82,score_rx_min=-84]
function gun:bulletTP/rx/n81-n79 if @s[score_rx=-79,score_rx_min=-81]