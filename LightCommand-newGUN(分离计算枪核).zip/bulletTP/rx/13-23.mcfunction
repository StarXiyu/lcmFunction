function gun:bulletTP/rx/13-18 if @s[score_rx=18,score_rx_min=13]
function gun:bulletTP/rx/19-23 if @s[score_rx=23,score_rx_min=19]