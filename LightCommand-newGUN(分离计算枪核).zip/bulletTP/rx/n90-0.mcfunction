function gun:bulletTP/rx/n90-n45 if @s[score_rx=-45,score_rx_min=-90]
function gun:bulletTP/rx/n44-0 if @s[score_rx=0,score_rx_min=-44]