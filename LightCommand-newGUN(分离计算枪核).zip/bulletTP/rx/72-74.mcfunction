function gun:bulletTP/rx/72-73 if @s[score_rx=73,score_rx_min=72]
function gun:bulletTP/rx/74-74 if @s[score_rx=74,score_rx_min=74]