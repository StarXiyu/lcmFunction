function gun:bulletTP/rx/n4-n3 if @s[score_rx=-3,score_rx_min=-4]
function gun:bulletTP/rx/n2-n2 if @s[score_rx=-2,score_rx_min=-2]