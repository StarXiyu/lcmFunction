function gun:bulletTP/rx/exact/49 if @s[score_rx=49,score_rx_min=49]
function gun:bulletTP/rx/exact/50 if @s[score_rx=50,score_rx_min=50]