function gun:bulletTP/rx/52-54 if @s[score_rx=54,score_rx_min=52]
function gun:bulletTP/rx/55-57 if @s[score_rx=57,score_rx_min=55]