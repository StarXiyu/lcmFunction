function gun:bulletTP/rx/n90-n79 if @s[score_rx=-79,score_rx_min=-90]
function gun:bulletTP/rx/n78-n68 if @s[score_rx=-68,score_rx_min=-78]