function gun:bulletTP/rx/46-57 if @s[score_rx=57,score_rx_min=46]
function gun:bulletTP/rx/58-68 if @s[score_rx=68,score_rx_min=58]