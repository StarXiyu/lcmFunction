function gun:bulletTP/rx/1-12 if @s[score_rx=12,score_rx_min=1]
function gun:bulletTP/rx/13-23 if @s[score_rx=23,score_rx_min=13]