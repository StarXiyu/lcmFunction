function gun:bulletTP/rx/exact/n4 if @s[score_rx=-4,score_rx_min=-4]
function gun:bulletTP/rx/exact/n3 if @s[score_rx=-3,score_rx_min=-3]