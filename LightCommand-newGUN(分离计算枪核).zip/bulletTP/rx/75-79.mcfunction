function gun:bulletTP/rx/75-77 if @s[score_rx=77,score_rx_min=75]
function gun:bulletTP/rx/78-79 if @s[score_rx=79,score_rx_min=78]