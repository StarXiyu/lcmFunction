function gun:bulletTP/rx/24-34 if @s[score_rx=34,score_rx_min=24]
function gun:bulletTP/rx/35-45 if @s[score_rx=45,score_rx_min=35]