function gun:bulletTP/rx/n10-n5 if @s[score_rx=-5,score_rx_min=-10]
function gun:bulletTP/rx/n4-0 if @s[score_rx=0,score_rx_min=-4]