function gun:bulletTP/rx/exact/n84 if @s[score_rx=-84,score_rx_min=-84]
function gun:bulletTP/rx/exact/n83 if @s[score_rx=-83,score_rx_min=-83]