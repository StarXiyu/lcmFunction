function gun:bulletTP/rx/exact/n21 if @s[score_rx=-21,score_rx_min=-21]
function gun:bulletTP/rx/exact/n20 if @s[score_rx=-20,score_rx_min=-20]