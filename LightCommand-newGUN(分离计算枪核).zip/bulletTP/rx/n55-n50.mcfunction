function gun:bulletTP/rx/n55-n53 if @s[score_rx=-53,score_rx_min=-55]
function gun:bulletTP/rx/n52-n50 if @s[score_rx=-50,score_rx_min=-52]