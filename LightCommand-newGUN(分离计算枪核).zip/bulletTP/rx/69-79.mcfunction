function gun:bulletTP/rx/69-74 if @s[score_rx=74,score_rx_min=69]
function gun:bulletTP/rx/75-79 if @s[score_rx=79,score_rx_min=75]