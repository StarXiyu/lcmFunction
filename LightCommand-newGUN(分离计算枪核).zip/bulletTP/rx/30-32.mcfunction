function gun:bulletTP/rx/30-31 if @s[score_rx=31,score_rx_min=30]
function gun:bulletTP/rx/32-32 if @s[score_rx=32,score_rx_min=32]