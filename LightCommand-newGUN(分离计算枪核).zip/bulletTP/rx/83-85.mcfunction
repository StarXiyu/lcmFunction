function gun:bulletTP/rx/83-84 if @s[score_rx=84,score_rx_min=83]
function gun:bulletTP/rx/85-85 if @s[score_rx=85,score_rx_min=85]