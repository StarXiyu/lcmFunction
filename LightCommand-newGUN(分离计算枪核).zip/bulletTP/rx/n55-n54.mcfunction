function gun:bulletTP/rx/exact/n55 if @s[score_rx=-55,score_rx_min=-55]
function gun:bulletTP/rx/exact/n54 if @s[score_rx=-54,score_rx_min=-54]