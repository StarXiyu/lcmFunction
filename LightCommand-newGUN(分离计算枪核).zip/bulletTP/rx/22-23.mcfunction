function gun:bulletTP/rx/exact/22 if @s[score_rx=22,score_rx_min=22]
function gun:bulletTP/rx/exact/23 if @s[score_rx=23,score_rx_min=23]