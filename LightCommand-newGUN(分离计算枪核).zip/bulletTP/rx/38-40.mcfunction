function gun:bulletTP/rx/38-39 if @s[score_rx=39,score_rx_min=38]
function gun:bulletTP/rx/40-40 if @s[score_rx=40,score_rx_min=40]