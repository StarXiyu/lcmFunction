function gun:bulletTP/rx/n7-n6 if @s[score_rx=-6,score_rx_min=-7]
function gun:bulletTP/rx/n5-n5 if @s[score_rx=-5,score_rx_min=-5]