function gun:bulletTP/rx/69-71 if @s[score_rx=71,score_rx_min=69]
function gun:bulletTP/rx/72-74 if @s[score_rx=74,score_rx_min=72]