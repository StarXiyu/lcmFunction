function gun:bulletTP/rx/exact/10 if @s[score_rx=10,score_rx_min=10]
function gun:bulletTP/rx/exact/11 if @s[score_rx=11,score_rx_min=11]