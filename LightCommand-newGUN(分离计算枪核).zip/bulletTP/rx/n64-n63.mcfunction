function gun:bulletTP/rx/exact/n64 if @s[score_rx=-64,score_rx_min=-64]
function gun:bulletTP/rx/exact/n63 if @s[score_rx=-63,score_rx_min=-63]