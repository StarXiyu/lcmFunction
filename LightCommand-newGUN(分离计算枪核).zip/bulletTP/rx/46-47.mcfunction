function gun:bulletTP/rx/exact/46 if @s[score_rx=46,score_rx_min=46]
function gun:bulletTP/rx/exact/47 if @s[score_rx=47,score_rx_min=47]