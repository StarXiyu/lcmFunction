function gun:bulletTP/rx/n44-n43 if @s[score_rx=-43,score_rx_min=-44]
function gun:bulletTP/rx/n42-n42 if @s[score_rx=-42,score_rx_min=-42]