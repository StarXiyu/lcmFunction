function gun:bulletTP/rx/27-28 if @s[score_rx=28,score_rx_min=27]
function gun:bulletTP/rx/29-29 if @s[score_rx=29,score_rx_min=29]