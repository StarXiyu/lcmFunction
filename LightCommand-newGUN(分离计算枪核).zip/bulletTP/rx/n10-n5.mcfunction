function gun:bulletTP/rx/n10-n8 if @s[score_rx=-8,score_rx_min=-10]
function gun:bulletTP/rx/n7-n5 if @s[score_rx=-5,score_rx_min=-7]