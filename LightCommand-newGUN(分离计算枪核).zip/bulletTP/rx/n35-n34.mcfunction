function gun:bulletTP/rx/exact/n35 if @s[score_rx=-35,score_rx_min=-35]
function gun:bulletTP/rx/exact/n34 if @s[score_rx=-34,score_rx_min=-34]