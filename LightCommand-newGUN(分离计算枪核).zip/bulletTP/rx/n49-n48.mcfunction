function gun:bulletTP/rx/exact/n49 if @s[score_rx=-49,score_rx_min=-49]
function gun:bulletTP/rx/exact/n48 if @s[score_rx=-48,score_rx_min=-48]