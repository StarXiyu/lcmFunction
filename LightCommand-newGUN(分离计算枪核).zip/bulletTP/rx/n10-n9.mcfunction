function gun:bulletTP/rx/exact/n10 if @s[score_rx=-10,score_rx_min=-10]
function gun:bulletTP/rx/exact/n9 if @s[score_rx=-9,score_rx_min=-9]