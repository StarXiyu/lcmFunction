function gun:bulletTP/rx/n21-n16 if @s[score_rx=-16,score_rx_min=-21]
function gun:bulletTP/rx/n15-n11 if @s[score_rx=-11,score_rx_min=-15]