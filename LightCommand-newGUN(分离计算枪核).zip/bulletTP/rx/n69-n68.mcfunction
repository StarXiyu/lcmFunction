function gun:bulletTP/rx/exact/n69 if @s[score_rx=-69,score_rx_min=-69]
function gun:bulletTP/rx/exact/n68 if @s[score_rx=-68,score_rx_min=-68]