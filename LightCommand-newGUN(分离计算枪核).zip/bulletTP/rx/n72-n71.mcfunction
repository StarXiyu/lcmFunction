function gun:bulletTP/rx/exact/n72 if @s[score_rx=-72,score_rx_min=-72]
function gun:bulletTP/rx/exact/n71 if @s[score_rx=-71,score_rx_min=-71]