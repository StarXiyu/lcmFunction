function gun:bulletTP/rx/n90-n88 if @s[score_rx=-88,score_rx_min=-90]
function gun:bulletTP/rx/n87-n85 if @s[score_rx=-85,score_rx_min=-87]