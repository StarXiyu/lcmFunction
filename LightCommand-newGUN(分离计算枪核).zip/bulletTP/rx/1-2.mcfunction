function gun:bulletTP/rx/exact/1 if @s[score_rx=1,score_rx_min=1]
function gun:bulletTP/rx/exact/2 if @s[score_rx=2,score_rx_min=2]