function gun:bulletTP/rx/n90-0 if @s[score_rx=0,score_rx_min=-90]
function gun:bulletTP/rx/1-90 if @s[score_rx=90,score_rx_min=1]