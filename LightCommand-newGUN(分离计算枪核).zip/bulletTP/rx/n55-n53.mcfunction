function gun:bulletTP/rx/n55-n54 if @s[score_rx=-54,score_rx_min=-55]
function gun:bulletTP/rx/n53-n53 if @s[score_rx=-53,score_rx_min=-53]