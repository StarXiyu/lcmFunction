function gun:bulletTP/rx/exact/n87 if @s[score_rx=-87,score_rx_min=-87]
function gun:bulletTP/rx/exact/n86 if @s[score_rx=-86,score_rx_min=-86]