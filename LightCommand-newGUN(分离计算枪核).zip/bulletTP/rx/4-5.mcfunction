function gun:bulletTP/rx/exact/4 if @s[score_rx=4,score_rx_min=4]
function gun:bulletTP/rx/exact/5 if @s[score_rx=5,score_rx_min=5]