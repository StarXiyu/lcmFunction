function gun:bulletTP/ry/120-122 if @s[score_ry=122,score_ry_min=120]
function gun:bulletTP/ry/123-124 if @s[score_ry=124,score_ry_min=123]