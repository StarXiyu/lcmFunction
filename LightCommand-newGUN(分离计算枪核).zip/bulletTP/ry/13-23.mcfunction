function gun:bulletTP/ry/13-18 if @s[score_ry=18,score_ry_min=13]
function gun:bulletTP/ry/19-23 if @s[score_ry=23,score_ry_min=19]