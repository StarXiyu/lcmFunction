function gun:bulletTP/ry/exact/114 if @s[score_ry=114,score_ry_min=114]
function gun:bulletTP/ry/exact/115 if @s[score_ry=115,score_ry_min=115]