function gun:bulletTP/ry/114-116 if @s[score_ry=116,score_ry_min=114]
function gun:bulletTP/ry/117-119 if @s[score_ry=119,score_ry_min=117]