function gun:bulletTP/ry/117-118 if @s[score_ry=118,score_ry_min=117]
function gun:bulletTP/ry/119-119 if @s[score_ry=119,score_ry_min=119]