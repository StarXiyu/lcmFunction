function gun:bulletTP/ry/exact/120 if @s[score_ry=120,score_ry_min=120]
function gun:bulletTP/ry/exact/121 if @s[score_ry=121,score_ry_min=121]