function gun:bulletTP/ry/106-107 if @s[score_ry=107,score_ry_min=106]
function gun:bulletTP/ry/108-108 if @s[score_ry=108,score_ry_min=108]