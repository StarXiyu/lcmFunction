function gun:bulletTP/ry/136-138 if @s[score_ry=138,score_ry_min=136]
function gun:bulletTP/ry/139-141 if @s[score_ry=141,score_ry_min=139]