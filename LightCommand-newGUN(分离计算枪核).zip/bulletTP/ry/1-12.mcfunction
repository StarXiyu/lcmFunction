function gun:bulletTP/ry/1-6 if @s[score_ry=6,score_ry_min=1]
function gun:bulletTP/ry/7-12 if @s[score_ry=12,score_ry_min=7]