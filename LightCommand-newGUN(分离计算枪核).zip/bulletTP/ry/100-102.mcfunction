function gun:bulletTP/ry/100-101 if @s[score_ry=101,score_ry_min=100]
function gun:bulletTP/ry/102-102 if @s[score_ry=102,score_ry_min=102]