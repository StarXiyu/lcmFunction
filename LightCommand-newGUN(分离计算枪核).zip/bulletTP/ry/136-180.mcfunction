function gun:bulletTP/ry/136-158 if @s[score_ry=158,score_ry_min=136]
function gun:bulletTP/ry/159-180 if @s[score_ry=180,score_ry_min=159]