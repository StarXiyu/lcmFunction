function gun:bulletTP/ry/exact/112 if @s[score_ry=112,score_ry_min=112]
function gun:bulletTP/ry/exact/113 if @s[score_ry=113,score_ry_min=113]