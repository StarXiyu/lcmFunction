function gun:bulletTP/ry/103-105 if @s[score_ry=105,score_ry_min=103]
function gun:bulletTP/ry/106-108 if @s[score_ry=108,score_ry_min=106]