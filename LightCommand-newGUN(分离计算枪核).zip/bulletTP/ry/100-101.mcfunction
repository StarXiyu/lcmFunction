function gun:bulletTP/ry/exact/100 if @s[score_ry=100,score_ry_min=100]
function gun:bulletTP/ry/exact/101 if @s[score_ry=101,score_ry_min=101]