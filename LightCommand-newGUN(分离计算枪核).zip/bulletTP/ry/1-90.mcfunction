function gun:bulletTP/ry/1-45 if @s[score_ry=45,score_ry_min=1]
function gun:bulletTP/ry/46-90 if @s[score_ry=90,score_ry_min=46]