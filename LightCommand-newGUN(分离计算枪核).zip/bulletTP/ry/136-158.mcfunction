function gun:bulletTP/ry/136-147 if @s[score_ry=147,score_ry_min=136]
function gun:bulletTP/ry/148-158 if @s[score_ry=158,score_ry_min=148]