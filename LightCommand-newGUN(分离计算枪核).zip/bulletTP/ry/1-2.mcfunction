function gun:bulletTP/ry/exact/1 if @s[score_ry=1,score_ry_min=1]
function gun:bulletTP/ry/exact/2 if @s[score_ry=2,score_ry_min=2]