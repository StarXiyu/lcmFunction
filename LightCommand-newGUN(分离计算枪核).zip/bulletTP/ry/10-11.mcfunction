function gun:bulletTP/ry/exact/10 if @s[score_ry=10,score_ry_min=10]
function gun:bulletTP/ry/exact/11 if @s[score_ry=11,score_ry_min=11]