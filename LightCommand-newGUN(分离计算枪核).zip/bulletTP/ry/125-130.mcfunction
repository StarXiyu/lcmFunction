function gun:bulletTP/ry/125-127 if @s[score_ry=127,score_ry_min=125]
function gun:bulletTP/ry/128-130 if @s[score_ry=130,score_ry_min=128]