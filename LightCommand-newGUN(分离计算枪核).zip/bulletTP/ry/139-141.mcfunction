function gun:bulletTP/ry/139-140 if @s[score_ry=140,score_ry_min=139]
function gun:bulletTP/ry/141-141 if @s[score_ry=141,score_ry_min=141]