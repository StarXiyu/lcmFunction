function gun:bulletTP/ry/125-126 if @s[score_ry=126,score_ry_min=125]
function gun:bulletTP/ry/127-127 if @s[score_ry=127,score_ry_min=127]