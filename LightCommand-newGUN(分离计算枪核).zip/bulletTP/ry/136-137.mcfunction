function gun:bulletTP/ry/exact/136 if @s[score_ry=136,score_ry_min=136]
function gun:bulletTP/ry/exact/137 if @s[score_ry=137,score_ry_min=137]