function gun:bulletTP/ry/exact/142 if @s[score_ry=142,score_ry_min=142]
function gun:bulletTP/ry/exact/143 if @s[score_ry=143,score_ry_min=143]