function gun:bulletTP/ry/131-132 if @s[score_ry=132,score_ry_min=131]
function gun:bulletTP/ry/133-133 if @s[score_ry=133,score_ry_min=133]