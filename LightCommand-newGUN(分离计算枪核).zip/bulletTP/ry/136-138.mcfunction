function gun:bulletTP/ry/136-137 if @s[score_ry=137,score_ry_min=136]
function gun:bulletTP/ry/138-138 if @s[score_ry=138,score_ry_min=138]