function gun:bulletTP/ry/exact/117 if @s[score_ry=117,score_ry_min=117]
function gun:bulletTP/ry/exact/118 if @s[score_ry=118,score_ry_min=118]