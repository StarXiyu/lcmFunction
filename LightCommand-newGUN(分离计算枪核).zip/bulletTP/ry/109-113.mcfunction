function gun:bulletTP/ry/109-111 if @s[score_ry=111,score_ry_min=109]
function gun:bulletTP/ry/112-113 if @s[score_ry=113,score_ry_min=112]