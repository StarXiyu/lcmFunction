function gun:bulletTP/ry/125-130 if @s[score_ry=130,score_ry_min=125]
function gun:bulletTP/ry/131-135 if @s[score_ry=135,score_ry_min=131]