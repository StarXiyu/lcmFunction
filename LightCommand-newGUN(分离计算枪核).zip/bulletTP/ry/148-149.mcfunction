function gun:bulletTP/ry/exact/148 if @s[score_ry=148,score_ry_min=148]
function gun:bulletTP/ry/exact/149 if @s[score_ry=149,score_ry_min=149]