function gun:bulletTP/ry/13-14 if @s[score_ry=14,score_ry_min=13]
function gun:bulletTP/ry/15-15 if @s[score_ry=15,score_ry_min=15]