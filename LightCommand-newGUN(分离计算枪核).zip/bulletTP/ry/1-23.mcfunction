function gun:bulletTP/ry/1-12 if @s[score_ry=12,score_ry_min=1]
function gun:bulletTP/ry/13-23 if @s[score_ry=23,score_ry_min=13]