function gun:bulletTP/ry/exact/145 if @s[score_ry=145,score_ry_min=145]
function gun:bulletTP/ry/exact/146 if @s[score_ry=146,score_ry_min=146]