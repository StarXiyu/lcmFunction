function gun:bulletTP/ry/exact/123 if @s[score_ry=123,score_ry_min=123]
function gun:bulletTP/ry/exact/124 if @s[score_ry=124,score_ry_min=124]