function gun:bulletTP/ry/exact/134 if @s[score_ry=134,score_ry_min=134]
function gun:bulletTP/ry/exact/135 if @s[score_ry=135,score_ry_min=135]