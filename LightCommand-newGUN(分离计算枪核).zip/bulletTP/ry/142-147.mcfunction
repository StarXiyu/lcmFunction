function gun:bulletTP/ry/142-144 if @s[score_ry=144,score_ry_min=142]
function gun:bulletTP/ry/145-147 if @s[score_ry=147,score_ry_min=145]