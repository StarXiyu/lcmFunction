function gun:bulletTP/ry/148-149 if @s[score_ry=149,score_ry_min=148]
function gun:bulletTP/ry/150-150 if @s[score_ry=150,score_ry_min=150]