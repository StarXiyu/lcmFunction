function gun:bulletTP/ry/103-104 if @s[score_ry=104,score_ry_min=103]
function gun:bulletTP/ry/105-105 if @s[score_ry=105,score_ry_min=105]