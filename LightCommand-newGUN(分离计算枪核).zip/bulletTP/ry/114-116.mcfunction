function gun:bulletTP/ry/114-115 if @s[score_ry=115,score_ry_min=114]
function gun:bulletTP/ry/116-116 if @s[score_ry=116,score_ry_min=116]