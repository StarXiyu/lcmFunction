function gun:bulletTP/ry/131-133 if @s[score_ry=133,score_ry_min=131]
function gun:bulletTP/ry/134-135 if @s[score_ry=135,score_ry_min=134]