function gun:bulletTP/ry/148-150 if @s[score_ry=150,score_ry_min=148]
function gun:bulletTP/ry/151-153 if @s[score_ry=153,score_ry_min=151]