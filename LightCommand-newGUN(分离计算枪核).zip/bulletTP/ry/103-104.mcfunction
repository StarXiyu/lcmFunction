function gun:bulletTP/ry/exact/103 if @s[score_ry=103,score_ry_min=103]
function gun:bulletTP/ry/exact/104 if @s[score_ry=104,score_ry_min=104]