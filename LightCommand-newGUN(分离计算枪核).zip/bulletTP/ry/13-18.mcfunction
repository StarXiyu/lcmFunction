function gun:bulletTP/ry/13-15 if @s[score_ry=15,score_ry_min=13]
function gun:bulletTP/ry/16-18 if @s[score_ry=18,score_ry_min=16]