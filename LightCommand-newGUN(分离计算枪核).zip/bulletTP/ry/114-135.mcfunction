function gun:bulletTP/ry/114-124 if @s[score_ry=124,score_ry_min=114]
function gun:bulletTP/ry/125-135 if @s[score_ry=135,score_ry_min=125]