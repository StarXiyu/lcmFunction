function gun:bulletTP/ry/1-3 if @s[score_ry=3,score_ry_min=1]
function gun:bulletTP/ry/4-6 if @s[score_ry=6,score_ry_min=4]