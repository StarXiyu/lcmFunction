function gun:bulletTP/ry/142-143 if @s[score_ry=143,score_ry_min=142]
function gun:bulletTP/ry/144-144 if @s[score_ry=144,score_ry_min=144]