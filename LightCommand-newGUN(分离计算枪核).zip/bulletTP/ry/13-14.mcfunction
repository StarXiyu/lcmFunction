function gun:bulletTP/ry/exact/13 if @s[score_ry=13,score_ry_min=13]
function gun:bulletTP/ry/exact/14 if @s[score_ry=14,score_ry_min=14]