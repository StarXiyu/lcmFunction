function gun:bulletTP/ry/exact/151 if @s[score_ry=151,score_ry_min=151]
function gun:bulletTP/ry/exact/152 if @s[score_ry=152,score_ry_min=152]