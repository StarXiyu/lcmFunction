function gun:bulletTP/ry/103-108 if @s[score_ry=108,score_ry_min=103]
function gun:bulletTP/ry/109-113 if @s[score_ry=113,score_ry_min=109]