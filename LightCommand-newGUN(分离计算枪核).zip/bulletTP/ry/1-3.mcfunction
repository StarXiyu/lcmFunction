function gun:bulletTP/ry/1-2 if @s[score_ry=2,score_ry_min=1]
function gun:bulletTP/ry/3-3 if @s[score_ry=3,score_ry_min=3]