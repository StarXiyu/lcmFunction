function gun:bulletTP/ry/exact/131 if @s[score_ry=131,score_ry_min=131]
function gun:bulletTP/ry/exact/132 if @s[score_ry=132,score_ry_min=132]