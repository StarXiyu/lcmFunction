function gun:bulletTP/ry/128-129 if @s[score_ry=129,score_ry_min=128]
function gun:bulletTP/ry/130-130 if @s[score_ry=130,score_ry_min=130]