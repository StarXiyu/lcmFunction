function gun:bulletTP/ry/109-110 if @s[score_ry=110,score_ry_min=109]
function gun:bulletTP/ry/111-111 if @s[score_ry=111,score_ry_min=111]