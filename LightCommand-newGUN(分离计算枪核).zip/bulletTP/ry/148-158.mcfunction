function gun:bulletTP/ry/148-153 if @s[score_ry=153,score_ry_min=148]
function gun:bulletTP/ry/154-158 if @s[score_ry=158,score_ry_min=154]