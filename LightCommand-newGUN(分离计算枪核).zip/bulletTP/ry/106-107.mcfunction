function gun:bulletTP/ry/exact/106 if @s[score_ry=106,score_ry_min=106]
function gun:bulletTP/ry/exact/107 if @s[score_ry=107,score_ry_min=107]