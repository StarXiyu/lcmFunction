function gun:bulletTP/ry/114-119 if @s[score_ry=119,score_ry_min=114]
function gun:bulletTP/ry/120-124 if @s[score_ry=124,score_ry_min=120]