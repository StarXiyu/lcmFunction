function gun:bulletTP/ry/10-11 if @s[score_ry=11,score_ry_min=10]
function gun:bulletTP/ry/12-12 if @s[score_ry=12,score_ry_min=12]