function gun:bulletTP/ry/136-141 if @s[score_ry=141,score_ry_min=136]
function gun:bulletTP/ry/142-147 if @s[score_ry=147,score_ry_min=142]