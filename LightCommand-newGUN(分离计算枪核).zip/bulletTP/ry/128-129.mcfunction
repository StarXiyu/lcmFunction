function gun:bulletTP/ry/exact/128 if @s[score_ry=128,score_ry_min=128]
function gun:bulletTP/ry/exact/129 if @s[score_ry=129,score_ry_min=129]