function gun:bulletTP/ry/exact/125 if @s[score_ry=125,score_ry_min=125]
function gun:bulletTP/ry/exact/126 if @s[score_ry=126,score_ry_min=126]