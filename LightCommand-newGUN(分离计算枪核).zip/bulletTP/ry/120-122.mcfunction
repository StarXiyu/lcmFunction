function gun:bulletTP/ry/120-121 if @s[score_ry=121,score_ry_min=120]
function gun:bulletTP/ry/122-122 if @s[score_ry=122,score_ry_min=122]