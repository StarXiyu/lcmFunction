function gun:bulletTP/ry/145-146 if @s[score_ry=146,score_ry_min=145]
function gun:bulletTP/ry/147-147 if @s[score_ry=147,score_ry_min=147]