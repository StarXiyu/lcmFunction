function gun:bulletTP/ry/exact/139 if @s[score_ry=139,score_ry_min=139]
function gun:bulletTP/ry/exact/140 if @s[score_ry=140,score_ry_min=140]