function gun:bulletTP/ry/1-23 if @s[score_ry=23,score_ry_min=1]
function gun:bulletTP/ry/24-45 if @s[score_ry=45,score_ry_min=24]