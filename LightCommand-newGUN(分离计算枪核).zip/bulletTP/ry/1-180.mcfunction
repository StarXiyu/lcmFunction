function gun:bulletTP/ry/1-90 if @s[score_ry=90,score_ry_min=1]
function gun:bulletTP/ry/91-180 if @s[score_ry=180,score_ry_min=91]