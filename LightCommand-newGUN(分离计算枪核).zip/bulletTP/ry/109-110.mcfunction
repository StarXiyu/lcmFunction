function gun:bulletTP/ry/exact/109 if @s[score_ry=109,score_ry_min=109]
function gun:bulletTP/ry/exact/110 if @s[score_ry=110,score_ry_min=110]