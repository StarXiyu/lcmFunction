# 1.12.2 分离计算版子弹移动
# 第一步：处理仰角 (Y轴)
function gun:bulletTP/rx/n90-90
# 第二步：处理方位角 (XZ轴)
function gun:bulletTP/ry/n180-180