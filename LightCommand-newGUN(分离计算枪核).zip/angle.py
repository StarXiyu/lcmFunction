import os

# ==========================================
# 配置区域 - 请根据你的世界路径修改
# ==========================================
BASE_PATH = r"D:\PCL\.minecraft\versions\1.12.2-Forge_14.23.5.2860\saves\gunNew\data\functions"

RX_MIN, RX_MAX = -90, 90   # 仰俯角范围
RY_MIN, RY_MAX = -180, 180 # 方位角范围

# 最小区间阈值：当区间长度 <= 这个值时，不再递归，直接写入所有整数的 exact 调用
MIN_INTERVAL_THRESHOLD = 2

# ==========================================
# 不需要修改以下代码
# ==========================================

def sanitize_filename(val):
    """安全化文件名：负号替换为'n'"""
    return str(val).replace('-', 'n')

def create_dir_if_not_exists(path):
    """创建目录（如果不存在）"""
    if not os.path.exists(path):
        os.makedirs(path)

def generate_function_file(filepath, commands):
    """生成  文件"""
    dir_name = os.path.dirname(filepath)
    create_dir_if_not_exists(dir_name)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        for cmd in commands:
            f.write(cmd + '\n')

def generate_exact_files_for_range(min_val, max_val, folder_name, axis):
    """为指定范围生成所有单值的精确文件"""
    exact_folder = os.path.join(BASE_PATH, "gun", folder_name, "exact")
    create_dir_if_not_exists(exact_folder)
    
    for angle in range(min_val, max_val + 1):
        filename = f"{sanitize_filename(angle)}"
        filepath = os.path.join(exact_folder, filename)
        
        if axis == "X":  # rx / rxm
            cmd = f"scoreboard players set @s[rxm={angle},rx={angle}] rx {angle}"
        else:  # ry / rym
            cmd = f"scoreboard players set @s[rym={angle},ry={angle}] ry {angle}"
        
        generate_function_file(filepath, [cmd])

def build_optimized_binary_tree(min_val, max_val, folder_name, axis):
    """
    构建优化版二分查找树：
    - 当区间长度 <= MIN_INTERVAL_THRESHOLD 时，直接写入所有整数的 exact 调用
    - 否则二分递归
    - 确保选择器与坐标轴匹配（X轴用rx/rxm，Y轴用ry/rym）
    """
    if min_val > max_val:
        return  # ⚠️ 非法区间，直接返回
    
    current_file = f"{sanitize_filename(min_val)}-{sanitize_filename(max_val)}"
    full_path = os.path.join(BASE_PATH, "gun", folder_name, current_file)
    
    commands = []
    range_size = max_val - min_val + 1
    
    if range_size <= MIN_INTERVAL_THRESHOLD:
        # 区间足够小，直接写入所有整数的 exact 调用
        for angle in range(min_val, max_val + 1):
            exact_file = f"{sanitize_filename(angle)}"
            if axis == "X":
                cond = f"@s[rxm={angle},rx={angle}]"
            else:  # Y轴
                cond = f"@s[rym={angle},ry={angle}]"
            cmd = f"function gun:{folder_name}/exact/{exact_file} if {cond}"
            commands.append(cmd)
        
    else:
        # 区间较大，进行二分
        mid = (min_val + max_val) // 2
        
        # 左区间：min_val 到 mid
        left_child_file = f"{sanitize_filename(min_val)}-{sanitize_filename(mid)}"
        if axis == "X":
            left_cmd = f"function gun:{folder_name}/{left_child_file} if @s[rxm={min_val},rx={mid}]"
        else:
            left_cmd = f"function gun:{folder_name}/{left_child_file} if @s[rym={min_val},ry={mid}]"
        commands.append(left_cmd)
        
        # 右区间：mid+1 到 max_val
        right_child_file = f"{sanitize_filename(mid+1)}-{sanitize_filename(max_val)}"
        if axis == "X":
            right_cmd = f"function gun:{folder_name}/{right_child_file} if @s[rxm={mid+1},rx={max_val}]"
        else:
            right_cmd = f"function gun:{folder_name}/{right_child_file} if @s[rym={mid+1},ry={max_val}]"
        commands.append(right_cmd)
        
        # 递归构建左右子树
        build_optimized_binary_tree(min_val, mid, folder_name, axis)
        build_optimized_binary_tree(mid + 1, max_val, folder_name, axis)
    
    generate_function_file(full_path, commands)

def main():
    print(f"开始生成优化版精确指令文件到路径: {BASE_PATH}")
    
    # 创建根目录结构
    rx_folder = os.path.join(BASE_PATH, "gun", "getRX")
    ry_folder = os.path.join(BASE_PATH, "gun", "getRY")
    
    create_dir_if_not_exists(rx_folder)
    create_dir_if_not_exists(ry_folder)
    
    # ================================
    # 第一步：生成所有单值精确文件
    # ================================
    
    print("正在生成 X 轴 (rx) 精确文件...")
    generate_exact_files_for_range(RX_MIN, RX_MAX, "getRX", "X")
    
    print("正在生成 Y 轴 (ry) 精确文件...")
    generate_exact_files_for_range(RY_MIN, RY_MAX, "getRY", "Y")
    
    # ================================
    # 第二步：构建优化版二分查找树
    # ================================
    
    print("正在构建 X 轴 (getRX) 优化二分查找树...")
    build_optimized_binary_tree(RX_MIN, RX_MAX, "getRX", "X")
    
    print("正在构建 Y 轴 (getRY) 优化二分查找树...")
    build_optimized_binary_tree(RY_MIN, RY_MAX, "getRY", "Y")
    
    # ================================
    # 第三步：生成入口函数 main
    # ================================
    
    rx_main_path = os.path.join(BASE_PATH, "gun", "getRX", "main")
    rx_main_cmds = [f"function gun:getRX/{sanitize_filename(RX_MIN)}-{sanitize_filename(RX_MAX)}"]
    generate_function_file(rx_main_path, rx_main_cmds)
    
    ry_main_path = os.path.join(BASE_PATH, "gun", "getRY", "main")
    ry_main_cmds = [f"function gun:getRY/{sanitize_filename(RY_MIN)}-{sanitize_filename(RY_MAX)}"]
    generate_function_file(ry_main_path, ry_main_cmds)
    
    print("✅ 所有文件生成完成！")
    print("你可以通过以下命令在游戏内调用：")
    print("  /function gun:getRX/main   ← 获取玩家仰俯角到计分板 rx")
    print("  /function gun:getRY/main   ← 获取玩家方位角到计分板 ry")

if __name__ == "__main__":
    main()