import os
import math

# ==========================================
# 配置区域
# ==========================================
BASE_PATH = r"D:\PCL\.minecraft\versions\1.12.2-Forge_14.23.5.2860\saves\gunNew\data\functions"
RX_MIN, RX_MAX = -90, 90
RY_MIN, RY_MAX = -180, 180
MIN_INTERVAL_THRESHOLD = 2

# ==========================================
# 工具函数
# ==========================================
def sanitize_filename(val):
    return str(val).replace('-', 'n')

def create_dir_if_not_exists(path):
    if not os.path.exists(path):
        os.makedirs(path)

def generate_function_file(filepath, commands):
    dir_name = os.path.dirname(filepath)
    create_dir_if_not_exists(dir_name)
    if not filepath.endswith('.mcfunction'):
        filepath += '.mcfunction'
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('\n'.join(commands))

# ==========================================
# 第一部分：仰角 (rx) 计算
# ==========================================
def calculate_rx_dy(rx):
    rx_rad = math.radians(rx)
    dy = -math.sin(rx_rad)
    return round(dy, 6)

def build_rx_tree(min_val, max_val):
    if min_val > max_val:
        return

    # 确保 rx 目录存在
    create_dir_if_not_exists(os.path.join(BASE_PATH, "gun", "bulletTP", "rx"))

    current_file = f"rx/{sanitize_filename(min_val)}-{sanitize_filename(max_val)}"
    full_path = os.path.join(BASE_PATH, "gun", "bulletTP", current_file)
    commands = []
    range_size = max_val - min_val + 1

    if range_size <= MIN_INTERVAL_THRESHOLD:
        # 创建 exact 目录
        exact_dir = os.path.join(BASE_PATH, "gun", "bulletTP", "rx", "exact")
        create_dir_if_not_exists(exact_dir)

        for rx in range(min_val, max_val + 1):
            dy = calculate_rx_dy(rx)
            exact_path = os.path.join(exact_dir, sanitize_filename(rx))
            cmd = f"tp @s ~ ~{dy} ~"
            generate_function_file(exact_path, [cmd])

        # 添加精确调用命令到父节点
        for rx in range(min_val, max_val + 1):
            exact_name = sanitize_filename(rx)
            commands.append(f"function gun:bulletTP/rx/exact/{exact_name} if @s[score_rx={rx},score_rx_min={rx}]")

    else:
        mid = (min_val + max_val) // 2
        left_file = f"rx/{sanitize_filename(min_val)}-{sanitize_filename(mid)}"
        right_file = f"rx/{sanitize_filename(mid+1)}-{sanitize_filename(max_val)}"
        
        commands.append(f"function gun:bulletTP/{left_file} if @s[score_rx={mid},score_rx_min={min_val}]")
        commands.append(f"function gun:bulletTP/{right_file} if @s[score_rx={max_val},score_rx_min={mid+1}]")

        build_rx_tree(min_val, mid)
        build_rx_tree(mid + 1, max_val)

    # 强制生成当前节点文件，即使它是叶子节点
    generate_function_file(full_path, commands)

# ==========================================
# 第二部分：方位角 (ry) 计算
# ==========================================
def calculate_ry_vector(ry):
    ry_rad = math.radians(ry)
    dx = -math.sin(ry_rad)
    dz = math.cos(ry_rad)
    return round(dx, 6), round(dz, 6)

def build_ry_tree(min_val, max_val):
    if min_val > max_val:
        return

    # 确保 ry 目录存在
    create_dir_if_not_exists(os.path.join(BASE_PATH, "gun", "bulletTP", "ry"))

    current_file = f"ry/{sanitize_filename(min_val)}-{sanitize_filename(max_val)}"
    full_path = os.path.join(BASE_PATH, "gun", "bulletTP", current_file)
    commands = []
    range_size = max_val - min_val + 1

    if range_size <= MIN_INTERVAL_THRESHOLD:
        # 创建 exact 目录
        exact_dir = os.path.join(BASE_PATH, "gun", "bulletTP", "ry", "exact")
        create_dir_if_not_exists(exact_dir)

        for ry in range(min_val, max_val + 1):
            dx, dz = calculate_ry_vector(ry)
            exact_path = os.path.join(exact_dir, sanitize_filename(ry))
            cmd = f"tp @s ~{dx} ~ ~{dz}"
            generate_function_file(exact_path, [cmd])

        for ry in range(min_val, max_val + 1):
            exact_name = sanitize_filename(ry)
            commands.append(f"function gun:bulletTP/ry/exact/{exact_name} if @s[score_ry={ry},score_ry_min={ry}]")

    else:
        mid = (min_val + max_val) // 2
        left_file = f"ry/{sanitize_filename(min_val)}-{sanitize_filename(mid)}"
        right_file = f"ry/{sanitize_filename(mid+1)}-{sanitize_filename(max_val)}"
        
        commands.append(f"function gun:bulletTP/{left_file} if @s[score_ry={mid},score_ry_min={min_val}]")
        commands.append(f"function gun:bulletTP/{right_file} if @s[score_ry={max_val},score_ry_min={mid+1}]")

        build_ry_tree(min_val, mid)
        build_ry_tree(mid + 1, max_val)

    # 强制生成当前节点文件，即使它是叶子节点
    generate_function_file(full_path, commands)

# ==========================================
# 主函数：生成 main.mcfunction 并确保子文件已生成
# ==========================================
def main():
    print(f"开始生成 1.12.2 版 bulletTP 文件到: {BASE_PATH}")
    base_folder_path = os.path.join(BASE_PATH, "gun", "bulletTP")
    create_dir_if_not_exists(base_folder_path)

    # 确保 rx 和 ry 的根目录存在
    create_dir_if_not_exists(os.path.join(base_folder_path, "rx"))
    create_dir_if_not_exists(os.path.join(base_folder_path, "ry"))

    # 检查 rx/n90-90 和 ry/n180-180 是否已生成，如果没有则生成
    rx_main_file = os.path.join(base_folder_path, "rx", "n90-90.mcfunction")
    ry_main_file = os.path.join(base_folder_path, "ry", "n180-180.mcfunction")

    if not os.path.exists(rx_main_file) or not os.path.exists(ry_main_file):
        print("检测到 rx 或 ry 的主文件未生成，正在重新生成...")
        # 显式调用构建函数，确保根节点被创建
        build_rx_tree(RX_MIN, RX_MAX)  # 这会强制生成 n90-90
        build_ry_tree(RY_MIN, RY_MAX)  # 这会强制生成 n180-180
        print("rx 和 ry 的文件树已成功生成。")
    else:
        print("rx 和 ry 的文件树已存在。")

    # 生成 main.mcfunction
    main_commands = [
        "# 1.12.2 分离计算版子弹移动",
        "# 第一步：处理仰角 (Y轴)",
        "function gun:bulletTP/rx/n90-90",
        "# 第二步：处理方位角 (XZ轴)",
        "function gun:bulletTP/ry/n180-180"
    ]
    
    main_path = os.path.join(base_folder_path, "main.mcfunction")
    generate_function_file(main_path, main_commands)
    
    print("✅ main.mcfunction 文件已成功生成！")
    print("🎉 恭喜！现在你可以安全地使用 /function gun:bulletTP/main 命令了。")
    print("📌 检查方法：请确认文件路径 D:\\PCL\\.minecraft\\versions\\1.12.2-Forge_14.23.5.2860\\saves\\gunNew\\data\\functions\\gun\\bulletTP\\main.mcfunction 存在。")
    print("📌 并确认其内容为：")
    print("   function gun:bulletTP/rx/n90-90")
    print("   function gun:bulletTP/ry/n180-180")

if __name__ == "__main__":
    main()