
scoreboard players add @s bulletTime 1
kill @s[score_bulletTime_min=400]

function gun:killBullet unless @a[r=200]

particle fireworksSpark ~ ~ ~ 0 0 0 0 1 force @a

execute @s ~ ~ ~ detect ~ ~ ~ air * scoreboard players tag @s add temp.gun.bullet.allowFired
function gun:bulletTP/main if @s[tag=temp.gun.bullet.allowFired]
kill @s[tag=!temp.gun.bullet.allowFired]
scoreboard players tag @s remove temp.gun.bullet.allowFired