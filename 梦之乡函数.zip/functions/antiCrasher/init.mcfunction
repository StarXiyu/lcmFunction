
scoreboard objectives remove antiCrasher
scoreboard objectives add antiCrasher dummy
scoreboard objectives add crasherCount dummy

scoreboard players set 20 antiCrasher 20

summon minecraft:armor_stand ~ ~1 ~ {CustomName:"§fantiCrasher.armor §e此盔甲架用于反崩，切勿清除！",Tags:["antiCrasher.armor"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}

## execute @e[tag=antiCrasher.armor] ~ ~ ~ /function anticrasher:start