
## 未移动的玩家
scoreboard players add @s walk 0

## 比率
scoreboard players operation @s math1 = @s walk
scoreboard players operation @s math1 /= 2000 math
scoreboard players operation @s math2 += @s math1

scoreboard players operation @s math1 0
scoreboard players operation @s math1 += @s mineCobble
scoreboard players operation @s math1 += @s mineLapis
scoreboard players operation @s math1 += @s mineCoal
scoreboard players operation @s math1 += @s mineIron
scoreboard players operation @s math1 += @s mineGold
scoreboard players operation @s math1 += @s mineEme
scoreboard players operation @s math1 += @s mineDiamond
scoreboard players operation @s math1 /= 10 math
scoreboard players operation @s math2 += @s math1

scoreboard players operation @s math1 = @s display.kill
scoreboard players operation @s math1 /= 2 math
scoreboard players operation @s math2 += @s math1

scoreboard players operation @s math3 = @s onlinetime
scoreboard players operation @s math3 /= @s math2