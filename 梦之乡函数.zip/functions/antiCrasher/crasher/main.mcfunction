
execute @a[score_onlinetime=36000,tag=!op] ~ ~ ~ function antiCrasher:crasher/selectSubject

scoreboard players tag @a[score_onlinetime_min=2400,score_walk_min=1,score_onlinetime=36000,tag=!op] add sort.temp.subject
execute @a[tag=sort.temp.subject] ~ ~ ~ scoreboard players operation @s sort.hand = @s math3
function sort:DescendingOrder/main

scoreboard players tag @a[score_sort.out_min=1,score_sort.out=3] add antiCrasher.ban

scoreboard players tag @a[tag=antiCrasher.ban] add tempban.ban
scoreboard players set @a[tag=antiCrasher.ban] tempBanU3 1
scoreboard players operation @a[tag=antiCrasher.ban] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[tag=antiCrasher.ban] tempBanT1 2400

scoreboard players tag @a[tag=antiCrasher.ban] remove antiCrasher.ban

tellraw @a [{"text":"[","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LightAC","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"] ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":">> ","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"服务器延迟 ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"antiCrasher","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" ticks","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard players tag @a[score_onlinetime=2400] add tempban.ban
scoreboard players set @a[score_onlinetime=2400] tempBanU3 1
scoreboard players operation @a[score_onlinetime=2400] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[score_onlinetime=2400] tempBanT1 2400

scoreboard players tag @a[score_walk=0,score_walk_min=0] add tempban.ban
scoreboard players set @a[score_walk=0,score_walk_min=0] tempBanU3 1
scoreboard players operation @a[score_walk=0,score_walk_min=0] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[score_walk=0,score_walk_min=0] tempBanT1 2400