
## start
function antiCrasher:start if @s[score_antiCrasher_min=1]

worldborder get

scoreboard players operation @s antiCrasher -= worldborder antiCrasher

execute @s[score_antiCrasher_min=50] ~ ~ ~ function antiCrasher:crasher/main if @s[tag=!temp.antiCrasher.stop]

## execute @e[tag=antiCrasher.armor] ~ ~ ~ function anticrasher:main