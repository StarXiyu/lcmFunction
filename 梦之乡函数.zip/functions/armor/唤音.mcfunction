scoreboard players tag @s remove temp.唤音

scoreboard players add @s a.critPob 15
scoreboard players add @s a.phyAttack 150