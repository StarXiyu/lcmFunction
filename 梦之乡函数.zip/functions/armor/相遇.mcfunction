
scoreboard players tag @s remove temp.相遇

scoreboard players add @s a.dodge 4
scoreboard players add @s a.maxhealth 75
scoreboard players add @s a.spellResist 80
scoreboard players add @s a.physicsResist 80