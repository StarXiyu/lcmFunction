scoreboard players tag @s remove temp.艳红
scoreboard players add @s a.critPob 10
scoreboard players add @s a.phyAttack 20