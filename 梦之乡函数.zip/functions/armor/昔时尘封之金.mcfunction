scoreboard players tag @s remove temp.昔时尘封之金

scoreboard players add @s a.spellPene 60
scoreboard players add @s a.physicsPene 60
scoreboard players add @s a.critPob 25