scoreboard players tag @s remove temp.空灵之梦
scoreboard players add @s a.dodge 80
scoreboard players add @s a.maxhealth 35000
scoreboard players add @s a.spellResist 1500
scoreboard players add @s a.physicsResist 1500

scoreboard players add @s a.critAttack 80

scoreboard players add @s a.seize 100
