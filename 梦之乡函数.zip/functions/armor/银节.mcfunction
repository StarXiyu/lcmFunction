scoreboard players tag @s remove temp.银节

scoreboard players add @s a.hit 20
scoreboard players add @s a.regeneration 12
scoreboard players add @s a.vampirism.rate 40
scoreboard players add @s a.vampirism 25