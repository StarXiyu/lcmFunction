
scoreboard players tag @s remove temp.影之光
scoreboard players add @s a.slow 30

scoreboard players set @s math.armor 0
scoreboard players operation @s math.armor = @s a.maxhealth
scoreboard players operation @s math.armor *= 40 math
scoreboard players operation @s math.armor /= 100 math
scoreboard players operation @s a.maxhealth -= @s math.armor

scoreboard players operation @s math.armor /= 2 math
scoreboard players operation @s a.phyAttack += @s math.armor
scoreboard players operation @s a.spellAttack += @s math.armor