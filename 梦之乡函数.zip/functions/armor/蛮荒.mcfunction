
scoreboard players tag @s remove temp.蛮荒

scoreboard players add @s a.dodge 4
scoreboard players add @s a.maxhealth 210
scoreboard players add @s a.spellResist 50
scoreboard players add @s a.physicsResist 50