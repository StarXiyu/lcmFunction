scoreboard players tag @s remove temp.通天1

scoreboard players add @s a.dodge 8
scoreboard players add @s a.maxhealth 2200
scoreboard players add @s a.spellResist 280
scoreboard players add @s a.physicsResist 280
scoreboard players add @s a.critPob 7
scoreboard players add @s a.critAttack 18
scoreboard players add @s a.vampirism 8
scoreboard players add @s a.seize 10
scoreboard players add @s a.spellAttack 180