
scoreboard players tag @s remove temp.光之影
scoreboard players add @s a.slow 30

scoreboard players set @s math.armor 0
scoreboard players operation @s math.armor += @s a.physicsResist
scoreboard players operation @s math.armor += @s p.physicsResist
scoreboard players operation @s math.armor += @s n.physicsResist

scoreboard players operation @s math.armor /= 2 math
scoreboard players operation @s a.phyAttack += @s math.armor

scoreboard players set @s math.armor 0
scoreboard players operation @s math.armor += @s a.spellResist
scoreboard players operation @s math.armor += @s p.spellResist
scoreboard players operation @s math.armor += @s n.spellResist

scoreboard players operation @s math.armor /= 2 math
scoreboard players operation @s a.spellAttack += @s math.armor

scoreboard players set @s a.physicsResist 0
scoreboard players set @s p.physicsResist 0
scoreboard players set @s n.physicsResist 0

scoreboard players set @s a.spellResist 0
scoreboard players set @s p.spellResist 0
scoreboard players set @s n.spellResist 0