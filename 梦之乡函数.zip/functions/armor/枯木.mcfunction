
scoreboard players tag @s remove temp.枯木

scoreboard players add @s a.dodge 3
scoreboard players add @s a.maxhealth 600
scoreboard players add @s a.regeneration 8
scoreboard players add @s a.physicsResist 100