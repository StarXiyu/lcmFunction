
scoreboard players tag @s remove temp.静法

scoreboard players add @s a.dodge 4
scoreboard players add @s a.maxhealth 270
scoreboard players add @s a.spellResist 200
scoreboard players add @s a.physicsResist 200