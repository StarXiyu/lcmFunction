scoreboard players tag @s remove temp.钻节

scoreboard players add @s a.regeneration 5
scoreboard players add @s a.reward 80
scoreboard players add @s a.rewardPob 40