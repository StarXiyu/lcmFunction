
scoreboard players tag @s remove temp.暗夜

scoreboard players add @s a.dodge 4
scoreboard players add @s a.maxhealth 60
scoreboard players add @s a.spellResist 60
scoreboard players add @s a.physicsResist 60