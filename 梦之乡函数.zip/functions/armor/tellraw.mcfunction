tellraw @s ""
tellraw @s [{"text":"§f§m§l😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁§7§l< 属性面板 >§f§m§l😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

tellraw @s [{"text":"\n§f§l   物理攻击 "},{"score":{"objective":"d.phyAttack","name":"@s"}},{"text":"§f§l   物理穿透 "},{"score":{"objective":"d.physicsPene","name":"@s"}},{"text":"§f§l§f§l‰"},{"text":"§f§l   物理抵抗 "},{"score":{"objective":"d.physicsResist","name":"@s"}},{"text":"§f§l§f§l‰"}]
tellraw @s [{"text":"§b§l   法术攻击 "},{"score":{"objective":"d.spellAttack","name":"@s"}},{"text":"§b§l   法术穿透 "},{"score":{"objective":"d.spellPene","name":"@s"}},{"text":"§b§l§f§l‰"},{"text":"§b§l   法术抵抗 "},{"score":{"objective":"d.spellResist","name":"@s"}},{"text":"§b§l§f§l‰"}]
tellraw @s [{"text":"§e§l   暴击概率 "},{"score":{"objective":"d.critPob","name":"@s"}},{"text":"§e§l§f§l%"},{"text":"§e§l   暴击伤害 "},{"score":{"objective":"d.critAttack","name":"@s"}},{"text":"§e§l§f§l%"},{"text":"§e§l   暴击抵抗 "},{"score":{"objective":"d.critResist","name":"@s"}},{"text":"§e§l§f§l%"}]
tellraw @s [{"text":"§a§l   吸血概率 "},{"score":{"objective":"d.vampirism","name":"@s"}},{"text":"§a§l§f§l%"},{"text":"§a§l   吸血倍率 "},{"score":{"objective":"d.vampirism.rate","name":"@s"}},{"text":"§a§l§f§l%"}]
tellraw @s [{"text":"§9§l   闪避概率 "},{"score":{"objective":"d.dodge","name":"@s"}},{"text":"§9§l§f§l%"},{"text":"§9§l   命中倍率 "},{"score":{"objective":"d.hit","name":"@s"}},{"text":"§9§l§f§l%"}]
tellraw @s [{"text":"§c§l   赏金 "},{"score":{"objective":"d.reward","name":"@s"}},{"text":"§c§l   赏金猎人 "},{"score":{"objective":"d.rewardPob","name":"@s"}},{"text":"§c§l§f§l%"}]
tellraw @s [{"text":"§2§l   巨力 "},{"score":{"objective":"d.strong","name":"@s"}},{"text":"§2§l§f§l%"},{"text":"§2§l   破败 "},{"score":{"objective":"d.break","name":"@s"}},{"text":"§2§l§f§l%"},{"text":"§2§l   混乱 "},{"score":{"objective":"d.slow","name":"@s"}},{"text":"§2§l§f§l%"}]
tellraw @s [{"text":"§3§l   巨力倍率 "},{"score":{"objective":"d.strong.rate","name":"@s"}},{"text":"§3§l§f§l%"},{"text":"§3§l   破败倍率 "},{"score":{"objective":"d.break.rate","name":"@s"}},{"text":"§3§l§f§l%"}]
tellraw @s [{"text":"§6§l   生命 "},{"score":{"objective":"health","name":"@s"}},{"text":"§6§l   最大生命 "},{"score":{"objective":"maxhealth","name":"@s"}},{"text":"§6§l   恢复 "},{"score":{"objective":"d.regeneration","name":"@s"}}]
tellraw @s [{"text":"§d§l   抢夺 "},{"score":{"objective":"d.seize","name":"@s"}},{"text":"§d§l§f§l‰"}]


tellraw @s [{"text":"\n§f§m§l😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁§7§l< 属性面板 >§f§m§l😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁😁\n","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]