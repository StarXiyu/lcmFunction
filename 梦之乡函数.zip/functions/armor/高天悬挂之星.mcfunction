scoreboard players tag @s remove temp.高天悬挂之星

scoreboard players add @s a.dodge 10
scoreboard players add @s a.maxhealth 400
scoreboard players add @s a.physicsResist 235
scoreboard players add @s a.spellResist 235
scoreboard players add @s a.critPob 15
scoreboard players add @s a.critAttack 20
scoreboard players add @s a.vampirism 15
scoreboard players add @s a.seize 100
scoreboard players add @s a.rewardPob 10
scoreboard players add @s a.reward 15
scoreboard players add @s a.strong 15
scoreboard players add @s a.strong.rate 15