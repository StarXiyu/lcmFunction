
scoreboard players tag @s remove temp.圣火

scoreboard players add @s a.dodge 8
scoreboard players add @s a.maxhealth 1500
scoreboard players add @s a.spellResist 220
scoreboard players add @s a.physicsResist 220
scoreboard players add @s a.critPob 4
scoreboard players add @s a.critAttack 24
scoreboard players add @s a.vampirism 10
scoreboard players add @s a.seize 8
scoreboard players add @s a.spellAttack 200