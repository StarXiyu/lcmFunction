
scoreboard players tag @s remove temp.丛林

scoreboard players add @s a.dodge 3
scoreboard players add @s a.maxhealth 35
scoreboard players add @s a.spellResist 45
scoreboard players add @s a.physicsResist 45