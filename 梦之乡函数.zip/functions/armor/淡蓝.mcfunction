scoreboard players tag @s remove temp.淡蓝
scoreboard players add @s a.spellAttack 18
scoreboard players add @s a.phyAttack 18