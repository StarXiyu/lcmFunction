scoreboard players tag @s remove temp.通天

scoreboard players add @s a.dodge 10
scoreboard players add @s a.maxhealth 2200
scoreboard players add @s a.spellResist 280
scoreboard players add @s a.physicsResist 280
scoreboard players add @s a.critPob 7
scoreboard players add @s a.critAttack 28
scoreboard players add @s a.vampirism 12
scoreboard players add @s a.seize 10
scoreboard players add @s a.spellAttack 280