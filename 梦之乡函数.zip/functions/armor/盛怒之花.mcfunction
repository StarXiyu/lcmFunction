scoreboard players tag @s remove temp.盛怒之花

scoreboard players add @s a.hit 20
scoreboard players add @s a.regeneration 20
scoreboard players add @s a.regeneration 20
scoreboard players add @s a.vampirism 35
scoreboard players add @s a.vampirism.rate 25
scoreboard players add @s a.break.rate 10
scoreboard players add @s a.break 20
scoreboard players add @s a.physicsPene 200
scoreboard players add @s a.spellPene 200
scoreboard players add @s a.maxhealth 200