
scoreboard players tag @s remove temp.行者

scoreboard players add @s a.dodge 5
scoreboard players add @s a.maxhealth 300
scoreboard players add @s a.spellResist 120
scoreboard players add @s a.physicsResist 120
scoreboard players add @s a.critPob 3
scoreboard players add @s a.critAttack 15
scoreboard players add @s a.vampirism 8
scoreboard players add @s a.seize 5
scoreboard players add @s a.spellAttack 80