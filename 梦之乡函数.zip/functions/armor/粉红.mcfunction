scoreboard players tag @s remove temp.粉红
scoreboard players add @s a.spellAttack 40
