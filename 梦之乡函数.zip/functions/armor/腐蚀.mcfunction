
scoreboard players tag @s remove temp.腐蚀

scoreboard players add @s a.dodge 3
scoreboard players add @s a.maxhealth 180
scoreboard players add @s a.spellResist 10
scoreboard players add @s a.physicsResist 10