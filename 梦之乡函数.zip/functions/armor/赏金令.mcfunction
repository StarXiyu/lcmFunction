scoreboard players tag @s remove temp.赏金令

scoreboard players add @s a.reward 60
scoreboard players add @s a.rewardPob 20