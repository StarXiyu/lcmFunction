scoreboard players tag @s remove temp.金节

scoreboard players add @s a.break 30
scoreboard players add @s a.strong 20
scoreboard players add @s a.strong.rate 15
scoreboard players add @s a.break.rate 15
scoreboard players add @s a.slow 30