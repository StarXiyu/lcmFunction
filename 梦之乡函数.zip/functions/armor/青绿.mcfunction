scoreboard players tag @s remove temp.青绿
scoreboard players add @s a.critPob 30