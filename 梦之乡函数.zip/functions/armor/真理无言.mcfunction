scoreboard players tag @s remove temp.真理无言
scoreboard players add @s a.spellAttack 60
scoreboard players add @s a.critPob 10
scoreboard players add @s a.spellPene 80