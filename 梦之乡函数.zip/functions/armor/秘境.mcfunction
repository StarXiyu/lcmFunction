
scoreboard players tag @s remove temp.秘境

scoreboard players add @s a.dodge 2
scoreboard players add @s a.maxhealth 15
scoreboard players add @s a.spellResist 20
scoreboard players add @s a.physicsResist 20