
## 重置
	scoreboard players operation @s maxhealth -= @s a.maxhealth
	scoreboard players set @s a.maxhealth 0
	scoreboard players set @s a.phyAttack 0
	scoreboard players set @s a.spellAttack 0
	scoreboard players set @s a.critPob 0
	scoreboard players set @s a.critAttack 150
	scoreboard players set @s a.seize 0
	scoreboard players set @s a.vampirism 0
	scoreboard players set @s a.physicsPene 0
	scoreboard players set @s a.spellPene 0
	scoreboard players set @s a.spellResist 0
	scoreboard players set @s a.physicsResist 0
	scoreboard players set @s a.dodge 0
	scoreboard players set @s a.critResist 0
	scoreboard players set @s a.hit 0
	scoreboard players set @s a.vampirism.rate 0
	scoreboard players set @s a.regeneration 0
	scoreboard players set @s a.slow 0
	scoreboard players set @s a.break 0
	scoreboard players set @s a.strong 0
	scoreboard players set @s a.reward 0
	scoreboard players set @s a.rewardPob 0
	scoreboard players set @s a.break.rate 0
	scoreboard players set @s a.strong.rate 0
	
## 武器
	function weapon:main
	
## 定制
	function 定制:armor/main if @s[tag=定制]
	
## 秘境
	scoreboard players tag @s add temp.秘境 {Inventory:[{Slot:103b,tag:{Tags:["秘境1"]}}]}
	function armor:秘境 if @s[tag=temp.秘境]
	scoreboard players tag @s add temp.秘境 {Inventory:[{Slot:102b,tag:{Tags:["秘境2"]}}]}
	function armor:秘境 if @s[tag=temp.秘境]
	scoreboard players tag @s add temp.秘境 {Inventory:[{Slot:101b,tag:{Tags:["秘境3"]}}]}
	function armor:秘境 if @s[tag=temp.秘境]
	scoreboard players tag @s add temp.秘境 {Inventory:[{Slot:100b,tag:{Tags:["秘境4"]}}]}
	function armor:秘境 if @s[tag=temp.秘境]
	
## 丛林
	scoreboard players tag @s add temp.丛林 {Inventory:[{Slot:103b,tag:{Tags:["丛林1"]}}]}
	function armor:丛林 if @s[tag=temp.丛林]
	scoreboard players tag @s add temp.丛林 {Inventory:[{Slot:102b,tag:{Tags:["丛林2"]}}]}
	function armor:丛林 if @s[tag=temp.丛林]
	scoreboard players tag @s add temp.丛林 {Inventory:[{Slot:101b,tag:{Tags:["丛林3"]}}]}
	function armor:丛林 if @s[tag=temp.丛林]
	scoreboard players tag @s add temp.丛林 {Inventory:[{Slot:100b,tag:{Tags:["丛林4"]}}]}
	function armor:丛林 if @s[tag=temp.丛林]
	
## 暗夜
	scoreboard players tag @s add temp.暗夜 {Inventory:[{Slot:103b,tag:{Tags:["暗夜1"]}}]}
	function armor:暗夜 if @s[tag=temp.暗夜]
	scoreboard players tag @s add temp.暗夜 {Inventory:[{Slot:102b,tag:{Tags:["暗夜2"]}}]}
	function armor:暗夜 if @s[tag=temp.暗夜]
	scoreboard players tag @s add temp.暗夜 {Inventory:[{Slot:101b,tag:{Tags:["暗夜3"]}}]}
	function armor:暗夜 if @s[tag=temp.暗夜]
	scoreboard players tag @s add temp.暗夜 {Inventory:[{Slot:100b,tag:{Tags:["暗夜4"]}}]}
	function armor:暗夜 if @s[tag=temp.暗夜]
	
## 腐蚀
	scoreboard players tag @s add temp.腐蚀 {Inventory:[{Slot:103b,tag:{Tags:["腐蚀1"]}}]}
	function armor:腐蚀 if @s[tag=temp.腐蚀]
	scoreboard players tag @s add temp.腐蚀 {Inventory:[{Slot:102b,tag:{Tags:["腐蚀2"]}}]}
	function armor:腐蚀 if @s[tag=temp.腐蚀]
	scoreboard players tag @s add temp.腐蚀 {Inventory:[{Slot:101b,tag:{Tags:["腐蚀3"]}}]}
	function armor:腐蚀 if @s[tag=temp.腐蚀]
	scoreboard players tag @s add temp.腐蚀 {Inventory:[{Slot:100b,tag:{Tags:["腐蚀4"]}}]}
	function armor:腐蚀 if @s[tag=temp.腐蚀]
	
## 相遇
	scoreboard players tag @s add temp.相遇 {Inventory:[{Slot:103b,tag:{Tags:["相遇1"]}}]}
	function armor:相遇 if @s[tag=temp.相遇]
	scoreboard players tag @s add temp.相遇 {Inventory:[{Slot:102b,tag:{Tags:["相遇2"]}}]}
	function armor:相遇 if @s[tag=temp.相遇]
	scoreboard players tag @s add temp.相遇 {Inventory:[{Slot:101b,tag:{Tags:["相遇3"]}}]}
	function armor:相遇 if @s[tag=temp.相遇]
	scoreboard players tag @s add temp.相遇 {Inventory:[{Slot:100b,tag:{Tags:["相遇4"]}}]}
	function armor:相遇 if @s[tag=temp.相遇]
	
## 相遇
	scoreboard players tag @s add temp.蛮荒 {Inventory:[{Slot:103b,tag:{Tags:["蛮荒"]}}]}
	function armor:蛮荒 if @s[tag=temp.蛮荒]
	scoreboard players tag @s add temp.蛮荒 {Inventory:[{Slot:102b,tag:{Tags:["蛮荒"]}}]}
	function armor:蛮荒 if @s[tag=temp.蛮荒]
	scoreboard players tag @s add temp.蛮荒 {Inventory:[{Slot:101b,tag:{Tags:["蛮荒"]}}]}
	function armor:蛮荒 if @s[tag=temp.蛮荒]
	scoreboard players tag @s add temp.蛮荒 {Inventory:[{Slot:100b,tag:{Tags:["蛮荒"]}}]}
	function armor:蛮荒 if @s[tag=temp.蛮荒]

## 金币抽奖副手
	scoreboard players tag @s add temp.青绿 {Inventory:[{Slot:-106b,tag:{Tags:["青绿"]}}]}
	function armor:青绿 if @s[tag=temp.青绿]
	scoreboard players tag @s add temp.艳红 {Inventory:[{Slot:-106b,tag:{Tags:["艳红"]}}]}
	function armor:艳红 if @s[tag=temp.艳红]
	scoreboard players tag @s add temp.粉红 {Inventory:[{Slot:-106b,tag:{Tags:["粉红"]}}]}
	function armor:粉红 if @s[tag=temp.粉红]
	scoreboard players tag @s add temp.淡蓝 {Inventory:[{Slot:-106b,tag:{Tags:["淡蓝"]}}]}
	function armor:淡蓝 if @s[tag=temp.淡蓝]
	scoreboard players tag @s add temp.昔时尘封之金 {Inventory:[{Slot:-106b,tag:{Tags:["昔时尘封之金"]}}]}
	function armor:昔时尘封之金 if @s[tag=temp.昔时尘封之金]
	scoreboard players tag @s add temp.唤音 {Inventory:[{Slot:-106b,tag:{Tags:["唤音"]}}]}
	function armor:唤音 if @s[tag=temp.唤音]
	scoreboard players tag @s add temp.真理无言 {Inventory:[{Slot:-106b,tag:{Tags:["真理无言"]}}]}
	function armor:真理无言 if @s[tag=temp.真理无言]
	
## 积分抽奖副手
	scoreboard players tag @s add temp.银节 {Inventory:[{Slot:-106b,tag:{Tags:["银节"]}}]}
	function armor:银节 if @s[tag=temp.银节]
	scoreboard players tag @s add temp.金节 {Inventory:[{Slot:-106b,tag:{Tags:["金节"]}}]}
	function armor:金节 if @s[tag=temp.金节]	
	scoreboard players tag @s add temp.钻节 {Inventory:[{Slot:-106b,tag:{Tags:["钻节"]}}]}
	function armor:钻节 if @s[tag=temp.钻节]
	
## 圣火
	scoreboard players tag @s add temp.圣火 {Inventory:[{Slot:103b,tag:{Tags:["圣火"]}}]}
	function armor:圣火 if @s[tag=temp.圣火]
	scoreboard players tag @s add temp.圣火 {Inventory:[{Slot:102b,tag:{Tags:["圣火"]}}]}
	function armor:圣火 if @s[tag=temp.圣火]
	scoreboard players tag @s add temp.圣火 {Inventory:[{Slot:101b,tag:{Tags:["圣火"]}}]}
	function armor:圣火 if @s[tag=temp.圣火]
	scoreboard players tag @s add temp.圣火 {Inventory:[{Slot:100b,tag:{Tags:["圣火"]}}]}
	function armor:圣火 if @s[tag=temp.圣火]
	
## 通天
	scoreboard players tag @s add temp.通天 {Inventory:[{Slot:103b,tag:{Tags:["通天"]}}]}
	function armor:通天 if @s[tag=temp.通天]
	scoreboard players tag @s add temp.通天 {Inventory:[{Slot:102b,tag:{Tags:["通天"]}}]}
	function armor:通天 if @s[tag=temp.通天]
	scoreboard players tag @s add temp.通天 {Inventory:[{Slot:101b,tag:{Tags:["通天"]}}]}
	function armor:通天 if @s[tag=temp.通天]
	scoreboard players tag @s add temp.通天 {Inventory:[{Slot:100b,tag:{Tags:["通天"]}}]}
	function armor:通天 if @s[tag=temp.通天]
	
## 行者
	scoreboard players tag @s add temp.行者 {Inventory:[{Slot:103b,tag:{Tags:["行者"]}}]}
	function armor:行者 if @s[tag=temp.行者]
	scoreboard players tag @s add temp.行者 {Inventory:[{Slot:102b,tag:{Tags:["行者"]}}]}
	function armor:行者 if @s[tag=temp.行者]
	scoreboard players tag @s add temp.行者 {Inventory:[{Slot:101b,tag:{Tags:["行者"]}}]}
	function armor:行者 if @s[tag=temp.行者]
	scoreboard players tag @s add temp.行者 {Inventory:[{Slot:100b,tag:{Tags:["行者"]}}]}
	function armor:行者 if @s[tag=temp.行者]
	
## 影流
	scoreboard players tag @s add temp.影流 {Inventory:[{Slot:103b,tag:{Tags:["影流"]}}]}
	function armor:影流 if @s[tag=temp.影流]
	scoreboard players tag @s add temp.影流 {Inventory:[{Slot:102b,tag:{Tags:["影流"]}}]}
	function armor:影流 if @s[tag=temp.影流]
	scoreboard players tag @s add temp.影流 {Inventory:[{Slot:101b,tag:{Tags:["影流"]}}]}
	function armor:影流 if @s[tag=temp.影流]
	scoreboard players tag @s add temp.影流 {Inventory:[{Slot:100b,tag:{Tags:["影流"]}}]}
	function armor:影流 if @s[tag=temp.影流]

## 静法
	scoreboard players tag @s add temp.静法 {Inventory:[{Slot:103b,tag:{Tags:["静法"]}}]}
	function armor:静法 if @s[tag=temp.静法]
	scoreboard players tag @s add temp.静法 {Inventory:[{Slot:102b,tag:{Tags:["静法"]}}]}
	function armor:静法 if @s[tag=temp.静法]
	scoreboard players tag @s add temp.静法 {Inventory:[{Slot:101b,tag:{Tags:["静法"]}}]}
	function armor:静法 if @s[tag=temp.静法]
	scoreboard players tag @s add temp.静法 {Inventory:[{Slot:100b,tag:{Tags:["静法"]}}]}
	function armor:静法 if @s[tag=temp.静法]
	
## 枯木
	scoreboard players tag @s add temp.枯木 {Inventory:[{Slot:103b,tag:{Tags:["枯木"]}}]}
	function armor:枯木 if @s[tag=temp.枯木]
	scoreboard players tag @s add temp.枯木 {Inventory:[{Slot:102b,tag:{Tags:["枯木"]}}]}
	function armor:枯木 if @s[tag=temp.枯木]
	scoreboard players tag @s add temp.枯木 {Inventory:[{Slot:101b,tag:{Tags:["枯木"]}}]}
	function armor:枯木 if @s[tag=temp.枯木]
	scoreboard players tag @s add temp.枯木 {Inventory:[{Slot:100b,tag:{Tags:["枯木"]}}]}
	function armor:枯木 if @s[tag=temp.枯木]
	
## 赏金令
	scoreboard players tag @s add temp.赏金令 {Inventory:[{Slot:-106b,tag:{Tags:["赏金令"]}}]}
	function armor:赏金令 if @s[tag=temp.赏金令]
	
## 盛怒之花
	scoreboard players tag @s add temp.盛怒之花 {Inventory:[{Slot:-106b,tag:{Tags:["盛怒之花"]}}]}
	function armor:盛怒之花 if @s[tag=temp.盛怒之花]
	
## 空灵之梦
	scoreboard players tag @s add temp.空灵之梦 {Inventory:[{Slot:103b,tag:{Tags:["空灵之梦"]}}]}
	function armor:空灵之梦 if @s[tag=temp.空灵之梦]
	scoreboard players tag @s add temp.空灵之梦 {Inventory:[{Slot:102b,tag:{Tags:["空灵之梦"]}}]}
	function armor:空灵之梦 if @s[tag=temp.空灵之梦]
	scoreboard players tag @s add temp.空灵之梦 {Inventory:[{Slot:101b,tag:{Tags:["空灵之梦"]}}]}
	function armor:空灵之梦 if @s[tag=temp.空灵之梦]
	scoreboard players tag @s add temp.空灵之梦 {Inventory:[{Slot:100b,tag:{Tags:["空灵之梦"]}}]}
	function armor:空灵之梦 if @s[tag=temp.空灵之梦]
	
## 高天悬挂之星
	scoreboard players tag @s add temp.高天悬挂之星 {Inventory:[{Slot:-106b,tag:{Tags:["高天悬挂之星"]}}]}
	function armor:高天悬挂之星 if @s[tag=temp.高天悬挂之星]
	
## 清零属性类装备,必须放在最后
	scoreboard players tag @s add temp.光之影 {Inventory:[{Slot:103b,tag:{Tags:["光之影"]}}]}
	function armor:光之影 if @s[tag=temp.光之影]	
	scoreboard players tag @s add temp.影之光 {Inventory:[{Slot:103b,tag:{Tags:["影之光"]}}]}
	function armor:影之光 if @s[tag=temp.影之光]
	
## 属性
	scoreboard players operation @s maxhealth += @s a.maxhealth

## 重置
	scoreboard players set @s d.phyAttack 0
	scoreboard players set @s d.spellAttack 0
	scoreboard players set @s d.physicsPene 0
	scoreboard players set @s d.spellPene 0
	scoreboard players set @s d.physicsResist 0
	scoreboard players set @s d.spellResist 0
	scoreboard players set @s d.critResist 0
	scoreboard players set @s d.dodge 0
	scoreboard players set @s d.hit 0
	scoreboard players set @s d.vampirism 0
	scoreboard players set @s d.vampirism.rate 0
	scoreboard players set @s d.regeneration 0
	scoreboard players set @s d.slow 0
	scoreboard players set @s d.break 0
	scoreboard players set @s d.strong 0
	scoreboard players set @s d.critAttack 0
	scoreboard players set @s d.seize 0
	scoreboard players set @s d.critPob 0
	scoreboard players set @s d.strong.rate 0
	scoreboard players set @s d.break.rate 0
	scoreboard players set @s d.reward 0
	scoreboard players set @s d.rewardPob 0
	
## 加和
	scoreboard players operation @s d.phyAttack += @s p.phyAttack
	scoreboard players operation @s d.spellAttack += @s p.spellAttack
	scoreboard players operation @s d.physicsPene += @s p.physicsPene
	scoreboard players operation @s d.spellPene += @s p.spellPene
	scoreboard players operation @s d.critPob += @s p.critPob
	scoreboard players operation @s d.critAttack += @s p.critAttack
	scoreboard players operation @s d.hit += @s p.hit
	scoreboard players operation @s d.vampirism += @s p.vampirism
	scoreboard players operation @s d.vampirism.rate += @s p.vampirism.rate
	scoreboard players operation @s d.regeneration += @s p.regeneration
	scoreboard players operation @s d.slow += @s p.slow
	scoreboard players operation @s d.break += @s p.break
	scoreboard players operation @s d.strong += @s p.strong
	scoreboard players operation @s d.reward += @s p.reward
	scoreboard players operation @s d.rewardPob += @s p.rewardPob
	scoreboard players operation @s d.seize += @s p.seize
	scoreboard players operation @s d.strong.rate += @s p.strong.rate
	scoreboard players operation @s d.break.rate += @s p.break.rate
	
	scoreboard players operation @s d.phyAttack += @s a.phyAttack
	scoreboard players operation @s d.spellAttack += @s a.spellAttack
	scoreboard players operation @s d.physicsPene += @s a.physicsPene
	scoreboard players operation @s d.spellPene += @s a.spellPene
	scoreboard players operation @s d.physicsResist += @s a.physicsResist
	scoreboard players operation @s d.spellResist += @s a.spellResist
	scoreboard players operation @s d.critResist += @s a.critResist
	scoreboard players operation @s d.dodge += @s a.dodge
	scoreboard players operation @s d.critPob += @s a.critPob
	scoreboard players operation @s d.critAttack += @s a.critAttack
	scoreboard players operation @s d.hit += @s a.hit
	scoreboard players operation @s d.vampirism += @s a.vampirism
	scoreboard players operation @s d.vampirism.rate += @s a.vampirism.rate
	scoreboard players operation @s d.regeneration += @s a.regeneration
	scoreboard players operation @s d.slow += @s a.slow
	scoreboard players operation @s d.break += @s a.break
	scoreboard players operation @s d.strong += @s a.strong
	scoreboard players operation @s d.reward += @s a.reward
	scoreboard players operation @s d.rewardPob += @s a.rewardPob
	scoreboard players operation @s d.seize += @s a.seize
	scoreboard players operation @s d.strong.rate += @s a.strong.rate
	scoreboard players operation @s d.break.rate += @s a.break.rate
	
	scoreboard players operation @s d.phyAttack += @s n.phyAttack
	scoreboard players operation @s d.spellAttack += @s n.spellAttack
	scoreboard players operation @s d.physicsPene += @s n.physicsPene
	scoreboard players operation @s d.spellPene += @s n.spellPene
	scoreboard players operation @s d.physicsResist += @s n.physicsResist
	scoreboard players operation @s d.spellResist += @s n.spellResist
	scoreboard players operation @s d.critResist += @s n.critResist
	scoreboard players operation @s d.critAttack  += @s n.critAttack
	scoreboard players operation @s d.dodge += @s n.dodge
	scoreboard players operation @s d.critPob += @s n.critPob
	scoreboard players operation @s d.hit += @s n.hit
	scoreboard players operation @s d.vampirism += @s n.vampirism
	scoreboard players operation @s d.vampirism.rate += @s n.vampirism.rate
	scoreboard players operation @s d.regeneration += @s n.regeneration
	scoreboard players operation @s d.slow += @s n.slow
	scoreboard players operation @s d.break += @s n.break
	scoreboard players operation @s d.strong += @s n.strong
	scoreboard players operation @s d.reward += @s n.reward
	scoreboard players operation @s d.rewardPob += @s n.rewardPob
	scoreboard players operation @s d.strong.rate += @s n.strong.rate
	scoreboard players operation @s d.break.rate += @s n.break.rate
	
	## 武器属性
	scoreboard players operation @s d.phyAttack += @s w.phyAttack
	scoreboard players operation @s d.spellAttack += @s w.spellAttack
	scoreboard players operation @s d.physicsPene += @s w.physicsPene
	scoreboard players operation @s d.spellPene += @s w.spellPene
	scoreboard players operation @s d.physicsResist += @s w.physicsResist
	scoreboard players operation @s d.spellResist += @s w.spellResist
	scoreboard players operation @s d.critResist += @s w.critResist
	scoreboard players operation @s d.dodge += @s w.dodge
	scoreboard players operation @s d.critPob += @s w.critPob
	scoreboard players operation @s d.critAttack += @s w.critAttack
	scoreboard players operation @s d.hit += @s w.hit
	scoreboard players operation @s d.vampirism += @s w.vampirism
	scoreboard players operation @s d.vampirism.rate += @s w.vampirism.rate
	scoreboard players operation @s d.regeneration += @s w.regeneration
	scoreboard players operation @s d.slow += @s w.slow
	scoreboard players operation @s d.break += @s w.break
	scoreboard players operation @s d.strong += @s w.strong
	scoreboard players operation @s d.reward += @s w.reward
	scoreboard players operation @s d.rewardPob += @s w.rewardPob
	scoreboard players operation @s d.strong.rate += @s w.strong.rate
	scoreboard players operation @s d.break.rate += @s w.break.rate
	
## 提示
	function armor:tellraw

## 持续性属性
scoreboard players operation @s regeneration = @s d.regeneration

## 天赋
function talent:enderChest/main1

tellraw @s "§8======[§6§l天赋装载信息§8]======\n"

tellraw @s[score_tf.1_min=0,score_tf.1=0] "§f§l[主天赋] §c§l无"
tellraw @s[score_tf.1_min=1,score_tf.1=1] "§f§l[主天赋] §c§l流泉"
tellraw @s[score_tf.1_min=2,score_tf.1=2] "§f§l[主天赋] §c§l止息"
tellraw @s[score_tf.1_min=3,score_tf.1=3] "§f§l[主天赋] §c§l背水"
tellraw @s[score_tf.1_min=4,score_tf.1=4] "§f§l[主天赋] §c§l隐士"
tellraw @s[score_tf.1_min=5,score_tf.1=5] "§f§l[主天赋] §c§l裁断"

tellraw @s[score_tf.2_min=0,score_tf.2=0] "§f§l[副天赋] §7§l无"
tellraw @s[score_tf.2_min=1,score_tf.2=1] "§f§l[副天赋] §7§l分兵"
tellraw @s[score_tf.2_min=2,score_tf.2=2] "§f§l[副天赋] §7§l袭击"
tellraw @s[score_tf.2_min=3,score_tf.2=3] "§f§l[副天赋] §7§l穿甲"
tellraw @s[score_tf.2_min=4,score_tf.2=4] "§f§l[副天赋] §7§l破甲"
tellraw @s[score_tf.2_min=5,score_tf.2=5] "§f§l[副天赋] §7§l炙热"
tellraw @s[score_tf.2_min=6,score_tf.2=6] "§f§l[副天赋] §7§l静心"
tellraw @s[score_tf.2_min=7,score_tf.2=7] "§f§l[副天赋] §7§l泉音"

tellraw @s[score_tf.3_min=0,score_tf.3=0] "§f§l[副天赋] §7§l无"
tellraw @s[score_tf.3_min=1,score_tf.3=1] "§f§l[副天赋] §7§l分兵"
tellraw @s[score_tf.3_min=2,score_tf.3=2] "§f§l[副天赋] §7§l袭击"
tellraw @s[score_tf.3_min=3,score_tf.3=3] "§f§l[副天赋] §7§l穿甲"
tellraw @s[score_tf.3_min=4,score_tf.3=4] "§f§l[副天赋] §7§l破甲"
tellraw @s[score_tf.3_min=5,score_tf.3=5] "§f§l[副天赋] §7§l炙热"
tellraw @s[score_tf.3_min=6,score_tf.3=6] "§f§l[副天赋] §7§l静心"
tellraw @s[score_tf.3_min=7,score_tf.3=7] "§f§l[副天赋] §7§l泉音"

tellraw @s "\n§8======[§6§l天赋装载信息§8]======"

scoreboard players operation @s health < @s maxhealth