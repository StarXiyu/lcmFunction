scoreboard players set @s spawnPCount 0

execute @a[r=10] ~ ~ ~ scoreboard players add @e[tag=temp.spawn] spawnPCount 1