scoreboard players set @s spawnMCount 0

execute @e[tag=mob,r=10] ~ ~ ~ scoreboard players add @e[tag=temp.spawn] spawnMCount 1