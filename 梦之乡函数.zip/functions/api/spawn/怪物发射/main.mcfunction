scoreboard players tag @s remove system.spawn.fx
particle flame ~ ~1 ~ 1 0 1 0 10 force @a

scoreboard players set @s max 200
scoreboard players set @s min 1
function random:main

function api:spawn/怪物发射/1_50 if @s[score_math.out_min=1,score_math.out=50]
function api:spawn/怪物发射/51_100 if @s[score_math.out_min=51,score_math.out=100]
function api:spawn/怪物发射/101_150 if @s[score_math.out_min=101,score_math.out=150]
function api:spawn/怪物发射/151_200 if @s[score_math.out_min=151,score_math.out=200]