scoreboard players operation @s money -= @s price
scoreboard players operation @s task.money += @s price
tellraw @s [{"text":"§f[§6梦之乡§f] §a购买已完成,物品已发放至您的背包"}]
scoreboard players tag @s remove 购买成功