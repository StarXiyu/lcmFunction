scoreboard players reset @s money.backup

scoreboard players operation @s money.backup = @s money
scoreboard players operation @s money.backup -= @s price

scoreboard players tag @s[score_money.backup=-1] add 购买失败
scoreboard players tag @s[score_money.backup_min=0] add 购买成功

scoreboard players set @s shop 0
playsound entity.experience_orb.pickup master @s ~ ~ ~ 2000 0 0