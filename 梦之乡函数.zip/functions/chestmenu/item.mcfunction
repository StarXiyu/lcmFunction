
scoreboard players tag @e[tag=!item.chestMenuTest,type=item] add item.chestMenuTest

scoreboard players tag @e[type=item] add chestmenu {Item:{tag:{Tags:["chestmenu"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["chestmenu"]}}}

scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["分兵"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["袭击"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["穿甲"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["破甲"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["炙热"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["静心"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["泉音"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["流泉"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["止息"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["背水"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["隐士"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["裁断"]}}}

scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["展示"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["模型"]}}}
scoreboard players tag @e[type=item] add need.kill {Item:{tag:{Tags:["预览"]}}}

function chestmenu:reset/main if @e[tag=chestmenu,type=item]

kill @e[tag=need.kill]