setblock ~ ~ ~ chest
summon minecraft:armor_stand ~ ~1 ~ {Tags:["armor.chestMenu","armor.setting"],Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§e§l『功能调整』"}