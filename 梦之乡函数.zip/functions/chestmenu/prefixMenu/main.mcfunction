
scoreboard players set @s chestmenu 0
stats entity @s set AffectedItems @s chestmenu

clear @s minecraft:stained_glass_pane 8 -1 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
function chestmenu:prefixMenu/air if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§3§l后起之秀",Lore:["§8* §7物理伤害 §a[20.0]","§8* §7法术伤害 §a[10.0]"]},Tags:["chestmenu","item.prefix.后起之秀"]}
function chestmenu:prefixMenu/后起之秀 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§a§l名震江湖",Lore:["§8* §7物理伤害 §a[40.0]","§8* §7法术伤害 §a[35.0]"]},Tags:["chestmenu","item.prefix.名震江湖"]}
function chestmenu:prefixMenu/名震江湖 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§6§l自成一派",Lore:["§8* §7物理伤害 §a[80.0]","§8* §7法术伤害 §a[80.0]"]},Tags:["chestmenu","item.prefix.自成一派"]}
function chestmenu:prefixMenu/自成一派 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§5§l武林盟主",Lore:["§8* §7物理伤害 §a[150.0]","§8* §7法术伤害 §a[150.0]"]},Tags:["chestmenu","item.prefix.武林盟主"]}
function chestmenu:prefixMenu/武林盟主 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§b§l飘然归隐",Lore:["§8* §7物理伤害 §a[320.0]","§8* §7法术伤害 §a[320.0]"]},Tags:["chestmenu","item.prefix.飘然归隐"]}
function chestmenu:prefixMenu/飘然归隐 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§c§l浴血战士",Lore:["§8* §7物理伤害 §a[50.0]","§8* §7吸血概率 §a[30.0%]"]},Tags:["chestmenu","item.prefix.浴血战士"]}
function chestmenu:prefixMenu/浴血战士 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§4§l嗜血者",Lore:["§8* §7吸血概率 §a[100.0%]"]},Tags:["chestmenu","item.prefix.嗜血者"]}
function chestmenu:prefixMenu/嗜血者 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§d§l术法学者",Lore:["§8* §7法术伤害 §a[40.0]","§8* §7法术穿透 §a[30.0]"]},Tags:["chestmenu","item.prefix.术法学者"]}
function chestmenu:prefixMenu/术法学者 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§d§l通术师",Lore:["§8* §7法术伤害 §a[30.0]","§8* §7法术穿透 §a[100.0]"]},Tags:["chestmenu","item.prefix.通术师"]}
function chestmenu:prefixMenu/通术师 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§5§l占星师",Lore:["§8* §7法术伤害 §a[135.0]"]},Tags:["chestmenu","item.prefix.占星师"]}
function chestmenu:prefixMenu/占星师 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§5§l魔法师",Lore:["§8* §7法术伤害 §a[180.0]","§8* §7法术穿透 §a[80.0]"]},Tags:["chestmenu","item.prefix.魔法师"]}
function chestmenu:prefixMenu/魔法师 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§4§l暗杀者",Lore:["§8* §7物理伤害 §a[400.0]","§8* §7物理穿透 §a[100.0]"]},Tags:["chestmenu","item.prefix.暗杀者"]}
function chestmenu:prefixMenu/暗杀者 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§e§lVIP",Lore:["§8* §7物理伤害 §a[400.0]","§8* §7法术伤害 §a[400.0]","§8* §7暴击率 §a[20%]"]},Tags:["chestmenu","item.prefix.VIP"]}
function chestmenu:prefixMenu/VIP if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§b§lSVIP",Lore:["§8* §7物理伤害 §a[550.0]","§8* §7法术伤害 §a[550.0]","§8* §7暴击率 §a[30%]","§8* §7暴击伤害 §a[20%]"]},Tags:["chestmenu","item.prefix.SVIP"]}
function chestmenu:prefixMenu/SVIP if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§a§lSVIP+",Lore:["§8* §7物理伤害 §a[750.0]","§8* §7法术伤害 §a[750.0]","§8* §7暴击率 §a[45%]","§8* §7暴击伤害 §a[40%]"]},Tags:["chestmenu","item.prefix.SVIP+"]}
function chestmenu:prefixMenu/SVIP+ if @s[score_chestmenu_min=1]

clear @s minecraft:barrier 0 1 {display:{Name:"§c§l卸下称号",Lore:["§f点击卸下所有称号"]},Tags:["chestmenu","item.prefix.leave"]}
function chestmenu:prefixMenu/卸下称号 if @s[score_chestmenu_min=1]

clear @s minecraft:name_tag 0 1 {display:{Name:"§e§l赏金猎手",Lore:["§8* §7赏金猎人 §a[30.0%]","§8* §7赏金 §a[10.0]"]},Tags:["chestmenu","item.prefix.赏金猎手"]}
function chestmenu:prefixMenu/赏金猎手 if @s[score_chestmenu_min=1]

stats entity @s clear AffectedItems