
	scoreboard players set @s[tag=VIP] p.phyAttack 0
	scoreboard players set @s[tag=VIP] p.spellAttack 0 
	scoreboard players set @s[tag=VIP] p.critPob 0
	scoreboard players set @s[tag=VIP] p.critAttack 0 
	scoreboard players set @s[tag=VIP] p.seize 0
	scoreboard players set @s[tag=VIP] p.vampirism 0 
	scoreboard players set @s[tag=VIP] p.physicsPene 0 
	scoreboard players set @s[tag=VIP] p.spellPene 0
	scoreboard players set @s[tag=VIP] p.spellResist 0
	scoreboard players set @s[tag=VIP] p.physicsResist 0
	scoreboard players set @s[tag=VIP] p.dodge 0
	scoreboard players set @s[tag=VIP] p.critResist 0
	scoreboard players set @s[tag=VIP] p.hit 0
	scoreboard players set @s[tag=VIP] p.vampirism.rate 0
	scoreboard players set @s[tag=VIP] p.slow 0
	scoreboard players set @s[tag=VIP] p.break 0
	scoreboard players set @s[tag=VIP] p.strong 0
	scoreboard players set @s[tag=VIP] p.reward 0
	scoreboard players set @s[tag=VIP] p.rewardPob 0
	
title @s[tag=!VIP] title "§c§l暂未获得此称号"
title @s[tag=VIP] title "§a§l替换成功"

scoreboard teams join VIP @s[tag=VIP]

scoreboard players set @s[tag=VIP] p.phyAttack 400
scoreboard players set @s[tag=VIP] p.spellAttack 400
scoreboard players set @s[tag=VIP] p.critPob 20

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu