
	scoreboard players set @s[tag=prefix.飘然归隐] p.phyAttack 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.飘然归隐] p.critPob 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.critAttack 0 
	scoreboard players set @s[tag=prefix.飘然归隐] p.seize 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.vampirism 0 
	scoreboard players set @s[tag=prefix.飘然归隐] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.飘然归隐] p.spellPene 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.spellResist 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.physicsResist 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.dodge 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.critResist 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.hit 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.slow 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.break 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.strong 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.reward 0
	scoreboard players set @s[tag=prefix.飘然归隐] p.rewardPob 0
	
title @s[tag=!prefix.飘然归隐] title "§c§l暂未获得此称号"
title @s[tag=prefix.飘然归隐] title "§a§l替换成功"

scoreboard teams join 飘然归隐 @s[tag=prefix.飘然归隐]

scoreboard players set @s[tag=prefix.飘然归隐] p.phyAttack 320
scoreboard players set @s[tag=prefix.飘然归隐] p.spellAttack 320

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu