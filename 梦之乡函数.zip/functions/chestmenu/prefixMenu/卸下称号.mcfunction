
	scoreboard players set @s p.phyAttack 0
	scoreboard players set @s p.spellAttack 0 
	scoreboard players set @s p.critPob 0
	scoreboard players set @s p.critAttack 0 
	scoreboard players set @s p.seize 0
	scoreboard players set @s p.vampirism 0 
	scoreboard players set @s p.physicsPene 0 
	scoreboard players set @s p.spellPene 0
	scoreboard players set @s p.spellResist 0
	scoreboard players set @s p.physicsResist 0
	scoreboard players set @s p.dodge 0
	scoreboard players set @s p.critResist 0
	scoreboard players set @s p.hit 0
	scoreboard players set @s p.vampirism.rate 0
	scoreboard players set @s p.slow 0
	scoreboard players set @s p.break 0
	scoreboard players set @s p.strong 0
	scoreboard players set @s p.reward 0
	scoreboard players set @s p.rewardPob 0
							   
title @s title "§a§l卸下成功"

scoreboard teams join 初涉江湖 @s

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu