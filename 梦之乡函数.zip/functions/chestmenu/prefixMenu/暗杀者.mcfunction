
	scoreboard players set @s[tag=prefix.暗杀者] p.phyAttack 0
	scoreboard players set @s[tag=prefix.暗杀者] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.暗杀者] p.critPob 0
	scoreboard players set @s[tag=prefix.暗杀者] p.critAttack 0 
	scoreboard players set @s[tag=prefix.暗杀者] p.seize 0
	scoreboard players set @s[tag=prefix.暗杀者] p.vampirism 0 
	scoreboard players set @s[tag=prefix.暗杀者] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.暗杀者] p.spellPene 0
	scoreboard players set @s[tag=prefix.暗杀者] p.spellResist 0
	scoreboard players set @s[tag=prefix.暗杀者] p.physicsResist 0
	scoreboard players set @s[tag=prefix.暗杀者] p.dodge 0
	scoreboard players set @s[tag=prefix.暗杀者] p.critResist 0
	scoreboard players set @s[tag=prefix.暗杀者] p.hit 0
	scoreboard players set @s[tag=prefix.暗杀者] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.暗杀者] p.slow 0
	scoreboard players set @s[tag=prefix.暗杀者] p.break 0
	scoreboard players set @s[tag=prefix.暗杀者] p.strong 0
	scoreboard players set @s[tag=prefix.暗杀者] p.reward 0
	scoreboard players set @s[tag=prefix.暗杀者] p.rewardPob 0
	
title @s[tag=!prefix.暗杀者] title "§c§l暂未获得此称号"
title @s[tag=prefix.暗杀者] title "§a§l替换成功"

scoreboard teams join 暗杀者 @s[tag=prefix.暗杀者]

scoreboard players set @s[tag=prefix.暗杀者] p.phyAttack 400
scoreboard players set @s[tag=prefix.暗杀者] p.physicsPene 100

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu