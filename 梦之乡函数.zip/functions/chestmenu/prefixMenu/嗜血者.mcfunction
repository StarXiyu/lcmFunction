
	scoreboard players set @s[tag=prefix.嗜血者] p.phyAttack 0
	scoreboard players set @s[tag=prefix.嗜血者] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.嗜血者] p.critPob 0
	scoreboard players set @s[tag=prefix.嗜血者] p.critAttack 0 
	scoreboard players set @s[tag=prefix.嗜血者] p.seize 0
	scoreboard players set @s[tag=prefix.嗜血者] p.vampirism 0 
	scoreboard players set @s[tag=prefix.嗜血者] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.嗜血者] p.spellPene 0
	scoreboard players set @s[tag=prefix.嗜血者] p.spellResist 0
	scoreboard players set @s[tag=prefix.嗜血者] p.physicsResist 0
	scoreboard players set @s[tag=prefix.嗜血者] p.dodge 0
	scoreboard players set @s[tag=prefix.嗜血者] p.critResist 0
	scoreboard players set @s[tag=prefix.嗜血者] p.hit 0
	scoreboard players set @s[tag=prefix.嗜血者] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.嗜血者] p.slow 0
	scoreboard players set @s[tag=prefix.嗜血者] p.break 0
	scoreboard players set @s[tag=prefix.嗜血者] p.strong 0
	scoreboard players set @s[tag=prefix.嗜血者] p.reward 0
	scoreboard players set @s[tag=prefix.嗜血者] p.rewardPob 0

title @s[tag=!prefix.嗜血者] title "§c§l暂未获得此称号"
title @s[tag=prefix.嗜血者] title "§a§l替换成功"

scoreboard teams join 嗜血者 @s[tag=prefix.嗜血者]

scoreboard players set @s[tag=prefix.嗜血者] p.vampirism 100

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu