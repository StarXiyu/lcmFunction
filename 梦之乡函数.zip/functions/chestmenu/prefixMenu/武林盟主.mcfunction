
	scoreboard players set @s[tag=prefix.武林盟主] p.phyAttack 0
	scoreboard players set @s[tag=prefix.武林盟主] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.武林盟主] p.critPob 0
	scoreboard players set @s[tag=prefix.武林盟主] p.critAttack 0 
	scoreboard players set @s[tag=prefix.武林盟主] p.seize 0
	scoreboard players set @s[tag=prefix.武林盟主] p.vampirism 0 
	scoreboard players set @s[tag=prefix.武林盟主] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.武林盟主] p.spellPene 0
	scoreboard players set @s[tag=prefix.武林盟主] p.spellResist 0
	scoreboard players set @s[tag=prefix.武林盟主] p.physicsResist 0
	scoreboard players set @s[tag=prefix.武林盟主] p.dodge 0
	scoreboard players set @s[tag=prefix.武林盟主] p.critResist 0
	scoreboard players set @s[tag=prefix.武林盟主] p.hit 0
	scoreboard players set @s[tag=prefix.武林盟主] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.武林盟主] p.slow 0
	scoreboard players set @s[tag=prefix.武林盟主] p.break 0
	scoreboard players set @s[tag=prefix.武林盟主] p.strong 0
	scoreboard players set @s[tag=prefix.武林盟主] p.reward 0
	scoreboard players set @s[tag=prefix.武林盟主] p.rewardPob 0
	
title @s[tag=!prefix.武林盟主] title "§c§l暂未获得此称号"
title @s[tag=prefix.武林盟主] title "§a§l替换成功"

scoreboard teams join 武林盟主 @s[tag=prefix.武林盟主]

scoreboard players set @s[tag=prefix.武林盟主] p.phyAttack 150
scoreboard players set @s[tag=prefix.武林盟主] p.spellAttack 150

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu