
	scoreboard players set @s[tag=prefix.占星师] p.phyAttack 0
	scoreboard players set @s[tag=prefix.占星师] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.占星师] p.critPob 0
	scoreboard players set @s[tag=prefix.占星师] p.critAttack 0 
	scoreboard players set @s[tag=prefix.占星师] p.seize 0
	scoreboard players set @s[tag=prefix.占星师] p.vampirism 0 
	scoreboard players set @s[tag=prefix.占星师] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.占星师] p.spellPene 0
	scoreboard players set @s[tag=prefix.占星师] p.spellResist 0
	scoreboard players set @s[tag=prefix.占星师] p.physicsResist 0
	scoreboard players set @s[tag=prefix.占星师] p.dodge 0
	scoreboard players set @s[tag=prefix.占星师] p.critResist 0
	scoreboard players set @s[tag=prefix.占星师] p.hit 0
	scoreboard players set @s[tag=prefix.占星师] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.占星师] p.slow 0
	scoreboard players set @s[tag=prefix.占星师] p.break 0
	scoreboard players set @s[tag=prefix.占星师] p.strong 0
	scoreboard players set @s[tag=prefix.占星师] p.reward 0
	scoreboard players set @s[tag=prefix.占星师] p.rewardPob 0
	
title @s[tag=!prefix.占星师] title "§c§l暂未获得此称号"
title @s[tag=prefix.占星师] title "§a§l替换成功"

scoreboard teams join 占星师 @s[tag=prefix.占星师]

scoreboard players set @s[tag=prefix.占星师] p.spellAttack 135

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu