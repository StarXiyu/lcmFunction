
	scoreboard players set @s[tag=prefix.后起之秀] p.phyAttack 0
	scoreboard players set @s[tag=prefix.后起之秀] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.后起之秀] p.critPob 0
	scoreboard players set @s[tag=prefix.后起之秀] p.critAttack 0 
	scoreboard players set @s[tag=prefix.后起之秀] p.seize 0
	scoreboard players set @s[tag=prefix.后起之秀] p.vampirism 0 
	scoreboard players set @s[tag=prefix.后起之秀] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.后起之秀] p.spellPene 0
	scoreboard players set @s[tag=prefix.后起之秀] p.spellResist 0
	scoreboard players set @s[tag=prefix.后起之秀] p.physicsResist 0
	scoreboard players set @s[tag=prefix.后起之秀] p.dodge 0
	scoreboard players set @s[tag=prefix.后起之秀] p.critResist 0
	scoreboard players set @s[tag=prefix.后起之秀] p.hit 0
	scoreboard players set @s[tag=prefix.后起之秀] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.后起之秀] p.slow 0
	scoreboard players set @s[tag=prefix.后起之秀] p.break 0
	scoreboard players set @s[tag=prefix.后起之秀] p.strong 0
	scoreboard players set @s[tag=prefix.后起之秀] p.reward 0
	scoreboard players set @s[tag=prefix.后起之秀] p.rewardPob 0
	
title @s[tag=!prefix.后起之秀] title "§c§l暂未获得此称号"
title @s[tag=prefix.后起之秀] title "§a§l替换成功"

scoreboard teams join 后起之秀 @s[tag=prefix.后起之秀]

scoreboard players set @s[tag=prefix.后起之秀] p.phyAttack 20
scoreboard players set @s[tag=prefix.后起之秀] p.spellAttack 10

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu