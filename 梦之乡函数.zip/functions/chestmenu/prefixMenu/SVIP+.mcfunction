
	scoreboard players set @s[tag=SVIP+] p.phyAttack 0
	scoreboard players set @s[tag=SVIP+] p.spellAttack 0 
	scoreboard players set @s[tag=SVIP+] p.critPob 0
	scoreboard players set @s[tag=SVIP+] p.critAttack 0 
	scoreboard players set @s[tag=SVIP+] p.seize 0
	scoreboard players set @s[tag=SVIP+] p.vampirism 0 
	scoreboard players set @s[tag=SVIP+] p.physicsPene 0 
	scoreboard players set @s[tag=SVIP+] p.spellPene 0
	scoreboard players set @s[tag=SVIP+] p.spellResist 0
	scoreboard players set @s[tag=SVIP+] p.physicsResist 0
	scoreboard players set @s[tag=SVIP+] p.dodge 0
	scoreboard players set @s[tag=SVIP+] p.critResist 0
	scoreboard players set @s[tag=SVIP+] p.hit 0
	scoreboard players set @s[tag=SVIP+] p.vampirism.rate 0
	scoreboard players set @s[tag=SVIP+] p.slow 0
	scoreboard players set @s[tag=SVIP+] p.break 0
	scoreboard players set @s[tag=SVIP+] p.strong 0
	scoreboard players set @s[tag=SVIP+] p.reward 0
	scoreboard players set @s[tag=SVIP+] p.rewardPob 0
	
title @s[tag=!SVIP+] title "§c§l暂未获得此称号"
title @s[tag=SVIP+] title "§a§l替换成功"

scoreboard teams join SVIP+ @s[tag=SVIP+]

scoreboard players set @s[tag=SVIP+] p.phyAttack 750
scoreboard players set @s[tag=SVIP+] p.spellAttack 750
scoreboard players set @s[tag=SVIP+] p.critPob 45
scoreboard players set @s[tag=SVIP+] p.critAttack 40

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu