
	scoreboard players set @s[tag=prefix.自成一派] p.phyAttack 0
	scoreboard players set @s[tag=prefix.自成一派] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.自成一派] p.critPob 0
	scoreboard players set @s[tag=prefix.自成一派] p.critAttack 0 
	scoreboard players set @s[tag=prefix.自成一派] p.seize 0
	scoreboard players set @s[tag=prefix.自成一派] p.vampirism 0 
	scoreboard players set @s[tag=prefix.自成一派] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.自成一派] p.spellPene 0
	scoreboard players set @s[tag=prefix.自成一派] p.spellResist 0
	scoreboard players set @s[tag=prefix.自成一派] p.physicsResist 0
	scoreboard players set @s[tag=prefix.自成一派] p.dodge 0
	scoreboard players set @s[tag=prefix.自成一派] p.critResist 0
	scoreboard players set @s[tag=prefix.自成一派] p.hit 0
	scoreboard players set @s[tag=prefix.自成一派] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.自成一派] p.slow 0
	scoreboard players set @s[tag=prefix.自成一派] p.break 0
	scoreboard players set @s[tag=prefix.自成一派] p.strong 0
	scoreboard players set @s[tag=prefix.自成一派] p.reward 0
	scoreboard players set @s[tag=prefix.自成一派] p.rewardPob 0
	
title @s[tag=!prefix.自成一派] title "§c§l暂未获得此称号"
title @s[tag=prefix.自成一派] title "§a§l替换成功"

scoreboard teams join 自成一派 @s[tag=prefix.自成一派]

scoreboard players set @s[tag=prefix.自成一派] p.phyAttack 80
scoreboard players set @s[tag=prefix.自成一派] p.spellAttack 80

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu