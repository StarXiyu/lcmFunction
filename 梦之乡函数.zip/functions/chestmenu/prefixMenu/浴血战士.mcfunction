
	scoreboard players set @s[tag=prefix.浴血战士] p.phyAttack 0
	scoreboard players set @s[tag=prefix.浴血战士] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.浴血战士] p.critPob 0
	scoreboard players set @s[tag=prefix.浴血战士] p.critAttack 0 
	scoreboard players set @s[tag=prefix.浴血战士] p.seize 0
	scoreboard players set @s[tag=prefix.浴血战士] p.vampirism 0 
	scoreboard players set @s[tag=prefix.浴血战士] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.浴血战士] p.spellPene 0
	scoreboard players set @s[tag=prefix.浴血战士] p.spellResist 0
	scoreboard players set @s[tag=prefix.浴血战士] p.physicsResist 0
	scoreboard players set @s[tag=prefix.浴血战士] p.dodge 0
	scoreboard players set @s[tag=prefix.浴血战士] p.critResist 0
	scoreboard players set @s[tag=prefix.浴血战士] p.hit 0
	scoreboard players set @s[tag=prefix.浴血战士] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.浴血战士] p.slow 0
	scoreboard players set @s[tag=prefix.浴血战士] p.break 0
	scoreboard players set @s[tag=prefix.浴血战士] p.strong 0
	scoreboard players set @s[tag=prefix.浴血战士] p.reward 0
	scoreboard players set @s[tag=prefix.浴血战士] p.rewardPob 0
	
	
title @s[tag=!prefix.浴血战士] title "§c§l暂未获得此称号"
title @s[tag=prefix.浴血战士] title "§a§l替换成功"

scoreboard teams join 浴血战士 @s[tag=prefix.浴血战士]

scoreboard players set @s[tag=prefix.浴血战士] p.phyAttack 50
scoreboard players set @s[tag=prefix.浴血战士] p.vampirism 30

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu