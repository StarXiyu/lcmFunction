
execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu