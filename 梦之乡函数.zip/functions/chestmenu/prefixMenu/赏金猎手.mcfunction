
	scoreboard players set @s[tag=prefix.赏金猎手] p.phyAttack 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.赏金猎手] p.critPob 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.critAttack 0 
	scoreboard players set @s[tag=prefix.赏金猎手] p.seize 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.vampirism 0 
	scoreboard players set @s[tag=prefix.赏金猎手] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.赏金猎手] p.spellPene 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.spellResist 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.physicsResist 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.dodge 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.critResist 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.hit 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.slow 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.break 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.strong 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.reward 0
	scoreboard players set @s[tag=prefix.赏金猎手] p.rewardPob 0
	
title @s[tag=!prefix.赏金猎手] title "§c§l暂未获得此称号"
title @s[tag=prefix.赏金猎手] title "§a§l替换成功"

scoreboard teams join 赏金猎手 @s[tag=prefix.赏金猎手]

scoreboard players set @s[tag=prefix.赏金猎手] p.reward 10
scoreboard players set @s[tag=prefix.赏金猎手] p.rewardPob 30


scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu