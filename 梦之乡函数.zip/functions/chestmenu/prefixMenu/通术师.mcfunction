
	scoreboard players set @s[tag=prefix.通术师] p.phyAttack 0
	scoreboard players set @s[tag=prefix.通术师] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.通术师] p.critPob 0
	scoreboard players set @s[tag=prefix.通术师] p.critAttack 0 
	scoreboard players set @s[tag=prefix.通术师] p.seize 0
	scoreboard players set @s[tag=prefix.通术师] p.vampirism 0 
	scoreboard players set @s[tag=prefix.通术师] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.通术师] p.spellPene 0
	scoreboard players set @s[tag=prefix.通术师] p.spellResist 0
	scoreboard players set @s[tag=prefix.通术师] p.physicsResist 0
	scoreboard players set @s[tag=prefix.通术师] p.dodge 0
	scoreboard players set @s[tag=prefix.通术师] p.critResist 0
	scoreboard players set @s[tag=prefix.通术师] p.hit 0
	scoreboard players set @s[tag=prefix.通术师] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.通术师] p.slow 0
	scoreboard players set @s[tag=prefix.通术师] p.break 0
	scoreboard players set @s[tag=prefix.通术师] p.strong 0
	scoreboard players set @s[tag=prefix.通术师] p.reward 0
	scoreboard players set @s[tag=prefix.通术师] p.rewardPob 0
	
title @s[tag=!prefix.通术师] title "§c§l暂未获得此称号"
title @s[tag=prefix.通术师] title "§a§l替换成功"

scoreboard teams join 通术师 @s[tag=prefix.通术师]

scoreboard players set @s[tag=prefix.通术师] p.spellAttack 30
scoreboard players set @s[tag=prefix.通术师] p.spellPene 100

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu