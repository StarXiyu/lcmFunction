

	scoreboard players set @s[tag=prefix.名震江湖] p.phyAttack 0
	scoreboard players set @s[tag=prefix.名震江湖] p.spellAttack 0 
	scoreboard players set @s[tag=prefix.名震江湖] p.critPob 0
	scoreboard players set @s[tag=prefix.名震江湖] p.critAttack 0 
	scoreboard players set @s[tag=prefix.名震江湖] p.seize 0
	scoreboard players set @s[tag=prefix.名震江湖] p.vampirism 0 
	scoreboard players set @s[tag=prefix.名震江湖] p.physicsPene 0 
	scoreboard players set @s[tag=prefix.名震江湖] p.spellPene 0
	scoreboard players set @s[tag=prefix.名震江湖] p.spellResist 0
	scoreboard players set @s[tag=prefix.名震江湖] p.physicsResist 0
	scoreboard players set @s[tag=prefix.名震江湖] p.dodge 0
	scoreboard players set @s[tag=prefix.名震江湖] p.critResist 0
	scoreboard players set @s[tag=prefix.名震江湖] p.hit 0
	scoreboard players set @s[tag=prefix.名震江湖] p.vampirism.rate 0
	scoreboard players set @s[tag=prefix.名震江湖] p.slow 0
	scoreboard players set @s[tag=prefix.名震江湖] p.break 0
	scoreboard players set @s[tag=prefix.名震江湖] p.strong 0
	scoreboard players set @s[tag=prefix.名震江湖] p.reward 0
	scoreboard players set @s[tag=prefix.名震江湖] p.rewardPob 0
	
title @s[tag=!prefix.名震江湖] title "§c§l暂未获得此称号"
title @s[tag=prefix.名震江湖] title "§a§l替换成功"

scoreboard teams join 名震江湖 @s[tag=prefix.名震江湖]

scoreboard players set @s[tag=prefix.名震江湖] p.phyAttack 40
scoreboard players set @s[tag=prefix.名震江湖] p.spellAttack 35

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu