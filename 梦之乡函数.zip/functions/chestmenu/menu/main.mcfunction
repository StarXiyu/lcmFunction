
execute @e[tag=armor.prefixMenu,type=armor_stand] ~ ~ ~ execute @a[r=6] ~ ~ ~ function chestMenu:prefixMenu/main

execute @e[tag=armor.talent,type=armor_stand] ~ ~ ~ execute @a[r=6] ~ ~ ~ function chestMenu:talent/main