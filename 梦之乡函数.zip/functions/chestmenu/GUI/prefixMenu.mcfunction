replaceitem block ~ ~-1 ~ slot.container.0 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.1 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.2 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.3 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.4 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.5 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.6 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.7 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.8 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.9 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.10 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.11 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.12 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.13 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.14 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.15 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.16 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.17 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.18 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.19 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.20 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.21 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.22 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.23 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.24 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.25 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
replaceitem block ~ ~-1 ~ slot.container.26 minecraft:stained_glass_pane 1 8 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}

replaceitem block ~ ~-1 ~ slot.container.0 minecraft:name_tag 1 0 {display:{Name:"§3§l后起之秀",Lore:["§8* §7物理伤害 §a[20.0]","§8* §7法术伤害 §a[10.0]"]},Tags:["chestmenu","item.prefix.后起之秀"]}
replaceitem block ~ ~-1 ~ slot.container.1 minecraft:name_tag 1 0 {display:{Name:"§a§l名震江湖",Lore:["§8* §7物理伤害 §a[40.0]","§8* §7法术伤害 §a[35.0]"]},Tags:["chestmenu","item.prefix.名震江湖"]}
replaceitem block ~ ~-1 ~ slot.container.2 minecraft:name_tag 1 0 {display:{Name:"§6§l自成一派",Lore:["§8* §7物理伤害 §a[80.0]","§8* §7法术伤害 §a[80.0]"]},Tags:["chestmenu","item.prefix.自成一派"]}
replaceitem block ~ ~-1 ~ slot.container.3 minecraft:name_tag 1 0 {display:{Name:"§5§l武林盟主",Lore:["§8* §7物理伤害 §a[150.0]","§8* §7法术伤害 §a[150.0]"]},Tags:["chestmenu","item.prefix.武林盟主"]}
replaceitem block ~ ~-1 ~ slot.container.4 minecraft:name_tag 1 0 {display:{Name:"§b§l飘然归隐",Lore:["§8* §7物理伤害 §a[320.0]","§8* §7法术伤害 §a[320.0]"]},Tags:["chestmenu","item.prefix.飘然归隐"]}
replaceitem block ~ ~-1 ~ slot.container.5 minecraft:name_tag 1 0 {display:{Name:"§c§l浴血战士",Lore:["§8* §7物理伤害 §a[50.0]","§8* §7吸血概率 §a[30.0%]"]},Tags:["chestmenu","item.prefix.浴血战士"]}
replaceitem block ~ ~-1 ~ slot.container.6 minecraft:name_tag 1 0 {display:{Name:"§4§l嗜血者",Lore:["§8* §7吸血概率 §a[100.0%]"]},Tags:["chestmenu","item.prefix.嗜血者"]}
replaceitem block ~ ~-1 ~ slot.container.7 minecraft:name_tag 1 0 {display:{Name:"§d§l术法学者",Lore:["§8* §7法术伤害 §a[40.0]","§8* §7法术穿透 §a[30.0]"]},Tags:["chestmenu","item.prefix.术法学者"]}
replaceitem block ~ ~-1 ~ slot.container.8 minecraft:name_tag 1 0 {display:{Name:"§d§l通术师",Lore:["§8* §7法术伤害 §a[30.0]","§8* §7法术穿透 §a[100.0]"]},Tags:["chestmenu","item.prefix.通术师"]}
replaceitem block ~ ~-1 ~ slot.container.9 minecraft:name_tag 1 0 {display:{Name:"§5§l占星师",Lore:["§8* §7法术伤害 §a[135.0]"]},Tags:["chestmenu","item.prefix.占星师"]}
replaceitem block ~ ~-1 ~ slot.container.10 minecraft:name_tag 1 0 {display:{Name:"§5§l魔法师",Lore:["§8* §7法术伤害 §a[180.0]","§8* §7法术穿透 §a[80.0]"]},Tags:["chestmenu","item.prefix.魔法师"]}
replaceitem block ~ ~-1 ~ slot.container.11 minecraft:name_tag 1 0 {display:{Name:"§4§l暗杀者",Lore:["§8* §7物理伤害 §a[400.0]","§8* §7物理穿透 §a[100.0]"]},Tags:["chestmenu","item.prefix.暗杀者"]}
replaceitem block ~ ~-1 ~ slot.container.12 minecraft:name_tag 1 0 {display:{Name:"§e§lVIP",Lore:["§8* §7物理伤害 §a[400.0]","§8* §7法术伤害 §a[400.0]","§8* §7暴击率 §a[20%]"]},Tags:["chestmenu","item.prefix.VIP"]}
replaceitem block ~ ~-1 ~ slot.container.13 minecraft:name_tag 1 0 {display:{Name:"§b§lSVIP",Lore:["§8* §7物理伤害 §a[550.0]","§8* §7法术伤害 §a[550.0]","§8* §7暴击率 §a[30%]","§8* §7暴击伤害 §a[20%]"]},Tags:["chestmenu","item.prefix.SVIP"]}
replaceitem block ~ ~-1 ~ slot.container.14 minecraft:name_tag 1 0 {display:{Name:"§a§lSVIP+",Lore:["§8* §7物理伤害 §a[750.0]","§8* §7法术伤害 §a[750.0]","§8* §7暴击率 §a[45%]","§8* §7暴击伤害 §a[40%]"]},Tags:["chestmenu","item.prefix.SVIP+"]}
replaceitem block ~ ~-1 ~ slot.container.15 minecraft:name_tag 1 0 {display:{Name:"§e§l赏金猎手",Lore:["§8* §7赏金猎人 §a[30.0%]","§8* §7赏金 §a[10.0]"]},Tags:["chestmenu","item.prefix.赏金猎手"]}

replaceitem block ~ ~-1 ~ slot.container.26 minecraft:barrier 1 0 {display:{Name:"§c§l卸下称号",Lore:["§f点击卸下所有称号"]},Tags:["chestmenu","item.prefix.leave"]}