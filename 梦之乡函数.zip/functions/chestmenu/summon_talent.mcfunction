setblock ~ ~ ~ chest
summon minecraft:armor_stand ~ ~1 ~ {Tags:["armor.chestMenu","armor.talent"],Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:1,CustomName:"§e§l『查看天赋等级』"}