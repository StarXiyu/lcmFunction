
##execute @e[tag=armor.chestMenu,type=armor_stand] ~ ~ ~ function chestmenu:menu/main if @p[r=6]

execute @a[score_chestmenu.time_min=0] ~ ~ ~ function chestmenu:tpDown

function chestmenu:item if @e[tag=!item.chestMenuTest,type=item]