
tp @s[score_chestmenu.time_min=0,score_chestmenu.time=0] ~ ~-100 ~

scoreboard players remove @s chestmenu.time 1