
execute @e[tag=armor.prefixMenu] ~ ~ ~ function chestmenu:GUI/prefixMenu
execute @e[tag=armor.talent] ~ ~ ~ function chestmenu:GUI/talent
execute @e[tag=armor.setting] ~ ~ ~ function chestmenu:GUI/setting