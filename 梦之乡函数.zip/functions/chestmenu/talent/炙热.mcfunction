
tellraw @s [{"text":"[天赋系统]","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 天赋 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"炙热","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 等级为 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"炙热","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 级","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.talent] ~ ~ ~ function chestmenu:GUI/talent

function talent:give/vice/炙热 if @s[score_炙热_min=1]