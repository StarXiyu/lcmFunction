
execute @e[tag=armor.talent] ~ ~ ~ function chestmenu:GUI/talent