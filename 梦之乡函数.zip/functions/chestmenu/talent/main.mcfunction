
scoreboard players set @s chestmenu 0
stats entity @s set AffectedItems @s chestmenu

clear @s minecraft:stained_glass_pane 8 -1 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
function chestmenu:talent/air if @s[score_chestmenu_min=1]

clear @s minecraft:cyan_glazed_terracotta 0 1 {display:{Name:"§3§l止息",Lore:["§6❏§f主天赋 §4§l[传说]","§f放置在末影箱§a最右侧第一格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7受到攻击后有§c10%>15%>20%>25%>30%>35%>40%§7概率","§7立即使伤害来源受到§c减速4§7效果持续§c3秒","§7并使其造成的所有伤害降低§c40%§7,持续§c3s"]},Tags:["talent","talent.main","止息","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/止息 if @s[score_chestmenu_min=1]

clear @s minecraft:yellow_glazed_terracotta 0 1 {ench:[{lvl:1s,id:1s}],HideFlags:1b,Tags:["talent","talent.main","流泉","chestmenu"],display:{Lore:["§6❏§f主天赋 §4§l[传说]","§f放置在末影箱§a最右侧第一格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7受到攻击后有§c30>35>40>45>50>55>60%§7概率","§7立即恢复受到伤害的§c50%§7并将§c30%§7伤害返还给对方"],Name:"§e§l流泉"}}
function chestmenu:talent/流泉 if @s[score_chestmenu_min=1]

clear @s minecraft:purple_glazed_terracotta 0 1 {display:{Name:"§5§l背水",Lore:["§6❏§f主天赋 §4§l[传说]","§f放置在末影箱§a最右侧第一格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7血量低于最大生命值的§c25%>30%>35%>40%>45%>50%>55%","§7自身造成的所有伤害增加§c30%","§7且有§c40%§7概率造成无视护甲的伤害"]},Tags:["talent","talent.main","背水","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/背水 if @s[score_chestmenu_min=1]

clear @s minecraft:light_blue_glazed_terracotta 0 1 {display:{Name:"§b§l裁断",Lore:["§6❏§f主天赋 §4§l[传说]","§f放置在末影箱§a最右侧第一格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7攻击有§c30%>35>40>45>50>55>60%§7概率","§7使你所攻击的玩家主副天赋全部失效持续§c4s"]},Tags:["talent","talent.main","裁断","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/裁断 if @s[score_chestmenu_min=1]

clear @s minecraft:white_glazed_terracotta 0 1 {display:{Name:"§f§l隐士",Lore:["§6❏§f主天赋 §4§l[传说]","§f放置在末影箱§a最右侧第一格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7以降低§c20%§7自身所有输出伤害为代价","§7使自身物理防御/法术防御§c+300/400/500/600/700/800/900","§7且不受负面药水效果影响"]},Tags:["talent","talent.main","隐士","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/隐士 if @s[score_chestmenu_min=1]

clear @s minecraft:stained_hardened_clay 3 1 {display:{Name:"§b§l分兵",Lore:["§6❏§f副天赋 §9§l[普通]","§f放置在末影箱§a最右侧第二/三格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7攻击有§c30%>35>40>45>50>55>60%§7概率","§7造成分兵效果，分别造成三次基于§c原伤害45%§7的伤害"]},Tags:["talent","talent.vice","分兵","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/分兵 if @s[score_chestmenu_min=1]

clear @s minecraft:stained_hardened_clay 13 1 {display:{Name:"§2§l泉音",Lore:["§6❏§f副天赋 §9§l[普通]","§f放置在末影箱§a最右侧第二/三格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7使自身每秒恢复§c0.2%/0.4%/0.6%/0.8%/1%/1.2%/1.4%§7的最大生命值"]},Tags:["talent","talent.vice","泉音","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/泉音 if @s[score_chestmenu_min=1]

clear @s minecraft:stained_hardened_clay 14 1 {display:{Name:"§c§l炙热",Lore:["§6❏§f副天赋 §9§l[普通]","§f放置在末影箱§a最右侧第二/三格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7使周围4格以内的玩家每秒受到基于自身法术穿透的","§c5%/10%/15%/20%/25%/30%/35%§7的法术伤害"]},Tags:["talent","talent.vice","炙热","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/炙热 if @s[score_chestmenu_min=1]

clear @s minecraft:stained_hardened_clay 9 1 {display:{Name:"§3§l破甲",Lore:["§6❏§f副天赋 §9§l[普通]","§f放置在末影箱§a最右侧第二/三格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7攻击有§c5%/10%/15%/20%/25%/30%/35%§7概率","§7造成§c无视护甲§7的伤害 每5秒可触发一次"]},Tags:["talent","talent.vice","破甲","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/破甲 if @s[score_chestmenu_min=1]

clear @s minecraft:stained_hardened_clay 4 1 {display:{Name:"§e§l穿甲",Lore:["§6❏§f副天赋 §9§l[普通]","§f放置在末影箱§a最右侧第二/三格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7攻击后获得§c100/150/200/250/300/350/400点§7物理穿透/法术穿透","§7持续4s,每10s可触发一次"]},Tags:["talent","talent.vice","穿甲","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/穿甲 if @s[score_chestmenu_min=1]

#clear @s minecraft:stained_hardened_clay 1 1 {display:{Name:"§6§l袭击",Lore:["§6❏§f副天赋 §9§l[普通]","§f放置在末影箱§a最右侧第二/三格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7对没有标记过的敌人造成攻击后","§7物理防御/法术防御减§c60/80/100/120/140/160/180§7持续5秒","§7并附加标记，标记§c10s§7清除"]},Tags:["talent","talent.vice","袭击","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
#function chestmenu:talent/袭击 if @s[score_chestmenu_min=1]

clear @s minecraft:stained_hardened_clay 5 1 {display:{Name:"§a§l静心",Lore:["§6❏§f副天赋 §9§l[普通]","§f放置在末影箱§a最右侧第二/三格§f生效","§f进入§a天赋箱子菜单§f页面查看等级","§f§l▮▮▮▮▮▮▮▮§e『天赋效果』§f§l▮▮▮▮▮▮▮▮","§7使自身每秒恢复基于自身物理穿透的§c5%/10%/15%/20%/25%/30%/35%§7的血量"]},Tags:["talent","talent.vice","静心","chestmenu"],HideFlags:1,ench:[{id:70s,lvl:1s}]}
function chestmenu:talent/静心 if @s[score_chestmenu_min=1]

stats entity @s clear AffectedItems