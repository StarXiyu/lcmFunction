
## stopMessage.war

## 玩家进入时默认没有Tag 则开启提示

scoreboard players tag @s add temp.setting

execute @s[tag=temp.setting] ~ ~ ~ function chestmenu:功能调整/战斗提示_remove if @s[tag=stopMessage.war]
execute @s[tag=temp.setting] ~ ~ ~ function chestmenu:功能调整/战斗提示_add unless @s[tag=stopMessage.war]

scoreboard players set @s chestmenu.time 1
tp @s ~ ~100 ~

execute @e[tag=armor.setting] ~ ~ ~ function chestmenu:GUI/setting