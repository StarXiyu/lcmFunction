
scoreboard players set @s chestmenu 0
stats entity @s set AffectedItems @s chestmenu

clear @s minecraft:stained_glass_pane 8 -1 {display:{Name:"§7我不是你的目标哦"},Tags:["chestmenu"]}
function chestmenu:功能调整/air if @s[score_chestmenu_min=1]

clear @s minecraft:knowledge_book 0 1 {display:{Name:"§4§l战斗提示",Lore:["§f点击开关§e战斗提示"]},Tags:["chestmenu","item.setting.战斗提示"]}
function chestmenu:功能调整/战斗提示 if @s[score_chestmenu_min=1]

clear @s minecraft:knowledge_book 0 1 {display:{Name:"§a§l战利品提示",Lore:["§f点击开关§e获取战利品提示"]},Tags:["chestmenu","item.setting.战利品提示"]}
function chestmenu:功能调整/战利品提示 if @s[score_chestmenu_min=1]

clear @s minecraft:knowledge_book 0 1 {display:{Name:"§b§l额外效果提示",Lore:["§f点击开关§e额外效果提示"]},Tags:["chestmenu","item.setting.额外效果提示"]}
function chestmenu:功能调整/额外效果提示 if @s[score_chestmenu_min=1]

stats entity @s clear AffectedItems