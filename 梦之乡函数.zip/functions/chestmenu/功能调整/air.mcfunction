
execute @e[tag=armor.setting] ~ ~ ~ function chestmenu:GUI/setting