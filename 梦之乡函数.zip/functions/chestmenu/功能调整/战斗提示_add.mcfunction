
tellraw @s[tag=!stopMessage.war] "§f[§6梦之乡§f] §8>> §7已为您§c关闭§7战斗提示"
scoreboard players tag @s[tag=!stopMessage.war] add stopMessage.war
scoreboard players tag @s remove temp.setting