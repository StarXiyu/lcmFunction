
tellraw @s "§f[§6梦之乡§f] §8>> §7已为您§c关闭§7战利品获得提示"
scoreboard players tag @s add stopMessage.getItem
scoreboard players tag @s remove temp.setting