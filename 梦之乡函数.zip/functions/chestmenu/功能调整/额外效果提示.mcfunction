
## stopMessage.extraEffect

## 玩家进入时默认没有Tag 则开启提示

scoreboard players tag @s add temp.setting

execute @s[tag=temp.setting] ~ ~ ~ function chestmenu:功能调整/额外效果提示_remove if @s[tag=stopMessage.extraEffect]
execute @s[tag=temp.setting] ~ ~ ~ function chestmenu:功能调整/额外效果提示_add unless @s[tag=stopMessage.extraEffect]

scoreboard players set @s chestmenu.time 1
tp @s ~ ~101 ~

execute @e[tag=armor.setting] ~ ~ ~ function chestmenu:GUI/setting