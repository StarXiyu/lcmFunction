
tellraw @s "§f[§6梦之乡§f] §8>> §7已为您§a开启§7额外效果提示"
scoreboard players tag @s remove stopMessage.extraEffect
scoreboard players tag @s remove temp.setting