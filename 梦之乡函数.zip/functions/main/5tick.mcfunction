scoreboard players set @s main 0

scoreboard players add @e[tag=10tick,type=armor_stand] main 5
execute @e[tag=10tick] ~ ~ ~ function main:10tick if @s[score_main_min=10,score_main=20]

execute @e[tag=armor.chestMenu,type=armor_stand] ~ ~ ~ function chestmenu:menu/main if @p[r=6]
function chestmenu:item if @e[tag=!item.chestMenuTest,type=item]

effect @a[tag=!test.noFall] minecraft:regeneration 10 255 true
effect @a[tag=!test.noFall] minecraft:resistance 10 3 true

scoreboard players add @e[tag=element.display,type=armor_stand] element.time 1
kill @e[tag=element.display,type=armor_stand,score_element.time_min=3]

execute @a[tag=!xr] ~ ~ ~ function system:xr
execute @a ~ ~ ~ function system:血条计算