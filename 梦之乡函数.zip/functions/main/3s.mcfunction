scoreboard players set @s main 0

effect @e[tag=entity.invisbale] minecraft:invisibility 999 255 true
effect @e[tag=entity.resistance] minecraft:resistance 999 255 true

scoreboard players tag @a[tag=SVIP+] add SVIP
scoreboard players tag @a[tag=SVIP+] add VIP

scoreboard players tag @a[tag=SVIP] add VIP

execute @a[tag=SVIP+] ~ ~ ~ scoreboard players operation @s time.limit1 = systemTick tempBanT1

scoreboard players add @a task 0