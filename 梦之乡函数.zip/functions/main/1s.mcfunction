
scoreboard players enable @a cdk
function system:cdk if @p[score_cdk_min=1]

scoreboard players enable @a 礼包
execute @a[score_礼包_min=1] ~ ~ ~ function system:礼包加密算法
execute @a[score_礼包=-1] ~ ~ ~ function system:礼包加密算法

scoreboard players add @a time 1
function system:notice_gift if @a[score_time_min=300,tag=权益]
function system:notice_firstGift if @a[score_time_min=3600]

scoreboard players add @e[tag=zc] money 1
function system:矿场刷新 if @e[tag=zc,score_money_min=590]

execute @e[tag=3c刷新] ~ ~ ~ execute @a[r=8] ~ ~ ~ scoreboard players add @e[tag=3c刷新] time 1
execute @e[tag=3c刷新,score_time_min=15] ~ ~ ~ function 全局:伪装者刷新
 execute @e[tag=3c刷新,score_time_min=15] ~ ~ ~ scoreboard players reset @s time
scoreboard players enable @a shop

execute @a[score_shop_min=1] ~ ~ ~ function system:shop/main
execute @a[score_sell.trigger_min=1] ~ ~ ~ function system:sell/main

## [02] 检测是否有人启动tempban程序
	scoreboard players enable @a tempban
	execute @p[score_tempban_min=1] ~ ~ ~ function tempban:setPlayer/main

## [03] 检测是否有人设定时间
	execute @p[score_tempban.time_min=1] ~ ~ ~ function tempban:setTime/main
	
function pay:main
function system:工会传送 if @p[score_guild.tp_min=1]
scoreboard players enable @a guild.tp

execute @e[tag=伪装者] ~ ~ ~ execute @a[r=4] ~ ~ ~ function system:伪装者
execute @e[tag=怒火之卫] ~ ~ ~ execute @a[r=4] ~ ~ ~ function system:怒火之卫
execute @e[tag=流浪商人] ~ ~ ~ execute @a[r=7] ~ ~ ~ function system:流浪商人

execute @e[tag=记忆boss] ~ ~ ~ function system:boss/1/main

execute @a[score_jinggao_min=1] ~ ~ ~ function system:warn
execute @a[score_警告_min=10] ~ ~ ~ function system:warnBan

function system:getMoney_limit if @p[tag=!getMoney.limit]
function system:moneyRate unless @p[tag=moneyRate]

execute @a[tag=tf.泉音] ~ ~ ~ function talent:泉音/main

execute @a[tag=tf.炙热] ~ ~ ~ function talent:炙热/main

execute @a[tag=tf.静心] ~ ~ ~ function talent:静心/main

scoreboard players remove @a[score_cj.time2_min=1] cj.time2 1
scoreboard players tag @a[score_cj.time2=0,score_cj.time2_min=0] remove temp.allow.tf.穿甲
scoreboard players reset @a[score_cj.time2=0,score_cj.time2_min=0] cj.time2

scoreboard players add @s killer 1
function system:killer/main if @s[score_killer_min=290]

scoreboard players remove @a[score_cd.time_min=1] cd.time 1
execute @a[score_cd.time_min=0,score_cd.time=0] ~ ~ ~ function system:裁断

execute @a[tag=tf.隐士] ~ ~ ~ function system:effect_clearDebuff

function 挑战:challenge/main if @a[team=挑战中]
gamemode 2 @a[score_死亡_min=1,m=0]
scoreboard players reset @a 死亡
execute @p[score_left_min=1] ~ ~ ~ function system:left

function system:regeneration if @p[score_regeneration_min=1]

execute @e[tag=岁月寒] ~ ~ ~ effect @a[r=5] minecraft:slowness 2 1

execute @e[score_eleTime.浇筑_min=1] ~ ~ ~ function element:浇筑/effect

execute @e[score_eleTime.萌发_min=1] ~ ~ ~ function element:萌发/effect

execute @e[score_eleTime.汲取_min=1] ~ ~ ~ function element:汲取/effect

execute @e[score_eleTime.燃烧_min=1] ~ ~ ~ function element:燃烧/effect

execute @e[tag=monsterSpawn] ~ ~ ~ function system:monsterSpawn/main if @p[r=6]

function system:锐意新势 if @p[score_锐意新势_min=1]

scoreboard players enable @a element
execute @a[score_element_min=1] ~ ~ ~ function system:element/main

execute @a[score_controlReclaim_min=1] ~ ~ ~ function system:ore_controlReclaim

function system:task_online if @p[score_task.online_min=12000,score_task_min=0,score_task=10]
function system:task_jf if @p[score_task.jf_min=80,score_task_min=0,score_task=10]
function system:task_money if @p[score_task.money_min=8000,score_task_min=0,score_task=10]

scoreboard players enable @a[tag=admin] ban
scoreboard players enable @a[tag=admin] jinggao

function system:天空群岛/main if @a[team=天空群岛]
execute @a[score_leavep_min=1] ~ ~ ~ function system:回服务器
execute @a[tag=killaura] ~ ~ ~ function system:killaura/main