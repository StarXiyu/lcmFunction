scoreboard players add @e[tag=5tick,type=armor_stand] main 1

execute @e[tag=5tick] ~ ~ ~ function main:5tick if @s[score_main_min=5,score_main=10]

function monster:main if @e[tag=monster.math]
function LightRPG:字幕/规则
scoreboard players enable @a §7LightRPG
scoreboard players enable @a §8LightRPG
execute @a[score_§7LightRPG_min=1] ~ ~ ~ function LightRPG:system/trigger/attackMain
execute @a[score_§8LightRPG_min=1] ~ ~ ~ function LightRPG:system/trigger/hurtMain

effect @e[tag=monster] minecraft:resistance 10 4 true

## [04] 增加服务器刻
	scoreboard players add systemTick tempBanT1 1

## [00] 重置管理员的临时封禁
	scoreboard players set @a[tag=op,score_tempbanT1_min=1] tempbanT1 0
	
## [01] 检测是否有已被封禁的玩家登录
	execute @a[tag=tempban.ban] ~ ~ ~ function tempban:ban/main
	
execute @a[tag=ban] ~ ~ ~ function system:ban

execute @a[score_ban_min=1] ~ ~ ~ function system:trban

	function system:menu/sneak/main if @p[score_menuSneak_min=1]
	scoreboard players remove @a[score_sneak2_min=0] sneak2 1

	scoreboard players add @a[score_sneak2_min=0,score_sneak2=0] sneakCount 1
	function system:menu/sneak/count if @p[score_sneakCount_min=1]
	
execute @a[score_chestmenu.time_min=0] ~ ~ ~ function chestmenu:tpDown

execute @a[m=!1] ~ ~ ~ detect ~ ~-1 ~ air * execute @s[m=!3] ~ ~ ~ detect ~ ~-2 ~ air 0 function system:flytest