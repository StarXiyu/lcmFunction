scoreboard players set @s main 0

scoreboard players add @e[tag=zc] time 5
function system:箱子刷新 if @e[tag=zc,score_time_min=30,type=armor_stand]

scoreboard players add @s time.bind 5
function system:notice_bind if @s[score_time.bind_min=200]

scoreboard players add @a time.limit 5
function system:notice_limit if @p[score_time.limit_min=3600]

scoreboard players tag @a[tag=tf.破甲] add temp.allow.tf.破甲

scoreboard players add @s cj.time 1
execute @s[score_cj.time_min=2] ~ ~ ~ scoreboard players tag @a[tag=tf.穿甲] add temp.allow.tf.穿甲
execute @s[score_cj.time_min=2] ~ ~ ~ scoreboard players set @a[tag=tf.穿甲] cj.time 0

scoreboard players add @e[type=item] item 5
kill @e[type=item,score_item_min=30]

execute @a[score_maxhealth=-1] ~ ~ ~ tellraw @s [{"text":"\n[","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"梦之乡","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >> ","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"检测到您的血量数据异常，请截图私信管理员处理","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\nUID ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"uid","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\nNICKNAME ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\nMAXHEALTH ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"maxhealth","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\nA.MAXHEALTH ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"a.maxhealth","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n"}]

scoreboard players add @e[score_eleEffect.碾压_min=1] eleTime.碾压 5
function element:碾压/reset if @e[score_eleTime.碾压_min=30]

scoreboard players add @a time.attribute 5
function system:5min_attributeUpdate if @p[score_time.attribute_min=300]

scoreboard players operation §6§l●𝓼𝓼§f注册人数§l𝓼𝓼§e➾ a = §7uid uid

scoreboard players set @a[score_flyTest_min=1] flyTest 0