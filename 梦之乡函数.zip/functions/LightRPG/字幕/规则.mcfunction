scoreboard players add @e[tag=字幕] money 1
tp @e[tag=字幕,score_money_min=12] ~ ~-0.1 ~
kill @e[tag=字幕,score_money_min=36]