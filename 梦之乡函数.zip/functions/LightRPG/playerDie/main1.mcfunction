
title @s[team=挑战中] title "§c§l挑战失败"
function 挑战:challenge/reset if @s[team=挑战中]

kill @s[team=!挑战中]

tellraw @a [{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 被 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@e[tag=LightRPG.temp.pve.attackPlayer,c=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 击败了","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

function LightRPG:playerDie/init unless @s[score_maxhealth_min=0]
scoreboard players operation @s health = @s maxhealth