
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster,r=10] pumpkin_pie 1 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lGLv1.§4§l流浪天空","§b§l✪ §f可在副本大厅兑换","","§e§l██████████████"],Name:"§4§l天空虚影"}}

execute @s[tag=LightRPG.temp.drop] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ tellraw @s[tag=!stopMessage.getItem] "§f[§6物品获得§f] §e天空虚影"
