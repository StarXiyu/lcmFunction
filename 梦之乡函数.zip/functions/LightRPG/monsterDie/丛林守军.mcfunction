
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster,r=10] pumpkin_seeds 1 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lLv2.§e§l丛林卫兵","§b§l✪ §f可在副本大厅兑换装备","","§e§l██████████████"],Name:"§a§l丛林种子"}}

execute @s[tag=LightRPG.temp.drop] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ tellraw @s[tag=!stopMessage.getItem] "§f[§6物品获得§f] §e丛林种子"
