
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster,r=10] carrot 1 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lLv10.§d§l流浪商人","§b§l✪ §f可在副本大厅兑换","","§e§l██████████████"],Name:"§e§l稀有的萝卜"}}

execute @s[tag=LightRPG.temp.drop] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ tellraw @s[tag=!stopMessage.getItem] "§f[§6物品获得§f] §e稀有的萝卜"