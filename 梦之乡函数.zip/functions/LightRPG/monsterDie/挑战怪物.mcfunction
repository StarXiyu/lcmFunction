
execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players add @s[team=挑战中] 挑战击杀 1