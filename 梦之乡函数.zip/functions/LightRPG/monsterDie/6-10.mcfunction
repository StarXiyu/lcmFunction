
function LightRPG:monsterDie/腐尸 if @s[tag=腐尸]
function LightRPG:monsterDie/蛮荒行者 if @s[tag=蛮荒行者]
function LightRPG:monsterDie/静法蛛魔 if @s[tag=静法蛛魔]
function LightRPG:monsterDie/秋风刀 if @s[tag=秋风刀]
function LightRPG:monsterDie/岁月寒 if @s[tag=岁月寒]