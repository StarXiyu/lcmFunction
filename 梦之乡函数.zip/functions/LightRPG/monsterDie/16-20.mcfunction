function LightRPG:monsterDie/原初·岩 if @s[tag=原初·岩]
function LightRPG:monsterDie/流浪商人 if @s[tag=流浪商人]