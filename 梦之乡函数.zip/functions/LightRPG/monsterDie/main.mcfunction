
## 掉落概率运算
function LightRPG:monsterDie/drop

## 赏金猎人运算
execute @p[tag=LightRPG.temp.attackMonster,r=10,score_reward_min=1] ~ ~ ~ function LightRPG:monsterDie/reward

## 死亡音效
execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 1 1

## 死亡怪物类型判定
function LightRPG:monsterDie/挑战怪物 if @s[tag=挑战怪物]
function LightRPG:monsterDie/时空裂缝分身 if @s[tag=时空裂缝分身]
function LightRPG:monsterDie/1-5 if @s[score_msp.number_min=1,score_msp.number=5]
function LightRPG:monsterDie/6-10 if @s[score_msp.number_min=6,score_msp.number=10]
function LightRPG:monsterDie/11-15 if @s[score_msp.number_min=11,score_msp.number=15]
function LightRPG:monsterDie/16-20 if @s[score_msp.number_min=16,score_msp.number=20]

function LightRPG:monsterDie/空域将士 if @s[tag=天空群岛空域将士]
function LightRPG:monsterDie/空域将领 if @s[tag=天空群岛空域将领]

scoreboard players add @p[tag=LightRPG.temp.attackMonster,r=10] display.kill 1
scoreboard players add @p[tag=LightRPG.temp.attackMonster,r=10,score_task_min=0,score_task=10] task.kill 1

scoreboard players add @p[tag=LightRPG.temp.attackMonster,r=10,score_task_min=0,score_task=10,score_task.kill_min=70] task 1
tellraw @p[tag=LightRPG.temp.attackMonster,r=10,score_task_min=0,score_task=10,score_task.kill_min=70] [{"text":">> ","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"每日任务进度 ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"task","name":"@p[tag=LightRPG.temp.attackMonster,r=10,score_task_min=0,score_task=10,score_task.kill_min=70]"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"/10","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
tellraw @p[tag=LightRPG.temp.attackMonster,r=10,score_task_min=10,score_task=10,score_task.kill_min=70] [{"text":"您的每日任务已完成 请前往主城提交","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
scoreboard players set @p[tag=LightRPG.temp.attackMonster,r=10,score_task.kill_min=70] task.kill 0

kill @s