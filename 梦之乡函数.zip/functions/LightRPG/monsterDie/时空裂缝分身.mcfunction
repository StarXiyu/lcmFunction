
scoreboard players add @e[tag=记忆boss] health 5000
execute @e[tag=记忆boss] ~ ~ ~ scoreboard players operation @s health < @s maxhealth