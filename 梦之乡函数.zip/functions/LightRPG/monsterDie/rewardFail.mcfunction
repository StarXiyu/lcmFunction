
tellraw @s[tag=!stopMessage.extraEffect] "§7[赏金猎人] §c抱歉,您已达到小时获得金币限额，无法获得"