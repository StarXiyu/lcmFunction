
kill @e[tag=时空裂缝分身]
scoreboard players reset @a 力场崩坏

scoreboard players tag @a[score_记忆.damage_min=1] add sort.temp.subject
execute @a[tag=sort.temp.subject] ~ ~ ~ scoreboard players operation @s sort.hand = @s 记忆.damage
function sort:DescendingOrder/main

tellraw @a " "
tellraw @a "§7======[记忆BOSS战斗结算]======"
tellraw @a [{"text":"-1st. ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[score_sort.out_min=1,score_sort.out=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 伤害:","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"记忆.damage","name":"@a[score_sort.out_min=1,score_sort.out=1]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
tellraw @a [{"text":"-2nd. ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[score_sort.out_min=2,score_sort.out=2]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 伤害:","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"记忆.damage","name":"@a[score_sort.out_min=2,score_sort.out=2]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
tellraw @a [{"text":"-3rd. ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[score_sort.out_min=3,score_sort.out=3]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 伤害:","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"记忆.damage","name":"@a[score_sort.out_min=3,score_sort.out=3]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
tellraw @a " "

give @a[score_sort.out_min=1,score_sort.out=1] glowstone_dust 1 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §cBOSS材料","§b§l✪ §f来源:§a§lTLv1.§4§b§c§lBOSS·§4§l记忆","§b§l✪ §f可在副本大厅兑换","","§e§l██████████████"],Name:"§c§l记忆晶体"}}
give @a[score_sort.out_min=1,score_sort.out=1] gold_nugget 8 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §cBOSS材料","§b§l✪ §f来源:§a§lTLv1.§c§lBOSS·§4§l记忆","§b§l✪ §f可在副本大厅兑换","","§e§l██████████████"],Name:"§d§l记忆碎片"}}
give @a[score_sort.out_min=2,score_sort.out=2] gold_nugget 5 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §cBOSS材料","§b§l✪ §f来源:§a§lTLv1.§c§lBOSS·§4§l记忆","§b§l✪ §f可在副本大厅兑换","","§e§l██████████████"],Name:"§d§l记忆碎片"}}
give @a[score_sort.out_min=3,score_sort.out=3] gold_nugget 3 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §cBOSS材料","§b§l✪ §f来源:§a§lTLv1.§c§lBOSS·§4§l记忆","§b§l✪ §f可在副本大厅兑换","","§e§l██████████████"],Name:"§d§l记忆碎片"}}

give @a[score_记忆.damage_min=8000,score_sort.out_min=4] gold_nugget 1 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §cBOSS材料","§b§l✪ §f来源:§a§lTLv1.§c§lBOSS·§4§l记忆","§b§l✪ §f可在副本大厅兑换","","§e§l██████████████"],Name:"§d§l记忆碎片"}}

scoreboard players reset @a 记忆.damage