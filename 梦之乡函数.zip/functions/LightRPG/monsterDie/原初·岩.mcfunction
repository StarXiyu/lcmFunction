
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster,r=10] dye 1 7 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lLv9.§6§l原初·岩","§b§l✪ §f可在元素大厅兑换","","§e§l██████████████"],Name:"§6§l原初之岩"}}

execute @s[tag=LightRPG.temp.drop] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ tellraw @s[tag=!stopMessage.getItem] "§f[§6物品获得§f] §e原初之岩"