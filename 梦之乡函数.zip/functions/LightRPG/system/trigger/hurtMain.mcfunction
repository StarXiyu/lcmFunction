scoreboard players reset @s[x=351,y=4,z=-1481,r=50] §8LightRPG

function system:damageMain

## 天赋 穿甲
function talent:穿甲/main if @s[tag=temp.allow.tf.穿甲]

## 天赋 背水
function talent:背水/main if @s[tag=tf.背水]

## 天赋 隐士
function talent:隐士/main if @s[tag=tf.隐士]

## 1-10
function LightRPG:system/trigger/hurt_1-10 if @s[score_§8LightRPG=10,score_§8LightRPG_min=1]

## 11-20
function LightRPG:system/trigger/hurt_11-20 if @s[score_§8LightRPG=20,score_§8LightRPG_min=11]

scoreboard players reset @s §8LightRPG