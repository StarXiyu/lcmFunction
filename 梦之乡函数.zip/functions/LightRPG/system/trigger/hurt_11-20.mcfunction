## 11-15
function LightRPG:system/trigger/hurt_11-15 if @s[score_§8LightRPG=15,score_§8LightRPG_min=11]

## 16-20
function LightRPG:system/trigger/hurt_16-20 if @s[score_§8LightRPG=20,score_§8LightRPG_min=16]