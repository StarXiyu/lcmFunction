
function system:damageMain

## 天赋 穿甲
function talent:穿甲/main if @s[tag=temp.allow.tf.穿甲]

## 天赋 背水
function talent:背水/main if @s[tag=tf.背水]

## 天赋 隐士
function talent:隐士/main if @s[tag=tf.隐士]

## 杀戮自动关闭
function system:killaura/stop if @s[tag=killaura]

function LightRPG:system/trigger/attackMonster if @s[score_§7LightRPG=1,score_§7LightRPG_min=1]

scoreboard players reset @s §7LightRPG