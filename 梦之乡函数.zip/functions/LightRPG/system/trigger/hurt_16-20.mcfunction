function LightRPG:system/trigger/原初·木 if @s[score_§8LightRPG=16,score_§8LightRPG_min=16]
function LightRPG:system/trigger/原初·岩 if @s[score_§8LightRPG=17,score_§8LightRPG_min=17]
function LightRPG:system/trigger/流浪商人 if @s[score_§8LightRPG=18,score_§8LightRPG_min=18]
function LightRPG:system/trigger/天空群岛怪物 if @s[score_§8LightRPG=19,score_§8LightRPG_min=19]