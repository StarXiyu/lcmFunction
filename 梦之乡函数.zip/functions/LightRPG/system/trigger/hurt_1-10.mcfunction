## 1-5
function LightRPG:system/trigger/hurt_1-5 if @s[score_§8LightRPG=5,score_§8LightRPG_min=1]

## 6-10
function LightRPG:system/trigger/hurt_6-10 if @s[score_§8LightRPG=10,score_§8LightRPG_min=6]