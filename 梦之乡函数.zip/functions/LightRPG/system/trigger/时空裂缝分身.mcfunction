
## 选择攻击的怪物
scoreboard players tag @e[r=10,c=1,tag=时空裂缝分身] add LightRPG.temp.pve.attackPlayer

scoreboard players tag @s add LightRPG.temp.pve.hurtPlayer

execute @p[tag=LightRPG.temp.pve.hurtPlayer] ~ ~ ~ function LightRPG:system/pve/main

advancement revoke @s only lightrpg:时空裂缝分身