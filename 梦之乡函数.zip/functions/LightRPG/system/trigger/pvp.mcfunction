
scoreboard players tag @s add LightRPG.temp.pvp.hurtPlayer
advancement revoke @s only lightrpg:pvp

## 选择攻击的玩家
scoreboard players tag @a[c=1,r=10,score_MCdamage_min=0,tag=!LightRPG.temp.pvp.hurtPlayer] add LightRPG.temp.pvp.attackPlayer

## 天赋 裁断
function talent:裁断/main if @s[tag=tf.裁断]

execute @p[tag=LightRPG.temp.pvp.hurtPlayer,r=10] ~ ~ ~ function LightRPG:system/pvp/main