
## 攻击动画
	particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a[r=10] 152
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 2 1
	
## 玩家伤害运算
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ function LightRPG:system/pvp/playerAttack

## 天赋 破甲
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ function talent:破甲/main if @s[tag=temp.allow.tf.破甲]

## 物理属性
	function LightRPG:system/pvp/physics if @p[tag=LightRPG.temp.pvp.attackPlayer,score_phyAttack_min=1,r=10]

## 法术属性
	function LightRPG:system/pvp/spell if @p[tag=LightRPG.temp.pvp.attackPlayer,score_spellAttack_min=1,r=10]

## 闪避
	function LightRPG:system/pvp/dodge if @s[score_dodge_min=1]

## 混乱(减速)
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ function LightRPG:system/pvp/slow if @p[tag=LightRPG.temp.pvp.attackPlayer,r=10,score_slow_min=1]
	
## 破败
	execute @s[tag=!LightRPG.temp.dodge,score_health_min=1] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer] ~ ~ ~ function LightRPG:system/pvp/break if @s[score_break_min=1]

## 巨力
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer] ~ ~ ~ function LightRPG:system/pvp/strong if @s[score_strong_min=1]
	
## 攻击总数
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ scoreboard players set @s math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack1
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack2

## 暴击运算
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,score_critPob_min=1,r=10] ~ ~ ~ function LightRPG:system/pvp/crit
	
## 天赋 止息
	function talent:止息/player if @s[tag=tf.止息]
	
## 天赋 分兵
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ function talent:分兵/main if @s[tag=tf.分兵]

## 元素反应
	scoreboard players tag @s add element.hurt
	scoreboard players tag @p[tag=LightRPG.temp.attackMonster,r=10] add element.attack
	function element:main
	
## 怪物生命
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ scoreboard players set @s[score_math.attack3=-1] math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ scoreboard players operation @s health -= @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] math.attack3

## 天赋 流泉
	function talent:流泉/player if @s[tag=tf.流泉]
	
## 吸血
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ function LightRPG:system/pvp/vampirism if @s[score_vampirism_min=1]
	
## 攻击提示
	scoreboard players set @s[score_health=-1] health 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ title @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"⚔","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ title @s[tag=LightRPG.temp.crit] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"☣","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ title @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] subtitle [{"score":{"objective":"math.attack3","name":"@p[tag=LightRPG.temp.pvp.attackPlayer,r=10]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" / ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ tellraw @s[tag=!stopMessage.war] [{"selector":"@p[tag=LightRPG.temp.pvp.hurtPlayer]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 闪避","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"了您的攻击","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

## 受伤提示
	execute @s[tag=!stopMessage.war] ~ ~ ~ tellraw @s[tag=LightRPG.temp.dodge] [{"text":"您","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"闪避","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@p[tag=LightRPG.temp.pvp.attackPlayer,r=10]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 的攻击","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "}]
	execute @s[tag=!stopMessage.war] ~ ~ ~ tellraw @s[tag=!LightRPG.temp.dodge] [{"text":"您损失了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math.attack3","name":"@p[tag=LightRPG.temp.pvp.attackPlayer,r=10]"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "}]
	
## 分兵
	function talent:分兵/startPlayer if @p[r=10,tag=LightRPG.temp.pvp.attackPlayer,score_分兵count_min=1]
	
## 怪物死亡
	function LightRPG:playerDie/main if @s[score_health=0]
	
## 删除标签
	scoreboard players tag @a[tag=LightRPG.temp.pvp.attackPlayer] remove LightRPG.temp.crit
	scoreboard players reset @a[tag=LightRPG.temp.pvp.attackPlayer] MCdamage
	scoreboard players reset @a[tag=LightRPG.temp.pvp.hurtPlayer] MCdamage
	scoreboard players tag @a[tag=LightRPG.temp.pvp.attackPlayer] remove LightRPG.temp.pvp.attackPlayer
	scoreboard players tag @s remove LightRPG.temp.pvp.hurtPlayer
	scoreboard players tag @s remove LightRPG.temp.dodge