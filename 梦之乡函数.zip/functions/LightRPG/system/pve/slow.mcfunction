
scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main

scoreboard players operation @s math.out -= @e[tag=LightRPG.temp.pve.attackPlayer,c=1,score_slow_min=1] slow

execute @s[score_math.out=0] ~ ~ ~ effect @s minecraft:slowness 2 1
execute @s[score_math.out=0] ~ ~ ~ tellraw @s[tag=!stopMessage.extraEffect] [{"selector":"@e[tag=LightRPG.temp.pve.attackPlayer,c=1,score_slow_min=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 对 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 造成了","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 混乱","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"hoverEvent":{"action":"show_text","value":"减速"}},{"text":" 效果","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]