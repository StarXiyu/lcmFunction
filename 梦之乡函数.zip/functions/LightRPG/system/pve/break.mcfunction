
scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main
scoreboard players operation @s math.out -= @s break

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s math.attack4 = @p[tag=LightRPG.temp.pve.hurtPlayer] health

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s math.attack4 *= @s break.rate
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s math.attack4 /= 100 math

execute @s[score_math.out=0] ~ ~ ~ execute @p[tag=LightRPG.temp.pve.hurtPlayer] ~ ~ ~ tellraw @s[tag=!stopMessage.extraEffect] [{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 对 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@p[tag=LightRPG.temp.pve.hurtPlayer]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 造成了","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 破败","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"hoverEvent":{"action":"show_text","value":"破败"}},{"text":" 效果使其损失了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math.attack4","name":"@s"},"color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血量","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @p[tag=LightRPG.temp.pve.hurtPlayer] health -= @s math.attack4