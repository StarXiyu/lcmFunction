
scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main
scoreboard players operation @s math.out -= @s vampirism

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 = @s math.attack3
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 *= @s vampirism.rate
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 /= 100 math

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s health += @s temp.math1

execute @s[score_math.out=0] ~ ~ ~ execute @p[tag=LightRPG.temp.pve.hurtPlayer] ~ ~ ~ tellraw @s[tag=!stopMessage.war] [{"selector":"@e[tag=LightRPG.temp.pve.attackPlayer,c=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 吸取了您 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"temp.math1","name":"@s"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]