
execute @a[r=6] ~ ~ ~ playsound entity.player.attack.crit master @s ~ ~ ~ 16 1 0
particle lava ~ ~ ~ 0 0 0 0.15 10 normal