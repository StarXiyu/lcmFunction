## 攻击动画
	particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a[r=10] 152
	
	
## 玩家伤害运算
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/playerAttack

## 天赋 破甲
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ function talent:破甲/main if @s[tag=temp.allow.tf.破甲]
	
## 物理属性
	function LightRPG:system/monsterHurt/physics if @p[tag=LightRPG.temp.attackMonster,score_phyAttack_min=1,r=10]

## 法术属性
	function LightRPG:system/monsterHurt/spell if @p[tag=LightRPG.temp.attackMonster,score_spellAttack_min=1,r=10]

## 闪避
	function LightRPG:system/monsterHurt/dodge if @s[score_dodge_min=1]
	
## 攻击总数
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players set @s math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack1
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack2

## BOSS特殊机制
	function system:天空群岛/coreHurt if @s[tag=天空群岛.core]
	
## 暴击运算
	execute @p[tag=LightRPG.temp.attackMonster,score_critPob_min=1,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/crit
	
## 天赋 分兵
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ function talent:分兵/main if @s[tag=tf.分兵]

## 元素反应
	scoreboard players tag @s add element.hurt
	scoreboard players tag @p[tag=LightRPG.temp.attackMonster,r=10] add element.attack
	function element:main
	
## 混乱(减速)
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ function LightRPG:system/monsterHurt/slow if @p[tag=LightRPG.temp.attackMonster,r=10,score_slow_min=1]
	
## 怪物生命
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players set @s[score_math.attack3=-1] math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ scoreboard players operation @s health -= @p[tag=LightRPG.temp.attackMonster,r=10] math.attack3

## 吸血
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/vampirism if @s[score_vampirism_min=1]
	
## 破败
	execute @s[tag=!LightRPG.temp.dodge,score_health_min=1] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/break if @s[score_break_min=1]

## 巨力
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/strong if @s[score_strong_min=1]

## 攻击提示
	scoreboard players set @s[score_health=-1] health 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ title @p[tag=LightRPG.temp.attackMonster,r=10] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"⚔","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ title @s[tag=LightRPG.temp.crit] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"☣","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ title @p[tag=LightRPG.temp.attackMonster,r=10] subtitle [{"score":{"objective":"math.attack3","name":"@p[tag=LightRPG.temp.attackMonster,r=10]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" / ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ tellraw @s[tag=!stopMessage.war] [{"selector":"@e[tag=LightRPG.temp.hurtMonster,r=10,c=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 闪避","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"了您的攻击","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

## 暴击提示
	function LightRPG:system/monsterHurt/critParticle if @p[tag=LightRPG.temp.crit,r=10]

## 分兵
	function talent:分兵/startMonster if @p[r=10,tag=LightRPG.temp.attackMonster,score_分兵count_min=1]

## 伤害统计
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ function system:damageStat if @p[r=10,tag=LightRPG.temp.crit]

## hpBar
	function system:hpBar/main
	
## 怪物死亡
	function LightRPG:monsterDie/main if @s[score_health=0,tag=!天空群岛.core]
	
## 天空群岛核心死亡
	function system:天空群岛/over1 if @s[score_health=0,tag=天空群岛.core]

## 删除标签
	scoreboard players tag @s remove LightRPG.temp.hurtMonster
	scoreboard players tag @s remove LightRPG.temp.dodge
	scoreboard players tag @a[tag=LightRPG.temp.attackMonster] remove LightRPG.temp.crit
	scoreboard players tag @a[tag=LightRPG.temp.attackMonster] remove temp.tf.破甲
	scoreboard players tag @a[tag=LightRPG.temp.attackMonster] remove LightRPG.temp.attackMonster