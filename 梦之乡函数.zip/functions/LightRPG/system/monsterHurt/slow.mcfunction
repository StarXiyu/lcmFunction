
scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main


scoreboard players operation @s math.out -= @p[tag=LightRPG.temp.attackMonster,r=10,score_slow_min=1] slow
	execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=1,score_yf=1] ~-0.5000000000000004 ~+1.8 ~-0.8660254037844385 /summon minecraft:armor_stand ~ ~-1 ~ {CustomName:"§b§l混乱!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=2,score_yf=2]  ~-0.17364817766693033 ~+1.5 ~-0.984807753012208 /summon minecraft:armor_stand ~ ~-1 ~ {CustomName:"§b§l混乱!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=3,score_yf=3] ~0.9396926207859084 ~+2.0 ~0.3420201433256687 /summon minecraft:armor_stand ~ ~-1 ~ {CustomName:"§b§l混乱!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}

execute @s[score_math.out=0] ~ ~ ~ effect @s minecraft:slowness 2 1
execute @s[score_math.out=0] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10,score_slow_min=1] ~ ~ ~ tellraw @s[tag=!stopMessage.extraEffect] [{"selector":"@p[tag=LightRPG.temp.attackMonster,r=10,score_slow_min=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 对 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 造成了","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 混乱","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"hoverEvent":{"action":"show_text","value":"减速"}},{"text":" 效果","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]