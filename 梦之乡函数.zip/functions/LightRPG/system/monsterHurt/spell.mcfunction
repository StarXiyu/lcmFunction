
## math.attack2 法术攻击基数 @p[tag=LightRPG.temp.attackMonster]
## spell.math2 法术穿透 @p[tag=LightRPG.temp.attackMonster]
## spell.math1 法术抵抗 @s

## 初始化
	scoreboard players operation @s spell.math1 = @s spellResist

## 天赋破甲
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ execute @s[tag=temp.tf.破甲] ~ ~ ~ scoreboard players set @e[r=10,tag=LightRPG.temp.hurtMonster] spell.math1 0
	
## 计算法术
	scoreboard players operation @s spell.math1 -= @p[tag=LightRPG.temp.attackMonster,r=10] spell.math2
	
## 情况1 还是正数
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s temp.math1 = @s math.attack2
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s temp.math2 = @e[tag=LightRPG.temp.hurtMonster,r=10] spell.math1
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s temp.math1 *= @s temp.math2
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s temp.math1 /= 1000 math
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players set @s[score_temp.math1=0] temp.math1 0
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s math.attack2 -= @s temp.math1