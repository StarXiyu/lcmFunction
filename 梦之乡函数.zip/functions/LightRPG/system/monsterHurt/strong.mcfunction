scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main
scoreboard players operation @s math.out -= @s strong
	execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=1,score_yf=1] ~-0.5000000000000004 ~+1.8 ~-0.8660254037844385 /summon minecraft:armor_stand ~ ~-1.5 ~ {CustomName:"§6§l巨力!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=2,score_yf=2] ~-0.6427876096865394 ~+1.8 ~0.766044443118978 /summon minecraft:armor_stand ~ ~-1.5 ~ {CustomName:"§6§l巨力!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=3,score_yf=3] ~0.9396926207859084 ~+1.8 ~0.3420201433256687 /summon minecraft:armor_stand ~ ~-1.5 ~ {CustomName:"§6§l巨力!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s math.attack4 = @s health

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s math.attack4 *= @s strong.rate
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s math.attack4 /= 100 math

execute @s[score_math.out=0] ~ ~ ~ tellraw @s[tag=!stopMessage.extraEffect] [{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 对 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@e[tag=LightRPG.temp.hurtMonster,c=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 造成了","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 巨力","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"hoverEvent":{"action":"show_text","value":"巨力"}},{"text":" 效果使其损失了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math.attack4","name":"@s"},"color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血量","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @e[tag=LightRPG.temp.hurtMonster,c=1] health -= @s math.attack4