scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main
scoreboard players operation @s math.out += @p[tag=LightRPG.temp.attackMonster,r=10] hit
	execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=1,score_yf=1] ~-0.5000000000000004 ~+2.5 ~-0.8660254037844385 /summon minecraft:armor_stand ~ ~-1.5 ~ {CustomName:"§e§l被闪避!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=2,score_yf=2] ~-0.6427876096865394 ~+2.5 ~0.766044443118978 /summon minecraft:armor_stand ~ ~-1.5 ~ {CustomName:"§e§l被闪避!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=3,score_yf=3] ~0.9396926207859084 ~+2.5 ~0.3420201433256687 /summon minecraft:armor_stand ~ ~-1.5 ~ {CustomName:"§e§l被闪避!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}

scoreboard players operation @s math.out -= @s dodge
execute @s[score_math.out=0] ~ ~ ~ scoreboard players tag @s add LightRPG.temp.dodge