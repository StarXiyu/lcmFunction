
scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main
scoreboard players operation @s math.out -= @s vampirism
	execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=1,score_yf=1] ~-0.5000000000000004 ~+1.8 ~-0.8660254037844385 /summon minecraft:armor_stand ~ ~-1.1 ~ {CustomName:"§d§l吸血!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=2,score_yf=2] ~-0.6427876096865394 ~+1.8 ~0.756044443118978 /summon minecraft:armor_stand ~ ~-1.1 ~ {CustomName:"§d§l吸血!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=3,score_yf=3] ~-0.17364817766693033 ~ ~-0.984807753012208 /summon minecraft:armor_stand ~ ~-1.1 ~ {CustomName:"§d§l吸血!",Tags:["字幕"],DisabledSlots:65793,CustomNameVisible:1b,Invisible:1b,NoGravity:1b}
execute @s[score_math.out=0] ~ ~ ~ execute @e[tag=LightRPG.temp.hurtMonster,c=1,score_yf_min=3,score_yf=3] ~ ~ ~ particle happyVillager ~ ~ ~ 0.7 0.7 0.7 0.25 20 normal
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 = @s math.attack3
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 *= @s vampirism.rate
execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s temp.math1 /= 100 math

execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s health += @s temp.math1

execute @s[score_math.out=0] ~ ~ ~ tellraw @s[tag=!stopMessage.war] [{"text":"您吸取了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@e[tag=LightRPG.temp.hurtMonster,c=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 的 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"temp.math1","name":"@s"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "}]

scoreboard players operation @s health < @s maxhealth