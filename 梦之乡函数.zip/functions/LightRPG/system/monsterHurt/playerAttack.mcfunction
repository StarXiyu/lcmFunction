
## 备份当前攻击基数
	scoreboard players set @s math.attack1 0
	scoreboard players set @s math.attack2 0
	
	scoreboard players operation @s[tag=temp.physics] math.attack1 = @s[tag=temp.physics] phyAttack
	scoreboard players operation @s[tag=temp.spell] math.attack2 = @s[tag=temp.spell] spellAttack
	
	
## 物理赋值
	scoreboard players operation @s[tag=temp.physics] physics.math2 = @s[tag=temp.physics] physicsPene
	
## 法术赋值
	scoreboard players operation @s[tag=temp.spell] spell.math2 = @s[tag=temp.spell] spellPene