
execute @a[score_cd1_min=1] ~ ~ ~ execute @s[team=挑战中] ~ ~ ~ kill @e[tag=挑战怪物]
execute @a[score_cd1_min=1,score_cd1=5] ~ ~ ~ function 挑战:challenge/timeOut if @s[team=挑战中]
execute @a[score_cd1_min=7] ~ ~ ~ function 挑战:challenge/timeOut if @s[team=挑战中]

tp @a[score_cd1_min=1,score_cd1=1] @e[tag=zc]
kill @a[score_cd1_min=2,score_cd1=2]
tp @a[score_cd1_min=3,score_cd1=3] 1251 3 1288
tp @a[score_cd1_min=4,score_cd1=4] 2229 2 2250
tp @a[score_cd1_min=5,score_cd1=5] 263 4 -1908

execute @a[score_cd1_min=6,score_cd1=6] ~ ~ ~ function system:cd6

tp @a[score_cd1_min=7,score_cd1=7] 1128 3 4438
gamemode 2 @a[score_cd1_min=1,m=0]
title @a[score_cd1_min=1] title "§2§l✔"
title @a[score_cd1_min=1] subtitle "§a§l执行成功"

execute @a[score_cd1_min=8,score_cd1=8] ~ ~ ~ function system:killaura/stop if @s[tag=killaura]
execute @a[score_cd1_min=8,score_cd1=8] ~ ~ ~ function system:killaura/able unless @s[tag=killaura]
execute @a[score_cd1_min=9,score_cd1=9] ~ ~ ~ function system:进阶兵种/面板
 
execute @a[score_cd1_min=1] ~ ~ ~ playsound minecraft:block.note.bell master @s ~ ~ ~
scoreboard players set @a[score_cd1_min=1] cd1 0