
clear @a[x=355,y=4,z=-1497,r=6] iron_ore -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] gold_ore -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] emerald -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] cobblestone -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] coal -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] emerald_block -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] diamond -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] redstone_block -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] iron_block -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] diamond_block -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] coal_block -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] lapis_block -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] gold_block -1 -1 {Tags:["预览"]}
clear @a[x=355,y=4,z=-1497,r=6] dye 4 -1 {Tags:["预览"]}