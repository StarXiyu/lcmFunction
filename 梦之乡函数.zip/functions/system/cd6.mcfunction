
	scoreboard players operation @s math.attribute = @s time.attribute1
	scoreboard players operation @s math.attribute -= systemTick tempBanT1

	## False
	function armor:main if @s[score_math.attribute=-1]
	
	## True
	tellraw @s[score_math.attribute_min=0] "§f[§c§l!§f] §7属性更新还在冷却中,请稍后再试"

	execute @s[score_math.attribute=-1] ~ ~ ~ scoreboard players operation @s time.attribute1 = systemTick tempBanT1
	execute @s[score_math.attribute=-1] ~ ~ ~ scoreboard players add @s time.attribute1 200