
effect @s clear

scoreboard players tag @s[score_hurt.fall_min=0] add temp.disNoFall 

scoreboard players tag @s[tag=!temp.disNoFall] add ban

scoreboard players tag @s remove temp.disNoFall

tp @s @e[tag=zc]

scoreboard players tag @s remove test.noFall

scoreboard players reset @s hurt.fall