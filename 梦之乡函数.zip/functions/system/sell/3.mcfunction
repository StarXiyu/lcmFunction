
scoreboard players set @s reclaim 0
scoreboard players set @s math1 0
stats entity @s set AffectedItems @s reclaim
clear @s red_mushroom 0 0 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lLv3.§b§l伪装者","§b§l✪ §f可在副本大厅兑换装备","","§e§l██████████████"],Name:"§a§l伪装种子"}}
playsound minecraft:block.note.bell block @s

scoreboard players operation @s math1 = @s sell.trigger
## 输入额 - 背包内该材料个数
scoreboard players operation @s math1 -= @s reclaim

tellraw @s[score_math1_min=1] "§7[回收商店] §c材料不足!"
tellraw @s[score_math1=0] "§7[回收商店] §a回收完成"

scoreboard players tag @s[score_math1=0] add temp.sell.success

scoreboard players operation @s[tag=temp.sell.success] math1 = @s[tag=temp.sell.success] sell.trigger
scoreboard players operation @s[tag=temp.sell.success] math1 *= 20 math
scoreboard players operation @s[tag=temp.sell.success] math1 *= @s[tag=temp.sell.success] moneyRate
scoreboard players operation @s[tag=temp.sell.success] money += @s[tag=temp.sell.success] math1
scoreboard players operation @s[tag=temp.sell.success] getMoney += @s[tag=temp.sell.success] math1

scoreboard players operation @s[tag=temp.sell.success] math1 = @s[tag=temp.sell.success] sell.trigger

function system:sell/clear/3 if @s[tag=temp.sell.success]

scoreboard players tag @s[tag=temp.sell.success] remove temp.sell.success

stats entity @s clear AffectedItems