
## 重置数据
scoreboard players reset @s getMoney.math1
scoreboard players reset @s getMoney.math2

## @s getMoney.math1 被转账者的限额
scoreboard players operation @s getMoney.math1 = @s getMoney.limit

## @s getMoney.math2 被转账者的获得额
scoreboard players operation @s getMoney.math2 = @s getMoney

## 限额减去获得额
scoreboard players operation @s getMoney.math1 -= @s getMoney.math2

## 判断是否达到限额
function system:sell/fail if @s[score_getMoney.math1=-1]
function system:sell/success unless @s[score_getMoney.math1=-1]

scoreboard players set @s sell.trigger 0