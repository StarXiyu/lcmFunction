
scoreboard players set @s reclaim 0
scoreboard players set @s math1 0
stats entity @s set AffectedItems @s reclaim
clear @s banner 7 0 {display:{Lore:["§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§f§l物品介绍§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§f寂静沙漠中常见怪物§8[§6§l岁月寒§8]§f的战利品。","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§b§l物品获取§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§b§l在副本兑换处兑换§8[§6§l塞北霜§8]§b§l系列装备。","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§c§l物品信息§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§e§l❂§f§l物品评级 §a§l： §8A","§d§l❂§f§l物品类型 §a§l： §b§l材料","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§8§l八阶材料§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽"],Name:"§f[§8§l> §b§l霜寒 §8§l<§f]"}}
playsound minecraft:block.note.bell block @s

scoreboard players operation @s math1 = @s sell.trigger
## 输入额 - 背包内该材料个数
scoreboard players operation @s math1 -= @s reclaim

tellraw @s[score_math1_min=1] "§7[回收商店] §c材料不足!"
tellraw @s[score_math1=0] "§7[回收商店] §a回收完成"

scoreboard players tag @s[score_math1=0] add temp.sell.success

scoreboard players operation @s[tag=temp.sell.success] math1 = @s[tag=temp.sell.success] sell.trigger
scoreboard players operation @s[tag=temp.sell.success] math1 *= 80 math
scoreboard players operation @s[tag=temp.sell.success] math1 *= @s[tag=temp.sell.success] moneyRate
scoreboard players operation @s[tag=temp.sell.success] money += @s[tag=temp.sell.success] math1
scoreboard players operation @s[tag=temp.sell.success] getMoney += @s[tag=temp.sell.success] math1

scoreboard players operation @s[tag=temp.sell.success] math1 = @s[tag=temp.sell.success] sell.trigger

function system:sell/clear/9 if @s[tag=temp.sell.success]

scoreboard players tag @s[tag=temp.sell.success] remove temp.sell.success

stats entity @s clear AffectedItems