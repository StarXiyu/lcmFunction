
clear @s quartz 0 1 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lLv1.§e§l秘境守卫","§b§l✪ §f可在副本大厅兑换装备","","§e§l██████████████"],Name:"§3§l秘境碎石"}}
scoreboard players remove @s math1 1

function system:sell/clear/1 if @s[score_math1_min=1]