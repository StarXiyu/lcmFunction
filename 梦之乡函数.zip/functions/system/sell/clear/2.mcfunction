
clear @s pumpkin_seeds 0 1 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lLv2.§e§l丛林卫兵","§b§l✪ §f可在副本大厅兑换装备","","§e§l██████████████"],Name:"§a§l丛林种子"}}
scoreboard players remove @s math1 1

function system:sell/clear/2 if @s[score_math1_min=1]