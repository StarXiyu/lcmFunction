
clear @s rabbit_hide 0 1 {display:{Lore:["§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§f§l物品介绍§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§f蛮荒之地中常见怪物§8[§6§l蛮荒行者§8]§f的表皮。","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§b§l物品获取§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§b§l在副本兑换处兑换§8[§6§l蛮荒§8]§b§l系列装备。","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§c§l物品信息§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§e§l❂§f§l物品评级 §a§l： §8A-","§d§l❂§f§l物品类型 §a§l： §b§l材料","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§8§l六阶材料§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽"],Name:"§f[§8§l> §6§l韧皮 §8§l<§f]"}}
scoreboard players remove @s math1 1

function system:sell/clear/6 if @s[score_math1_min=1]