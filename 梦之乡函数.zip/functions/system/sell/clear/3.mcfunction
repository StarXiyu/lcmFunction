
clear @s red_mushroom 0 1 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lLv3.§b§l伪装者","§b§l✪ §f可在副本大厅兑换装备","","§e§l██████████████"],Name:"§a§l伪装种子"}}
scoreboard players remove @s math1 1

function system:sell/clear/3 if @s[score_math1_min=1]