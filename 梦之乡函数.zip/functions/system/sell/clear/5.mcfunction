
clear @s leather 0 1 {display:{Lore:["§e§l██████████████","","§b§l✪ §f材料类 §c副本材料","§b§l✪ §f来源:§a§lLv4.§4§l腐尸","§b§l✪ §f可在副本大厅兑换装备","","§e§l██████████████"],Name:"§4§l腐烂皮革"}}
scoreboard players remove @s math1 1

function system:sell/clear/5 if @s[score_math1_min=1]