
clear @s banner 11 1 {display:{Lore:["§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§f§l物品介绍§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§f寂静沙漠中常见怪物§8[§6§l秋风刀§8]§f的战利品。","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§b§l物品获取§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§b§l在副本兑换处兑换§8[§6§l塞北霜§8]§b§l系列装备。","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§c§l物品信息§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽","","§e§l❂§f§l物品评级 §a§l： §8A","§d§l❂§f§l物品类型 §a§l： §b§l材料","","§f§l☾§c§l§m   §e§l§m   §a§l§m   §b§l§m   [§8§l八阶材料§e§l]§b§l§m   §a§l§m   §e§l§m   §c§l§m   §f§l☽"],Name:"§f[§8§l> §6§l萧瑟 §8§l<§f]"}}

scoreboard players remove @s math1 1

function system:sell/clear/8 if @s[score_math1_min=1]