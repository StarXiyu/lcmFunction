
effect @s 2 0 0
effect @s 4 0 0
effect @s 9 0 0
effect @s 15 0 0
effect @s 17 0 0
effect @s 18 0 0