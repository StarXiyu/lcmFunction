
execute @a[score_cdk_min=1] ~ ~ ~ scoreboard players operation @s 礼包 = @s cdk
scoreboard players set @a[score_cdk_min=1] cdk 0