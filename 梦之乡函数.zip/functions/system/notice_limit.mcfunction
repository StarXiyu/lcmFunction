
scoreboard players set @a[score_time.limit_min=3600] getMoney 0
tellraw @a[score_time.limit_min=3600] "§7[金币限额] §a您的小时金币限额已刷新!"

scoreboard players set @a[score_time.limit_min=3600] time.limit 0