
scoreboard players reset * task
scoreboard players reset * task.jf
scoreboard players reset * task.kill
scoreboard players reset * task.money
scoreboard players reset * task.online