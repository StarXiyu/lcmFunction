
## 属性重置
	scoreboard players set @s phyAttack 0
	scoreboard players set @s spellAttack 0 
	scoreboard players set @s critPob 0
	scoreboard players set @s critAttack 0
	scoreboard players set @s seize 0
	scoreboard players set @s vampirism 0 
	scoreboard players set @s physicsPene 0 
	scoreboard players set @s spellPene 0
	scoreboard players set @s spellResist 0
	scoreboard players set @s physicsResist 0
	scoreboard players set @s dodge 0
	scoreboard players set @s critResist 0
	scoreboard players set @s hit 0
	scoreboard players set @s vampirism.rate 20
	scoreboard players set @s slow 0
	scoreboard players set @s break 0
	scoreboard players set @s strong 0
	scoreboard players set @s reward 0
	scoreboard players set @s rewardPob 0

## 装备属性
	scoreboard players operation @s phyAttack += @s d.phyAttack
	scoreboard players operation @s spellAttack += @s d.spellAttack
	scoreboard players operation @s critPob += @s d.critPob
	scoreboard players operation @s critAttack += @s d.critAttack
	scoreboard players operation @s seize += @s d.seize
	scoreboard players operation @s vampirism += @s d.vampirism
	scoreboard players operation @s physicsPene += @s d.physicsPene
	scoreboard players operation @s spellPene += @s d.spellPene
	scoreboard players operation @s spellResist += @s d.spellResist
	scoreboard players operation @s physicsResist += @s d.physicsResist
	scoreboard players operation @s dodge += @s d.dodge
	scoreboard players operation @s hit += @s d.hit
	scoreboard players operation @s vampirism.rate += @s d.vampirism.rate
	scoreboard players operation @s slow += @s d.slow
	scoreboard players operation @s break += @s d.break
	scoreboard players operation @s strong += @s d.strong
	scoreboard players operation @s reward += @s d.reward
	scoreboard players operation @s rewardPob += @s d.rewardPob