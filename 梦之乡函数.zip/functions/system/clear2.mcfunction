clear @a[x=367,y=4,z=-1477,r=6] minecraft:quartz -1 -1 {Tags:["模型"]}
clear @a[x=367,y=4,z=-1477,r=6] minecraft:red_mushroom -1 -1 {Tags:["模型"]}
clear @a[x=367,y=4,z=-1477,r=6] minecraft:gunpowder -1 -1 {Tags:["模型"]}
clear @a[x=367,y=4,z=-1477,r=6] minecraft:pumpkin_seeds -1 -1 {Tags:["模型"]}
