
scoreboard players set @s boss1.skill 0
scoreboard players add @s boss1.skill1 1
scoreboard players set @s[score_boss1.skill1_min=5] boss1.skill1 1

execute @s[score_boss1.skill1_min=1,score_boss1.skill1=1] ~ ~ ~ execute @a[r=12] ~ ~ ~ function system:boss/1/灭吴
execute @s[score_boss1.skill1_min=2,score_boss1.skill1=2] ~ ~ ~ function system:boss/1/回魂震慑
execute @s[score_boss1.skill1_min=3,score_boss1.skill1=3] ~ ~ ~ function system:boss/1/力场崩坏
execute @s[score_boss1.skill1_min=4,score_boss1.skill1=4] ~ ~ ~ function system:boss/1/时空裂缝

function system:boss/1/时空裂缝time if @e[tag=时空裂缝分身]