
execute @a[r=20] ~ ~ ~ title @s title "§e§l『回魂震慑』"
tellraw @a[r=20] "§e<< 回魂震慑 >>"

execute @a[r=20] ~ ~ ~ particle witchMagic ~ ~ ~ 1 2 1 0.1 50 force @s
execute @a[r=20] ~ ~ ~ playsound minecraft:entity.wither.shoot ambient @s

execute @a[r=20] ~ ~ ~ scoreboard players operation @s 回魂.backup1 = @s d.spellAttack
execute @a[r=20] ~ ~ ~ scoreboard players operation @s d.spellAttack *= 40 math
execute @a[r=20] ~ ~ ~ scoreboard players operation @s d.spellAttack /= 100 math
execute @a[r=20] ~ ~ ~ scoreboard players operation @s 回魂.backup2 = @s d.phyAttack
execute @a[r=20] ~ ~ ~ scoreboard players operation @s d.phyAttack *= 40 math
execute @a[r=20] ~ ~ ~ scoreboard players operation @s d.phyAttack /= 100 math

scoreboard players operation @s boss.math = @s health
scoreboard players operation @s boss.math *= 30 math
scoreboard players operation @s boss.math /= 100 math
scoreboard players operation @s health += @s boss.math
scoreboard players operation @s health < @s maxhealth