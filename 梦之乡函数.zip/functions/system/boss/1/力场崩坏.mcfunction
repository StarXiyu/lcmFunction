
execute @a[r=20] ~ ~ ~ title @s title "§e§l『力场崩坏』"
tellraw @a[r=20] "§e<< 力场崩坏 >>"

execute @a[r=20] ~ ~ ~ particle witchMagic ~ ~ ~ 1 2 1 0.1 50 force @s
execute @a[r=20] ~ ~ ~ playsound minecraft:record.11 ambient @s ~ ~ ~

execute @a[r=20] ~ ~ ~ effect @s minecraft:levitation 6 1
execute @a[r=20] ~ ~ ~ effect @s minecraft:blindness 6 1
execute @a[r=20] ~ ~ ~ scoreboard players set @s 力场崩坏 6