
scoreboard players operation @s boss.math2 = @s maxhealth
scoreboard players operation @s boss.math2 *= 10 math
scoreboard players operation @s boss.math2 /= 100 math
scoreboard players operation @s health -= @s boss.math2

kill @s[score_health=0]
scoreboard players set @s[score_health=0] 力场崩坏 0
function LightRPG:playerDie/init unless @s[score_maxhealth_min=0]
execute @s[score_health=0] ~ ~ ~ scoreboard players operation @s health = @s maxhealth

tellraw @s[tag=!stopMessage.war] [{"text":"§6§l[力场崩坏] ","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"你损失了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"boss.math2","name":"@s"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血量","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard players remove @s 力场崩坏 1