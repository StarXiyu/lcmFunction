
scoreboard players add @s 时空裂缝 1

execute @s[score_时空裂缝_min=10] ~ ~ ~ kill @e[tag=时空裂缝分身]
execute @s[score_时空裂缝_min=10] ~ ~ ~ scoreboard players add @s health 5000
execute @s[score_时空裂缝_min=10] ~ ~ ~ scoreboard players operation @s health < @s maxhealth

execute @s[score_时空裂缝_min=10] ~ ~ ~ execute @a[r=20] ~ ~ ~ scoreboard players operation @s d.spellAttack = @s 回魂.backup1
execute @s[score_时空裂缝_min=10] ~ ~ ~ execute @a[r=20] ~ ~ ~ scoreboard players operation @s d.phyAttack = @s 回魂.backup2

execute @s[score_时空裂缝_min=10] ~ ~ ~ scoreboard players set @s 时空裂缝 0