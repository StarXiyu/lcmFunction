
title @a title " §e§l记忆·BOSS "
title @a subtitle " §f- 召唤成功，快前去讨伐吧! -"

execute @a[r=10] ~ ~ ~ summon minecraft:lightning_bolt

summon minecraft:zombie_pigman ~ ~2 ~ {CustomName:"§c[BOSS/火系] §e§l记忆·BOSS §4§l<Lv.T1>",Tags:["nk","monster","boss","记忆boss","element.fire"],CustomNameVisible:1b,Passengers:[{CustomName:"§c§l■■§6§l■■§e§l■■§a§l■■§b§l■■",Tags:["hpBar.hpDisplay"],CustomNameVisible:1b,Invulnerable:1b,Motion:[0.0,0.0,0.0],id:"minecraft:snowball",Passengers:[{CustomName:"§c[BOSS/火系] §e§l记忆·BOSS §4§l<Lv.T1>",Tags:["hpBar.name"],CustomNameVisible:1b,Invulnerable:1b,Motion:[0.0,0.0,0.0],id:"minecraft:snowball"}]}],PersistenceRequired:1b,Health:100,DeathLootTable:"entities/empty",Attributes:[{Name:"generic.maxHealth",Base:100},{Name:"generic.movementSpeed",Base:0.6},{Name:"generic.knockbackResistance",Base:1},{Name:"generic.followRange",Base:20}]}

setblock 1016 5 1124 air

scoreboard players set @e[tag=记忆boss] health 50000
scoreboard players set @e[tag=记忆boss] maxhealth 50000
scoreboard players set @e[tag=记忆boss] phyAttack 800
scoreboard players set @e[tag=记忆boss] physicsPene 600
scoreboard players set @e[tag=记忆boss] physicsResist 800
scoreboard players set @e[tag=记忆boss] spellResist 500
scoreboard players set @e[tag=记忆boss] dodge 20
scoreboard players set @e[tag=记忆boss] drop 1000
scoreboard players set @e[tag=记忆boss] msp.number 14