
scoreboard players add @s boss1.skill 1
scoreboard players add @s boss1.time 1

function system:boss/1/fail if @s[score_boss1.time_min=360]

function system:boss/1/skill if @s[score_boss1.skill_min=5]

execute @a[score_力场崩坏_min=1] ~ ~ ~ function system:boss/1/力场崩坏player