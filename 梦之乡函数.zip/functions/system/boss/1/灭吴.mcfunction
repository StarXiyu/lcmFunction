
## 选择攻击的怪物
scoreboard players tag @e[r=10,c=1,tag=记忆boss] add LightRPG.temp.pve.attackPlayer

scoreboard players set @e[r=10,c=1,tag=记忆boss] spellAttack 750
scoreboard players set @e[r=10,c=1,tag=记忆boss] spellPene 500

scoreboard players tag @s add LightRPG.temp.pve.hurtPlayer

execute @p[tag=LightRPG.temp.pve.hurtPlayer] ~ ~ ~ function LightRPG:system/pve/main

scoreboard players set @e[r=10,c=1,tag=记忆boss] spellAttack 0
scoreboard players set @e[r=10,c=1,tag=记忆boss] spellPene 0

title @s title "§e§l『灭吴』"
tellraw @a[r=20] "§e<< 灭吴 >>"

particle fireworksSpark ~ ~ ~ 1 2 1 0.01 20 force @s 6
playsound minecraft:entity.wither.shoot ambient @s