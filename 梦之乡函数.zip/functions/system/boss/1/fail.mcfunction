title @a title "§4§l记忆BOSS挑战失败"

kill @e[tag=记忆boss]
kill @e[tag=时空裂缝分身]

scoreboard players reset @a 力场崩坏
scoreboard players reset @a 记忆.damage