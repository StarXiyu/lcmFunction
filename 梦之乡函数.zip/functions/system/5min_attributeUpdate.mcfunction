
execute @a[score_time.attribute_min=300] ~ ~ ~ function system:无提示属性更新
scoreboard players reset @a[score_time.attribute_min=300] time.attribute