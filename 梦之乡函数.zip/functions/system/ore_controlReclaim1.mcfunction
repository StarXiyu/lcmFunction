
scoreboard players operation @s conReclaim.money = @s getMoney.limit
scoreboard players operation @s conReclaim.money -= @s getMoney

scoreboard players operation @s money += @s conReclaim.money
scoreboard players operation @s getMoney += @s conReclaim.money
tellraw @s [{"text":"本次获得 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"conReclaim.money","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 金币","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard players reset @s conReclaim.money

	clear @s cobblestone 0 -1
	clear @s dye 4 -1
	clear @s coal 0 -1
	clear @s iron_ore 0 -1
	clear @s gold_ore 0 -1
	clear @s emerald 0 -1
	clear @s diamond 0 -1
	clear @s coal_block 0 -1
	clear @s lapis_block 0 -1
	clear @s redstone_block 0 -1
	clear @s iron_block 0 -1
	clear @s gold_block 0 -1
	clear @s emerald_block 0 -1
	clear @s diamond_block 0 -1