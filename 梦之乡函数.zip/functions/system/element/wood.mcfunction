
function system:element/wood_now if @s[tag=element.own.wood]
function system:element/wood_buy if @s[tag=!element.own.wood]