
scoreboard players set @s reclaim 0
stats entity @s set AffectedItems @s reclaim

clear @s paper 0 1 {HideFlags:63,display:{Name:"§6§l岩元素兑换券"},Tags:["岩"]}

execute @s[score_reclaim=0,score_reclaim_min=0] ~ ~ ~ tellraw @s "§f[§6梦之乡§f] §8>> §c岩元素兑换失败,请检查你的背包"
execute @s[score_reclaim_min=1] ~ ~ ~ tellraw @s "§f[§6梦之乡§f] §8>> §a岩元素兑换成功,再次点击即可替换"
execute @s[score_reclaim_min=1] ~ ~ ~ scoreboard players tag @s add element.own.rock

stats entity @s clear AffectedItems