
scoreboard players tag @s remove element.water
scoreboard players tag @s remove element.fire
scoreboard players tag @s remove element.rock
scoreboard players tag @s remove element.wood

scoreboard players tag @s add element.fire

title @s title "§f§l元素装载成功:§c§l火"