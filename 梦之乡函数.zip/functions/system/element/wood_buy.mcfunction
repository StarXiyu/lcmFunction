
scoreboard players set @s reclaim 0
stats entity @s set AffectedItems @s reclaim

clear @s paper 0 1 {ench:[{lvl:1s,id:0s}],HideFlags:1,display:{Name:"§2§l木元素兑换券"},Tags:["木元素兑换券"]}

execute @s[score_reclaim=0,score_reclaim_min=0] ~ ~ ~ tellraw @s "§f[§6梦之乡§f] §8>> §c木元素兑换失败,请检查你的背包"
execute @s[score_reclaim_min=1] ~ ~ ~ tellraw @s "§f[§6梦之乡§f] §8>> §a木元素兑换成功,再次点击即可替换"
execute @s[score_reclaim_min=1] ~ ~ ~ scoreboard players tag @s add element.own.wood

stats entity @s clear AffectedItems