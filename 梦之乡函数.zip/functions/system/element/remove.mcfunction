
scoreboard players tag @s remove element.water
scoreboard players tag @s remove element.fire
scoreboard players tag @s remove element.rock
scoreboard players tag @s remove element.wood

title @s title "§f§l元素卸载成功"