
function system:element/rock_now if @s[tag=element.own.rock]
function system:element/rock_buy if @s[tag=!element.own.rock]