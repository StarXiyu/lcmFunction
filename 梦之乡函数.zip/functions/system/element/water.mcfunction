
function system:element/water_now if @s[tag=element.own.water]
function system:element/water_buy if @s[tag=!element.own.water]