
scoreboard players tag @s remove element.water
scoreboard players tag @s remove element.fire
scoreboard players tag @s remove element.rock
scoreboard players tag @s remove element.wood

scoreboard players tag @s add element.water

title @s title "§f§l元素装载成功:§b§l水"