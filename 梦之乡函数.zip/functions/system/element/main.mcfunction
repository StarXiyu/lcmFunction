
function system:element/fire if @s[score_element_min=1,score_element=1]
function system:element/water if @s[score_element_min=2,score_element=2]
function system:element/wood if @s[score_element_min=3,score_element=3]
function system:element/rock if @s[score_element_min=4,score_element=4]

function system:element/remove if @s[score_element_min=10,score_element=10]

scoreboard players set @s element 0