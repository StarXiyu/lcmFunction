
function system:element/fire_now if @s[tag=element.own.fire]
function system:element/fire_buy if @s[tag=!element.own.fire]