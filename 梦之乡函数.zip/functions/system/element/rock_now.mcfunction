
scoreboard players tag @s remove element.water
scoreboard players tag @s remove element.fire
scoreboard players tag @s remove element.rock
scoreboard players tag @s remove element.wood

scoreboard players tag @s add element.rock

title @s title "§f§l元素装载成功:§1§l岩"