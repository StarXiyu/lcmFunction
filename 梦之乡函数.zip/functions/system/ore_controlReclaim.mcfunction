## 原石1 青金石1 煤炭2 铁矿3 金矿4 绿宝石5 钻石6
## 煤炭块9 青金石块9 红石块12 铁块18
## 金块36 绿宝石块45 钻石块54

## 初始化
	scoreboard players reset @s controlReclaim
	scoreboard players set @s reclaim 0
	scoreboard players set @s math1 0
	stats entity @s set AffectedItems @s reclaim
	playsound minecraft:block.note.bell block @s
	
## 原石
	clear @s cobblestone 0 0
	scoreboard players operation @s math1 += @s reclaim

## 青金石
	clear @s dye 4 0
	scoreboard players operation @s math1 += @s reclaim

## 煤炭
	clear @s coal 0 0
	scoreboard players operation @s reclaim *= 2 math
	scoreboard players operation @s math1 += @s reclaim

## 铁矿
	clear @s iron_ore 0 0
	scoreboard players operation @s reclaim *= 3 math
	scoreboard players operation @s math1 += @s reclaim

## 金块
	clear @s gold_ore 0 0
	scoreboard players operation @s reclaim *= 4 math
	scoreboard players operation @s math1 += @s reclaim

## 绿宝石
	clear @s emerald 0 0
	scoreboard players operation @s reclaim *= 5 math
	scoreboard players operation @s math1 += @s reclaim

## 钻石
	clear @s diamond 0 0
	scoreboard players operation @s reclaim *= 6 math
	scoreboard players operation @s math1 += @s reclaim

## 煤炭块
	clear @s coal_block 0 0
	scoreboard players operation @s reclaim *= 9 math
	scoreboard players operation @s math1 += @s reclaim

## 青金石块
	clear @s lapis_block 0 0
	scoreboard players operation @s reclaim *= 9 math
	scoreboard players operation @s math1 += @s reclaim

## 红石块
	clear @s redstone_block 0 0
	scoreboard players operation @s reclaim *= 12 math
	scoreboard players operation @s math1 += @s reclaim

## 铁块
	clear @s iron_block 0 0
	scoreboard players operation @s reclaim *= 18 math
	scoreboard players operation @s math1 += @s reclaim

## 金块
	clear @s gold_block 0 0
	scoreboard players operation @s reclaim *= 36 math
	scoreboard players operation @s math1 += @s reclaim

## 绿宝石块
	clear @s emerald_block 0 0
	scoreboard players operation @s reclaim *= 45 math
	scoreboard players operation @s math1 += @s reclaim

## 钻石块
	clear @s diamond_block 0 0
	scoreboard players operation @s reclaim *= 54 math
	scoreboard players operation @s math1 += @s reclaim

## 金币倍率
	scoreboard players operation @s math1 *= @s moneyRate

## 重置数据
scoreboard players reset @s getMoney.math1
scoreboard players reset @s getMoney.math2

## @s getMoney.math1 被转账者的限额
scoreboard players operation @s getMoney.math1 = @s getMoney.limit

## @s getMoney.math2 被转账者的获得额
scoreboard players operation @s getMoney.math2 = @s getMoney
scoreboard players operation @s getMoney.math2 += @s math1

## 限额减去获得额
scoreboard players operation @s getMoney.math1 -= @s getMoney.math2

## 判断是否达到限额
function system:ore_controlReclaim1 if @s[score_getMoney.math1=0]
function system:reclaim/reclaim unless @s[score_getMoney.math1=0]
