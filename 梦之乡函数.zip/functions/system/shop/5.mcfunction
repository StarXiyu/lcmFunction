scoreboard players set @s price 12000
function api:shop/choose

give @s[tag=购买成功] iron_sword 1 0 {ench:[{lvl:1s,id:6s}],Unbreakable:1b,HideFlags:7,display:{Lore:["§e§l██████████████"," ","§b§l✪ §r武器类 §c物理武器","§b§l✪ §r品质评级 §7B-","§b§l✪ §4来自技艺高超的铁匠"," ","§9§l▷▷▷▷▷▷ §6§l武器属性 §9§l◁◁◁◁◁◁"," ","§a§l● §7物理伤害 §a+28","§a§l● §7暴击率 §a+25%","§a§l● §7移速 §a+10%","§l§a● §7暴击伤害 §a+20%","","§e§l██████████████"],Name:"§8§l『 §l§b§l寒锋剑 §8§l』"},Tags:["寒锋剑","item.weapon"],AttributeModifiers:[{UUIDMost:121222176641926880L,UUIDLeast:-6336535400853084956L,Amount:0.1d,AttributeName:"generic.movementSpeed",Operation:1,Name:"generic.movementSpeed"}]}
function api:shop/succes if @s[tag=购买成功]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number