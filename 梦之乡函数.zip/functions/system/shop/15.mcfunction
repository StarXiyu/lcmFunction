scoreboard players set @s price 120000
function api:shop/choose

give @s[tag=购买成功] iron_sword 1 0 {ench:[{lvl:1s,id:6s}],Unbreakable:1b,HideFlags:7,display:{Lore:["§e§l██████████████"," ","§b§l✪ §r武器类 §c物理武器","§b§l✪ §r品质评级 §7§3B+","§b§l✪ §4经过寒夜洗礼的剑"," ","§9§l▷▷▷▷▷▷ §6§l武器属性 §9§l◁◁◁◁◁◁"," ","§a§l● §7物理伤害 §a+50","§a§l● §7暴击率 §a+30%","§a§l● §7移速 §a+10%","§a§l● §7物理穿透 §a+30","§a● §7暴击伤害 §a+40%","","§e§l██████████████"],Name:"§8§l『 §e§l影流 §8§l』"},Tags:["影流","item.weapon"],AttributeModifiers:[{UUIDMost:-2492549613043561871L,UUIDLeast:-8856334825624906929L,Amount:0.1d,AttributeName:"generic.movementSpeed",Operation:1,Name:"generic.movementSpeed"}]}
function api:shop/succes if @s[tag=购买成功]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number