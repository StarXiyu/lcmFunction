scoreboard players set @s price 400000
function api:shop/choose

execute @s[tag=购买成功] ~ ~ ~ tellraw @s[tag=B] "§7[通行证] §c你已经拥有该通行证了"
execute @s[tag=购买成功] ~ ~ ~ scoreboard players tag @s[tag=A] remove 购买成功

scoreboard players tag @s[tag=购买成功] add 通行B

execute @s[tag=购买成功] ~ ~ ~ scoreboard players operation @s money -= @s price
execute @s[tag=购买成功] ~ ~ ~ tellraw @s[tag=购买成功] "§7[通行证] §a购买成功,你可以前往§fB级矿区§a了"
execute @s[tag=购买成功] ~ ~ ~ scoreboard players tag @s remove 购买成功

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number