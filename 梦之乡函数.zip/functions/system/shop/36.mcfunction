scoreboard players enable @s sell.trigger
scoreboard players set @s sell 6

tellraw @s [{"text":"\n[回收商店]","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 你已选中回收 →","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 韧皮","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n[点此设置回收数量]\n","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"suggest_command","value":"/trigger sell.trigger set "}}]

scoreboard players tag @s add system.temp.find.number

scoreboard players set @s shop 0
playsound entity.experience_orb.pickup master @s ~ ~ ~ 2000 0 0