scoreboard players set @s price 5000
function api:shop/choose

give @s[tag=购买成功] iron_sword 1 0 {ench:[{lvl:1s,id:6s}],Unbreakable:1b,HideFlags:7,display:{Lore:["§e§l██████████████"," ","§b§l✪ §r武器类 §c物理武器","§b§l✪ §r品质评级 §7C+","§b§l✪ §d顺着旅途继续前进吧"," ","§9§l▷▷▷▷▷▷ §6§l武器属性 §9§l◁◁◁◁◁◁"," ","§a§l● §7物理伤害 §a+18","§a§l● §7暴击率 §a+25%","§a§l● §7移速 §a+15%","§a● §7暴击伤害 §a+10%","","§e██████████████"],Name:"§8§l『 §e§l精英剑 §8§l』"},Tags:["精英剑","item.weapon"],AttributeModifiers:[{UUIDMost:-1221092324369677134L,UUIDLeast:-8162798599865697345L,Amount:0.15d,AttributeName:"generic.movementSpeed",Operation:1,Name:"generic.movementSpeed"}]}
function api:shop/succes if @s[tag=购买成功]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number