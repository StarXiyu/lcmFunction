scoreboard players set @s price 80000
function api:shop/choose

scoreboard players add @s[tag=购买成功] yf 50
function api:shop/succes if @s[tag=购买成功]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number