scoreboard players set @s price 80000
function api:shop/choose

give @s[tag=购买成功] minecraft:white_shulker_box 1 0
function api:shop/succes if @s[tag=购买成功]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number