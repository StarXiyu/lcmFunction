scoreboard players set @s price 300000
function api:shop/choose

execute @s[tag=prefix.自成一派] ~ ~ ~ tellraw @s[tag=购买成功] "§7[称号仓库] §c你已经拥有这个称号了"
execute @s[tag=prefix.自成一派] ~ ~ ~ scoreboard players tag @s remove 购买成功

scoreboard players tag @s[tag=购买成功] add prefix.自成一派

execute @s[tag=购买成功] ~ ~ ~ scoreboard players operation @s money -= @s price
execute @s[tag=购买成功] ~ ~ ~ tellraw @s[tag=购买成功] "§7[称号仓库] §a购买成功,您可以在§f称号仓库§a中替换"
execute @s[tag=购买成功] ~ ~ ~ scoreboard players tag @s remove 购买成功

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number