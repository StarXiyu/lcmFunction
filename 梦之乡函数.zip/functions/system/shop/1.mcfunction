scoreboard players set @s price 1000
function api:shop/choose

give @s[tag=购买成功] iron_sword 1 0 {ench:[{lvl:1s,id:6s}],Unbreakable:1b,HideFlags:7,display:{Lore:["§e§l██████████████"," ","§b§l✪ §r武器类 §c物理武器","§b§l✪ §r品质评级 §7C","§b§l✪ §c旅者亲手打造的第一把武器"," ","§9§l▷▷▷▷▷▷ §6§l武器属性 §9§l◁◁◁◁◁◁"," ","§a§l● §7物理伤害 §a+12","§a§l● §7暴击率 §a+25%","§a§l● §7移速 §a+15%"," ","§e§l██████████████"],Name:"§8§l『 §l§b§l纯铁剑 §8§l』"},Tags:["纯铁剑","item.weapon"],AttributeModifiers:[{UUIDMost:7616491027701058099L,UUIDLeast:-5110262376468283166L,Amount:0.15d,AttributeName:"generic.movementSpeed",Operation:1,Name:"generic.movementSpeed"}]}
function api:shop/succes if @s[tag=购买成功]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number