scoreboard players set @s price 10000
function api:shop/choose

give @s[tag=购买成功] iron_pickaxe 1 0 {ench:[{lvl:4s,id:32s}],Unbreakable:1b,HideFlags:15,display:{Lore:["§e§l██████████████","","§b§l✪ §r工具类 §6镐子","§b§l✪ §r品质评级 §7B-","§b§l✪ §c星会指引前行之路","","§9§l▷▷▷▷▷▷ §6§l工具属性 §9§l◁◁◁◁◁◁","","§a§l● §7效率 §aIV","§a§l● §7移速 §a+10%","","§e§l██████████████"],Name:"§8§l『 §e§l星之镐 §8§l』"},AttributeModifiers:[{UUIDMost:2328714346168136642L,UUIDLeast:-1327757188128219857L,Amount:0.1d,Slot:"mainhand",AttributeName:"generic.movementSpeed",Operation:1,Name:"generic.movementSpeed"}],CanDestroy:["minecraft:coal_ore","minecraft:iron_ore","minecraft:gold_ore","minecraft:lapis_ore","minecraft:diamond_ore","minecraft:emerald_ore","minecraft:cobblestone","minecraft:lapis_block","minecraft:gold_block","minecraft:iron_block","minecraft:diamond_block","minecraft:emerald_block","minecraft:redstone_block","minecraft:coal_block"]}
function api:shop/succes if @s[tag=购买成功]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number