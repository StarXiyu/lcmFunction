scoreboard players set @s price 10000
function api:shop/choose

give @s[tag=购买成功] minecraft:gold_ingot 1 0 {display:{Name:"§4§l金砖"},Tags:["金砖"],HideFlags:63,ench:[{id:6s,lvl:1s}]}
function api:shop/succes if @s[tag=购买成功]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number