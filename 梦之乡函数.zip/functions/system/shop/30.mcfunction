scoreboard players set @s price 400000

# 尝试购买金币限额
scoreboard players tag @s add 尝试购买金币限额
scoreboard players tag @s[score_金币限额购买次数_min=41] remove 尝试购买金币限额
tellraw @s[tag=!尝试购买金币限额] [{"text":"[系统商店]","color":"yellow","bold":true},{"text":"您已购买到上限，无法继续购买","color":"green","bold":true}]
scoreboard players add @s[tag=尝试购买金币限额] 金币限额购买次数 1
function api:shop/choose


scoreboard players add @s[tag=购买成功,score_金币限额购买次数=40] getMoney.limit 5000
tellraw @s[tag=购买成功,score_金币限额购买次数=40] [{"text":"[系统商店]","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"当前每小时金币限额为","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"getMoney.limit","name":"@s"},"color":"light_purple","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

function api:shop/succes if @s[tag=购买成功,score_金币限额购买次数=40]

function api:shop/unsucces if @s[tag=购买失败]

scoreboard players tag @s add system.temp.find.number

scoreboard players tag @s remove 尝试购买金币限额