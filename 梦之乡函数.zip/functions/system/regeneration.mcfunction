
execute @a[score_regeneration_min=1] ~ ~ ~ scoreboard players operation @s health += @s regeneration
execute @a[score_regeneration_min=1] ~ ~ ~ scoreboard players operation @s health < @s maxhealth