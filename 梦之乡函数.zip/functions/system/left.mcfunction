scoreboard players set @s left 0

function 挑战:challenge/timeOut if @s[team=挑战中]

tellraw @s[score_锐意新势_min=1] [{"text":"§f[§6梦之乡§f] §8>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" §a§l[锐意新势] §f效果生效中 剩余时间","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"hoverEvent":{"action":"show_text","value":"§f金币限额§a+30000\n§f金币倍率§a+3\n§f物法攻击提高§a+10\n§f血量上限提高§a+30\n§f双抗提高§a+50\n§f赏金猎人§a+50%\n§f赏金§a+4"}},{"score":{"objective":"锐意新势","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"秒","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

execute @s[tag=SVIP+] ~ ~ ~ scoreboard players operation @s time.limit1 -= systemTick tempBanT1
execute @s[tag=SVIP+] ~ ~ ~ scoreboard players operation @s time.limit1 *= -1 math
execute @s[tag=SVIP+] ~ ~ ~ scoreboard players operation @s time.limit1 /= 20 math
execute @s[tag=SVIP+] ~ ~ ~ scoreboard players operation @s time.limit += @s time.limit1
execute @s[tag=SVIP+] ~ ~ ~ scoreboard players operation @s time.limit1 = systemTick tempBanT1

scoreboard players reset @s hurt.fall

scoreboard players tag @s add test.noFall
tp @s 411 6 -1463