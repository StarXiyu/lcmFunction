
function system:damageMain

execute @e[r=5,tag=monster,c=1] ~ ~ ~ scoreboard players tag @s[tag=enable.killaura] add LightRPG.temp.hurtMonster
execute @e[r=5,tag=monster,c=1] ~ ~ ~ function system:killaura/特效
scoreboard players tag @s add LightRPG.temp.attackMonster
execute @e[tag=LightRPG.temp.hurtMonster,r=10] ~ ~ ~ effect @s minecraft:wither 1 1 true
execute @e[tag=LightRPG.temp.hurtMonster,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/main