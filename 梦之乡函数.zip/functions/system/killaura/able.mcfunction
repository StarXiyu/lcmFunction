
tellraw @s "§f[§4范围杀戮§f] §8>> §a开启成功,只攻击范围内小怪,不攻击玩家及BOSS"

tellraw @s "§f[§4范围杀戮§f] §8>> §f手动攻击生物后自动解除本功能"

scoreboard players tag @s add killaura

scoreboard players set @s cd1 0