
tellraw @s "§f[§4范围杀戮§f] §8>> §f已为您关闭范围杀戮"

scoreboard players tag @s remove killaura

scoreboard players set @s cd1 0