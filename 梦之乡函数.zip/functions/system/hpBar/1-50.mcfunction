
execute @s[score_hpBar.math_min=1,score_hpBar.math=10] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■§f§l■§f§l■■§f§l■■§f§l■■§f§l■■"}
execute @s[score_hpBar.math_min=11,score_hpBar.math=20] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§f§l■■§f§l■■§f§l■■§f§l■■"}
execute @s[score_hpBar.math_min=21,score_hpBar.math=30] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§6§l■§f§l■§f§l■■§f§l■■§f§l■■"}
execute @s[score_hpBar.math_min=31,score_hpBar.math=40] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§6§l■■§f§l■■§f§l■■§f§l■■"}
execute @s[score_hpBar.math_min=41,score_hpBar.math=50] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§6§l■■§e§l■§f§l■§f§l■■§f§l■■"}