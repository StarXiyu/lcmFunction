
execute @s[score_hpBar.math_min=51,score_hpBar.math=60] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§6§l■■§e§l■■§f§l■■§f§l■■"}
execute @s[score_hpBar.math_min=61,score_hpBar.math=70] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§6§l■■§e§l■■§a§l■§f§l■§f§l■■"}
execute @s[score_hpBar.math_min=71,score_hpBar.math=80] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§6§l■■§e§l■■§a§l■■§f§l■■"}
execute @s[score_hpBar.math_min=81,score_hpBar.math=90] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§6§l■■§e§l■■§a§l■■§b§l■§f§l■"}
execute @s[score_hpBar.math_min=91,score_hpBar.math=100] ~ ~ ~ execute @e[c=1,r=2,tag=hpBar.hpDisplay] ~ ~ ~ entitydata @s {CustomName:"§c§l■■§6§l■■§e§l■■§a§l■■§b§l■■"}