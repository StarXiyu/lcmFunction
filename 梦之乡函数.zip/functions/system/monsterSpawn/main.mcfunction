
scoreboard players remove @s msp.time 1
function system:monsterSpawn/displaySummonTime/main if @s[score_msp.time_min=1]

execute @s[score_msp.number=12,score_msp.number_min=12] ~ ~ ~ function system:monsterSpawn/monster/12 unless @s[score_msp.time_min=1]
execute @s[score_msp.number=13,score_msp.number_min=13] ~ ~ ~ function system:monsterSpawn/monster/13 unless @s[score_msp.time_min=1]
execute @s[score_msp.number=15,score_msp.number_min=15] ~ ~ ~ function system:monsterSpawn/monster/15 unless @s[score_msp.time_min=1]
execute @s[score_msp.number=16,score_msp.number_min=16] ~ ~ ~ function system:monsterSpawn/monster/16 unless @s[score_msp.time_min=1]