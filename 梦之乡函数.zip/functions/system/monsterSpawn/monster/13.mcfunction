
## 周围有相同种类怪物
scoreboard players set @s msp.math 0
scoreboard players set @e[r=10,score_msp.number_min=13,score_msp.number=13,tag=monster] msp.math 1
scoreboard players operation @s msp.math += @e[r=10,score_msp.number_min=13,score_msp.number=13,tag=monster] msp.math
scoreboard players operation @s msp.math -= @s msp.count
function system:monsterSpawn/displaySummonTime/out unless @s[score_msp.math=-1]
function system:monsterSpawn/summon/13 if @s[score_msp.math=-1]