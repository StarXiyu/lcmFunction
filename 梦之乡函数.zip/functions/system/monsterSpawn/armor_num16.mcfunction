
summon minecraft:armor_stand ~ ~-1 ~ {CustomNameVisible:0b,Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b,ArmorItems:[{},{},{},{id:"minecraft:mob_spawner",Count:1b,Damage:0s}],Invisible:1,NoBasePlate:1,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
summon minecraft:armor_stand ~ ~-0.5 ~ {CustomName:"§f刷怪点 §4§l原初·岩",CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b,ArmorItems:[{},{},{},{id:"minecraft:air",Count:1b,Damage:0s}],Invisible:1,NoBasePlate:1,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
summon minecraft:armor_stand ~ ~-1 ~ {CustomName:"§f刷怪时间 §e§l30秒",CustomNameVisible:1b,Tags:["monsterSpawn"],Invulnerable:1b,PersistenceRequired:1b,NoGravity:1b,Invisible:1,NoBasePlate:1,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}

scoreboard players set @e[tag=monsterSpawn,r=3,c=1,type=armor_stand] msp.number 16
scoreboard players set @e[tag=monsterSpawn,r=3,c=1,type=armor_stand] msp.count 1
scoreboard players set @e[tag=monsterSpawn,r=3,c=1,type=armor_stand] msp.time 30
scoreboard players set @e[tag=monsterSpawn,r=3,c=1,type=armor_stand] msp.maxTime 30