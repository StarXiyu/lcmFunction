
scoreboard players operation @s msp.time = @s msp.maxTime

summon minecraft:skeleton ~ ~1.5 ~ {CustomName:"§c[敌对/岩系] §7原初·岩 §6<Lv.9>",Tags:["monster","element.rock","system.spawn.fx","monster.math","原初·岩"],CustomNameVisible:1b,Passengers:[{CustomName:"§c§l■■§6§l■■§e§l■■§a§l■■§b§l■■",Tags:["hpBar.hpDisplay"],CustomNameVisible:1b,Invulnerable:1b,Motion:[0.0,0.0,0.0],id:"minecraft:snowball",Passengers:[{CustomName:"§c[敌对/岩系] §7原初·岩 §6<Lv.9>",Tags:["hpBar.name"],CustomNameVisible:1b,Invulnerable:1b,Motion:[0.0,0.0,0.0],id:"minecraft:snowball"}]}],DeathLootTable:"entities/empty"}

execute @e[tag=system.spawn.fx] ~ ~ ~ function api:spawn/怪物发射/main