entitydata @s[score_msp.time_min=1,score_msp.time=1] {CustomName:"§f刷怪时间 §e§l1秒"}
entitydata @s[score_msp.time_min=2,score_msp.time=2] {CustomName:"§f刷怪时间 §e§l2秒"}
entitydata @s[score_msp.time_min=3,score_msp.time=3] {CustomName:"§f刷怪时间 §e§l3秒"}
entitydata @s[score_msp.time_min=4,score_msp.time=4] {CustomName:"§f刷怪时间 §e§l4秒"}
entitydata @s[score_msp.time_min=5,score_msp.time=5] {CustomName:"§f刷怪时间 §e§l5秒"}