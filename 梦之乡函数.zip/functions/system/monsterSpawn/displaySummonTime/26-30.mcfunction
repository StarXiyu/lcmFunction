entitydata @s[score_msp.time_min=26,score_msp.time=26] {CustomName:"§f刷怪时间 §e§l26秒"}
entitydata @s[score_msp.time_min=27,score_msp.time=27] {CustomName:"§f刷怪时间 §e§l27秒"}
entitydata @s[score_msp.time_min=28,score_msp.time=28] {CustomName:"§f刷怪时间 §e§l28秒"}
entitydata @s[score_msp.time_min=29,score_msp.time=29] {CustomName:"§f刷怪时间 §e§l29秒"}
entitydata @s[score_msp.time_min=30,score_msp.time=30] {CustomName:"§f刷怪时间 §e§l30秒"}