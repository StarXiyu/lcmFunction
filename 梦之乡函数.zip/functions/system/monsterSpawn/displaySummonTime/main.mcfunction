
function system:monsterSpawn/displaySummonTime/1-10 if @s[score_msp.time_min=1,score_msp.time=10]
function system:monsterSpawn/displaySummonTime/11-20 if @s[score_msp.time_min=11,score_msp.time=20]
function system:monsterSpawn/displaySummonTime/21-30 if @s[score_msp.time_min=21,score_msp.time=30]