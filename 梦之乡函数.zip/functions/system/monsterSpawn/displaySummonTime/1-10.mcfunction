
function system:monsterSpawn/displaySummonTime/1-5 if @s[score_msp.time_min=1,score_msp.time=5]
function system:monsterSpawn/displaySummonTime/6-10 if @s[score_msp.time_min=6,score_msp.time=10]