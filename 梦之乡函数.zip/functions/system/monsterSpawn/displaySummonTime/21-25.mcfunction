entitydata @s[score_msp.time_min=21,score_msp.time=21] {CustomName:"§f刷怪时间 §e§l21秒"}
entitydata @s[score_msp.time_min=22,score_msp.time=22] {CustomName:"§f刷怪时间 §e§l22秒"}
entitydata @s[score_msp.time_min=23,score_msp.time=23] {CustomName:"§f刷怪时间 §e§l23秒"}
entitydata @s[score_msp.time_min=24,score_msp.time=24] {CustomName:"§f刷怪时间 §e§l24秒"}
entitydata @s[score_msp.time_min=25,score_msp.time=25] {CustomName:"§f刷怪时间 §e§l25秒"}