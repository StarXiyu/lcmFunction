
function system:monsterSpawn/displaySummonTime/11-15 if @s[score_msp.time_min=11,score_msp.time=15]
function system:monsterSpawn/displaySummonTime/16-20 if @s[score_msp.time_min=16,score_msp.time=20]