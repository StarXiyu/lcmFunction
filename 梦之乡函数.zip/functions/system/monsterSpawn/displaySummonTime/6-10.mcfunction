entitydata @s[score_msp.time_min=6,score_msp.time=6] {CustomName:"§f刷怪时间 §e§l6秒"}
entitydata @s[score_msp.time_min=7,score_msp.time=7] {CustomName:"§f刷怪时间 §e§l7秒"}
entitydata @s[score_msp.time_min=8,score_msp.time=8] {CustomName:"§f刷怪时间 §e§l8秒"}
entitydata @s[score_msp.time_min=9,score_msp.time=9] {CustomName:"§f刷怪时间 §e§l9秒"}
entitydata @s[score_msp.time_min=10,score_msp.time=10] {CustomName:"§f刷怪时间 §e§l10秒"}