entitydata @s[score_msp.time_min=11,score_msp.time=11] {CustomName:"§f刷怪时间 §e§l11秒"}
entitydata @s[score_msp.time_min=12,score_msp.time=12] {CustomName:"§f刷怪时间 §e§l12秒"}
entitydata @s[score_msp.time_min=13,score_msp.time=13] {CustomName:"§f刷怪时间 §e§l13秒"}
entitydata @s[score_msp.time_min=14,score_msp.time=14] {CustomName:"§f刷怪时间 §e§l14秒"}
entitydata @s[score_msp.time_min=15,score_msp.time=15] {CustomName:"§f刷怪时间 §e§l15秒"}