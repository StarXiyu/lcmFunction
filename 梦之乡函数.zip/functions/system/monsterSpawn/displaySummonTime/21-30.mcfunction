
function system:monsterSpawn/displaySummonTime/21-25 if @s[score_msp.time_min=21,score_msp.time=25]
function system:monsterSpawn/displaySummonTime/26-30 if @s[score_msp.time_min=26,score_msp.time=30]