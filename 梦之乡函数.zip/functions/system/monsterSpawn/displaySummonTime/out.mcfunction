
entitydata @s {CustomName:"§f刷怪时间 §6周围存在同类怪物"}