entitydata @s[score_msp.time_min=16,score_msp.time=16] {CustomName:"§f刷怪时间 §e§l16秒"}
entitydata @s[score_msp.time_min=17,score_msp.time=17] {CustomName:"§f刷怪时间 §e§l17秒"}
entitydata @s[score_msp.time_min=18,score_msp.time=18] {CustomName:"§f刷怪时间 §e§l18秒"}
entitydata @s[score_msp.time_min=19,score_msp.time=19] {CustomName:"§f刷怪时间 §e§l19秒"}
entitydata @s[score_msp.time_min=20,score_msp.time=20] {CustomName:"§f刷怪时间 §e§l20秒"}