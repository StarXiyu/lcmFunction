
scoreboard players set @a[tag=!getMoney.limit] getMoney.limit 50000
scoreboard players tag @a[tag=!getMoney.limit] add getMoney.limit