scoreboard players tag @s[type=armor_stand] add nk
scoreboard players tag @s[type=villager] add nk
scoreboard players tag @s[type=player] add nk
#scoreboard players tag @s[name=xy] add nk
scoreboard players tag @s[type=item_frame] add nk
#scoreboard players tag @s[type=ender_crystal] add nk
#scoreboard players tag @s[type=ender_dragon] add nk
#scoreboard players tag @s[type=wither] add nk
#scoreboard players tag @s[type=vindication_illager] add nk
#scoreboard players tag @s[type=shulker] add nk
#scoreboard players tag @s[type=elder_guardian] add nk
#scoreboard players tag @s[type=guardian] add nk
#scoreboard players tag @s[type=evocation_illager] add nk

scoreboard players tag @s add system.entity.nktest