
function system:killer/10s if @s[score_killer_min=290,score_killer=290]
function system:killer/3s if @s[score_killer_min=297,score_killer=297]
function system:killer/2s if @s[score_killer_min=298,score_killer=298]
function system:killer/1s if @s[score_killer_min=299,score_killer=299]
function system:killer/kill if @s[score_killer_min=300,score_killer=300]