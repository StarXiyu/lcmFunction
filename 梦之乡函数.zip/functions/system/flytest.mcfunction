
scoreboard players add @s flyTest 1 {FallDistance:0f}

execute @s ~ ~ ~ detect ~ ~-0.5 ~ minecraft:stone_slab * scoreboard players set @s flyTest 0

scoreboard players set @s[score_flySneak_min=1] flyTest 0

scoreboard players set @s flyTest 0 {Inventory:[{Slot:102b,id:"minecraft:elytra"}]}
scoreboard players set @s flyTest 0 {ActiveEffects:[{Id:8b}]}
scoreboard players set @s flyTest 0 {ActiveEffects:[{Id:25b}]}

scoreboard players set @s flySneak 0

function system:flyBan if @s[score_flyTest_min=50]