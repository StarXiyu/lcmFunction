clear @a[x=1089,y=2,z=4454,r=6] minecraft:potion -1 -1 {Tags:["模型"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:dye -1 -1 {Tags:["模型"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:netherbrick -1 -1 {Tags:["模型"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:glowstone_dust -1 -1 {Tags:["模型"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:book -1 -1 {Tags:["模型"]}


clear @a[x=1089,y=2,z=4454,r=6] minecraft:leather_helmet -1 -1 {Tags:["展示"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:leather_chestplate -1 -1 {Tags:["展示"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:leather_leggings -1 -1 {Tags:["展示"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:leather_boots -1 -1 {Tags:["展示"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:skull -1 -1 {Tags:["展示"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:diamond_horse_armor -1 -1 {Tags:["展示"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:golden_horse_armor -1 -1 {Tags:["展示"]}
clear @a[x=1089,y=2,z=4454,r=6] minecraft:iron_horse_armor -1 -1 {Tags:["展示"]}