
scoreboard players add @a[score_sneakCount_min=1] sneakTime 1
scoreboard players set @a[score_sneakTime_min=12] sneakCount 0
scoreboard players set @a[score_sneakTime_min=12] sneakTime 0

function system:menu/tellraw if @p[score_sneakCount_min=2]