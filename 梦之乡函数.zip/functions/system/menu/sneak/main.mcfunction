
scoreboard players set @a[score_menuSneak_min=1] sneak2 2
scoreboard players remove @a[score_menuSneak_min=1] menuSneak 1