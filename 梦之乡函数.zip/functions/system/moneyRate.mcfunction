
scoreboard players set @a[tag=!moneyRate] moneyRate 1
scoreboard players tag @a[tag=!moneyRate] add moneyRate