
scoreboard players set @s math5 0
scoreboard players operation @s math5 = @s getMoney.limit
scoreboard players operation @s math5 -= @s getMoney

scoreboard players enable @s controlReclaim

tellraw @s [{"text":"\n在完成本次兑换后，你将会超过小时获取限额","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"getMoney.limit","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币,你本次应获得","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math1","name":"@s"},"color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币,但你本小时已经获得","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"getMoney","name":"@s"},"color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币,如果你决定继续回收你将会获得","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math5","name":"@s"},"color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币,如若你同意继续回收,请","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"[点击此处]","color":"green","bold":true,"italic":false,"underlined":true,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger controlReclaim set 1"},"hoverEvent":{"action":"show_text","value":"点击此处继续回收"}},{"text":"\n"}]

scoreboard players operation @s conReclaim.money = @s math5