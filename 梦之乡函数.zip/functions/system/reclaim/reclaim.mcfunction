## 原石1 青金石1 煤炭2 铁矿3 金矿4 绿宝石5 钻石6
## 煤炭块9 青金石块9 红石块12 铁块18
## 金块36 绿宝石块45 钻石块54

## 初始化
	scoreboard players set @s reclaim 0
	scoreboard players set @s math1 0
	stats entity @s set AffectedItems @s reclaim
	playsound minecraft:block.note.bell block @s
	
## 提示
	tellraw @s "§6₳一键回收 §8>> §7以下为回收详细内容\n"
	
## 原石
	clear @s cobblestone 0 -1
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"原石","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 青金石
	clear @s dye 4 -1
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"青金石","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 煤炭
	clear @s coal 0 -1
	scoreboard players operation @s reclaim *= 2 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"煤炭","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 铁矿
	clear @s iron_ore 0 -1
	scoreboard players operation @s reclaim *= 3 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"铁矿石","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 金块
	clear @s gold_ore 0 -1
	scoreboard players operation @s reclaim *= 4 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"金矿石","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 绿宝石
	clear @s emerald 0 -1
	scoreboard players operation @s reclaim *= 5 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"绿宝石","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 钻石
	clear @s diamond 0 -1
	scoreboard players operation @s reclaim *= 6 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"钻石","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 煤炭块
	clear @s coal_block 0 -1
	scoreboard players operation @s reclaim *= 9 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"煤炭块","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 青金石块
	clear @s lapis_block 0 -1
	scoreboard players operation @s reclaim *= 9 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"青金石块","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 红石块
	clear @s redstone_block 0 -1
	scoreboard players operation @s reclaim *= 12 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"红石块","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 铁块
	clear @s iron_block 0 -1
	scoreboard players operation @s reclaim *= 18 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"铁块","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 金块
	clear @s gold_block 0 -1
	scoreboard players operation @s reclaim *= 36 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"金块","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 绿宝石块
	clear @s emerald_block 0 -1
	scoreboard players operation @s reclaim *= 45 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"绿宝石块","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## 钻石块
	clear @s diamond_block 0 -1
	scoreboard players operation @s reclaim *= 54 math
	scoreboard players operation @s math1 += @s reclaim
	
	tellraw @s[score_reclaim_min=1] [{"text":" - 本次共计回收","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"钻石块","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"共","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"reclaim","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

## 金币倍率
	scoreboard players operation @s math1 *= @s moneyRate

## 限额
	scoreboard players operation @s money += @s math1
	scoreboard players operation @s getMoney += @s math1
	
## 最终提示
	tellraw @s[score_moneyRate=1] [{"text":"\n§f本次共计回收","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math1","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	tellraw @s[score_moneyRate_min=2] [{"text":"\n§6§l[金币倍率生效中] §f本次共计回收","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math1","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"金币","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	stats entity @s clear AffectedItems