
## 默认倍率
scoreboard players set @s math.element1 130
scoreboard players operation @s math.element2 = @s math.attack3

scoreboard players operation @s math.element2 *= @s math.element1
scoreboard players operation @s math.element2 /= 100 math
scoreboard players operation @s math.attack3 = @s math.element2

execute @e[tag=element.hurt,c=1,r=10] ~ ~ ~ summon minecraft:armor_stand ~-0.4 ~0.3 ~-0.4 {CustomName:"§c§l蒸发",Tags:["element.display"],NoAI:1b,Motion:[0.03,0.65,0.03],Invisible:1,Marker:1,CustomNameVisible:1b}