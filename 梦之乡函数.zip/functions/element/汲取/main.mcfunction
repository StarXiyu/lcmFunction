
## 默认倍率
scoreboard players set @s eleTime.汲取 5
scoreboard players operation @s eleEffect.汲取 = @e[tag=element.hurt,r=10,c=1] maxhealth
scoreboard players set @s eleEffect.汲取1 4

execute @e[tag=element.hurt,c=1,r=10] ~ ~ ~ summon minecraft:armor_stand ~-0.4 ~0.3 ~-0.4 {CustomName:"§4§l汲取",Tags:["element.display"],NoAI:1b,Motion:[0.03,0.65,0.03],Invisible:1,Marker:1,CustomNameVisible:1b}