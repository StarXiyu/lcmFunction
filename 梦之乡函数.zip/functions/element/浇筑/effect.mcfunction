
scoreboard players remove @s eleTime.浇筑 1

scoreboard players operation @s math.element1 = @s maxhealth
scoreboard players operation @s math.element1 *= @s eleEffect.浇筑
scoreboard players operation @s math.element1 /= 100 math
scoreboard players operation @s health -= @s math.element1

execute @s[tag=!monster] ~ ~ ~ kill @s[score_health=0]
execute @s[tag=!monster] ~ ~ ~ function LightRPG:playerDie/init unless @s[score_maxhealth_min=0]
execute @s[tag=!monster] ~ ~ ~ execute @s[score_health=0] ~ ~ ~ scoreboard players operation @s health = @s maxhealth

tellraw @s[tag=!stopMessage.extraEffect] [{"text":"[浇筑] ","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"你损失了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math.element1","name":"@s"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血量","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]