
## element.hurt
## element.attack
## 调用本方法:受伤者

## [01] 蒸发 [水攻击]
execute @s[tag=element.fire] ~ ~ ~ execute @e[tag=element.attack,r=10,c=1] ~ ~ ~ function element:蒸发/attack_water if @s[tag=element.water]

## [02] 蒸发 [火攻击]
execute @s[tag=element.water] ~ ~ ~ execute @e[tag=element.attack,r=10,c=1] ~ ~ ~ function element:蒸发/attack_fire if @s[tag=element.fire]

## [03] 浇筑
execute @s[tag=element.rock] ~ ~ ~ execute @e[tag=element.attack,r=10,c=1] ~ ~ ~ function element:浇筑/main if @s[tag=element.water]

## [04] 凝固
execute @s[tag=element.water] ~ ~ ~ execute @e[tag=element.attack,r=10,c=1] ~ ~ ~ function element:凝固/main if @s[tag=element.rock]

## [05] 萌发
execute @s[tag=element.wood] ~ ~ ~ execute @e[tag=element.attack,r=10,c=1] ~ ~ ~ function element:萌发/main if @s[tag=element.water]

## [06] 汲取
execute @s[tag=element.water] ~ ~ ~ execute @e[tag=element.attack,r=10,c=1] ~ ~ ~ function element:汲取/main if @s[tag=element.wood]

## [07] 燃烧
execute @s[tag=element.wood] ~ ~ ~ execute @e[tag=element.attack,r=10,c=1] ~ ~ ~ function element:燃烧/main if @s[tag=element.fire]

## [08] 碾压
execute @s[tag=element.wood] ~ ~ ~ execute @e[tag=element.attack,r=10,c=1] ~ ~ ~ function element:碾压/main if @s[tag=element.rock]

scoreboard players tag @s remove element.hurt
scoreboard players tag @e[tag=element.attack] remove element.attack