## 调用者 攻击者

scoreboard players set @e[c=1,tag=element.hurt,r=10] eleEffect.碾压1 0
scoreboard players add @e[c=1,tag=element.hurt,r=10] eleEffect.碾压 1
scoreboard players add @e[c=1,tag=element.hurt,r=10,score_eleEffect.碾压_min=4,score_eleEffect.碾压=4] eleEffect.碾压1 40

execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=4,score_eleEffect.碾压=4] ~ ~ ~ scoreboard players operation @s math.element1 = @s health
execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=4,score_eleEffect.碾压=4] ~ ~ ~ scoreboard players operation @s math.element1 *= @s eleEffect.碾压1
execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=4,score_eleEffect.碾压=4] ~ ~ ~ scoreboard players operation @s math.element1 /= 100 math
execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=4,score_eleEffect.碾压=4] ~ ~ ~ scoreboard players operation @s health -= @s math.element1
execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=4,score_eleEffect.碾压=4] ~ ~ ~ tellraw @s[tag=!stopMessage.extraEffect] [{"text":"§8§l[碾压] ","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"你损失了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math.element1","name":"@s"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血量","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=10,score_eleEffect.碾压=10] ~ ~ ~ execute @s[tag=!monster] ~ ~ ~ kill @s
execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=10,score_eleEffect.碾压=10] ~ ~ ~ execute @s[tag=!monster] ~ ~ ~ function LightRPG:playerDie/init unless @s[score_maxhealth_min=0]
execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=10,score_eleEffect.碾压=10] ~ ~ ~ execute @s[tag=!monster] ~ ~ ~ scoreboard players operation @s health = @s maxhealth
execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=10,score_eleEffect.碾压=10] ~ ~ ~ execute @s[tag=!monster] ~ ~ ~ scoreboard players set @s eleEffect.碾压 0

execute @e[c=1,tag=element.hurt,r=10] ~ ~ ~ execute @s[score_eleEffect.碾压_min=10,score_eleEffect.碾压=10] ~ ~ ~ execute @s[tag=monster] ~ ~ ~ scoreboard players set @s health 0

execute @e[tag=element.hurt,c=1,r=10] ~ ~ ~ summon minecraft:armor_stand ~-0.4 ~0.3 ~-0.4 {CustomName:"§8§l碾压",Tags:["element.display"],NoAI:1b,Motion:[0.03,0.65,0.03],Invisible:1,Marker:1,CustomNameVisible:1b}