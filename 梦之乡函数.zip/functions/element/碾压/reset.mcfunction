
scoreboard players set @e[score_eleTime.碾压_min=30] eleEffect.碾压 0
scoreboard players set @e[score_eleTime.碾压_min=30] eleTime.碾压 0