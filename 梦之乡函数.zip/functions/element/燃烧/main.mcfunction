
## 默认倍率
scoreboard players set @e[tag=element.hurt,c=1,r=10] eleTime.燃烧 5
scoreboard players set @e[tag=element.hurt,c=1,r=10] eleEffect.燃烧 5

execute @e[tag=element.hurt,c=1,r=10] ~ ~ ~ summon minecraft:armor_stand ~-0.4 ~0.3 ~-0.4 {CustomName:"§6§l燃烧",Tags:["element.display"],NoAI:1b,Motion:[0.03,0.65,0.03],Invisible:1,Marker:1,CustomNameVisible:1b}