
effect @e[tag=element.hurt,r=10,c=1] minecraft:slowness 3 2

execute @e[tag=element.hurt,c=1,r=10] ~ ~ ~ summon minecraft:armor_stand ~-0.4 ~0.3 ~-0.4 {CustomName:"§7§l凝固",Tags:["element.display"],NoAI:1b,Motion:[0.03,0.65,0.03],Invisible:1,Marker:1,CustomNameVisible:1b}