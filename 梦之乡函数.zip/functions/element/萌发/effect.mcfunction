
scoreboard players remove @s eleTime.萌发 1

scoreboard players operation @s math.element1 = @s maxhealth
scoreboard players operation @s math.element1 *= @s eleEffect.萌发
scoreboard players operation @s math.element1 /= 100 math
scoreboard players operation @s health += @s math.element1

scoreboard players operation @s health < @s maxhealth

tellraw @s[tag=!stopMessage.extraEffect] [{"text":"§a§l[萌发] ","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"你恢复了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math.element1","name":"@s"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血量","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]