scoreboard players operation @p money.test = @p money
scoreboard players operation @p pay.money.test = @p pay.money
scoreboard players operation @p money.test -= @p pay.money.test
function pay:count/mun if @p[score_money.test=-1]
function pay:count/menough if @p[score_money.test_min=0]