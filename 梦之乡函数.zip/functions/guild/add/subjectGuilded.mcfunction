
tellraw @s "§f[§6公会系统§f] §8>> §c该玩家已有公会!"

scoreboard players tag @a[tag=temp.guild.selected] remove temp.guild.selected