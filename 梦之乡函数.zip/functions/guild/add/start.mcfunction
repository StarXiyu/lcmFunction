
## 选中者
execute @a ~ ~ ~ scoreboard players operation @s guild.math = @s uid
scoreboard players operation @a guild.math -= @s guild.select
scoreboard players tag @a[score_guild.math=0,score_guild.math_min=0] add temp.guild.selected

## 选中盔甲架
execute @e[type=armor_stand,tag=guild.armor] ~ ~ ~ scoreboard players operation @s guild.math = @s guild
scoreboard players operation @e[type=armor_stand,tag=guild.armor] guild.math -= @s guild
scoreboard players tag @e[type=armor_stand,tag=guild.armor,score_guild.math=0,score_guild.math_min=0] add temp.guildArmor

## 该玩家已有公会
function guild:add/subjectGuilded if @a[tag=temp.guild.selected,score_guild_min=1]

## 已达到公会人数上限
scoreboard players operation @s guild.math = @e[tag=temp.guildArmor] guild.limit
scoreboard players operation @s guild.math -= @e[tag=temp.guildArmor] guild.number
function guild:add/numberLimit if @s[score_guild.math=0]

## 成功
function guild:add/success if @a[tag=temp.guild.selected]

scoreboard players tag @e[tag=temp.guildArmor] remove temp.guildArmor
scoreboard players tag @a[tag=temp.guild.selected] remove temp.guild.selected