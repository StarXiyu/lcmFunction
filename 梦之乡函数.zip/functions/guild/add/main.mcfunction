
## 判断是否为公会会长
function guild:add/permissionDenied unless @s[tag=guild.admin]

function guild:add/start if @s[tag=guild.admin]