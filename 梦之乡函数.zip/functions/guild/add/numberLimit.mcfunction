
tellraw @s "§f[§6公会系统§f] §8>> §c公会人数已达上限!"

scoreboard players tag @a[tag=temp.guild.selected] remove temp.guild.selected