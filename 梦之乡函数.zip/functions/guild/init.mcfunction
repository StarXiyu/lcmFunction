
scoreboard objectives add guild dummy
scoreboard objectives add guild.level dummy
scoreboard objectives add guild.limit dummy
scoreboard objectives add guild.number dummy
scoreboard objectives add guild.math dummy
scoreboard objectives add guild.select trigger