
tellraw @s "§f[§6公会系统§f] §8>> §c该玩家不是你的公会成员!"

scoreboard players tag @a[tag=temp.guild.selected] remove temp.guild.selected