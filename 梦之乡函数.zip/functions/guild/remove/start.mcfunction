
## 选中者
execute @a[tag=!guild.superAdmin] ~ ~ ~ scoreboard players operation @s guild.math = @s uid
scoreboard players operation @a guild.math -= @s guild.select
scoreboard players tag @a[score_guild.math=0,score_guild.math_min=0] add temp.guild.selected

## 选中盔甲架
execute @e[type=armor_stand,tag=guild.armor] ~ ~ ~ scoreboard players operation @s guild.math = @s guild
scoreboard players operation @e[type=armor_stand,tag=guild.armor] guild.math -= @s guild
scoreboard players tag @e[type=armor_stand,tag=guild.armor,score_guild.math=0,score_guild.math_min=0] add temp.guildArmor

## 该玩家不是你的公会成员
scoreboard players operation @a[tag=temp.guildArmor] guild.math = guild
scoreboard players operation @a[tag=temp.guildArmor] guild.math -= @s guild
function guild:remove/subjectNoGuild unless @a[tag=temp.guild.selected,score_guild.math_min=0,score_guild.math=0]

## 成功
function guild:remove/success if @a[tag=temp.guild.selected]

scoreboard players tag @e[tag=temp.guildArmor] remove temp.guildArmor
scoreboard players tag @a[tag=temp.guild.selected] remove temp.guild.selected