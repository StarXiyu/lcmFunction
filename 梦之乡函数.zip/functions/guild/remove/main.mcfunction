

## 判断是否为公会会长
function guild:remove/permissionDenied unless @s[tag=guild.admin]

function guild:remove/start if @s[tag=guild.admin]