
## 判断是否为公会会长
function guild:update/permissionDenied unless @s[tag=guild.superAdmin]

function guild:update/start if @s[tag=guild.superAdmin]