
function guild:update/fail unless @s[score_money_min=500000]

function guild:update/success if @s[score_money_min=500000]