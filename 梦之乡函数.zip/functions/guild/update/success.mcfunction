
tellraw @s "§f[§6公会系统§f] §8>> §a公会等级升级成功!(到达30人再次升级将不会有效)"

execute @e[type=armor_stand,tag=guild.armor] ~ ~ ~ scoreboard players operation @s guild.math = @s guild
scoreboard players operation @e[type=armor_stand,tag=guild.armor] guild.math -= @s guild
scoreboard players tag @e[type=armor_stand,tag=guild.armor,score_guild.math=0,score_guild.math_min=0] add temp.guildArmor

scoreboard players add @e[tag=temp.guildArmor] guild.limit 5
scoreboard players add @e[tag=temp.guildArmor] guild.level 1

scoreboard players set @e[tag=temp.guildArmor,score_guild.level_min=6] guild.level 6
scoreboard players set @e[tag=temp.guildArmor,score_guild.level_min=6] guild.limit 30

tellraw @s [{"text":"§f[§6公会系统§f] §8>> §7您的公会当前人数限制为 ","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"guild.limit","name":"@e[tag=temp.guildArmor]"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 人","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard players remove @s money 500000

scoreboard players tag @e[tag=temp.guildArmor] remove temp.guildArmor