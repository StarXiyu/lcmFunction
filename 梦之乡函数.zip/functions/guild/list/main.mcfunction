
execute @a ~ ~ ~ scoreboard players operation @a guild.math = @s guild
scoreboard players operation @a guild.math -= @s guild

scoreboard players reset @s guild.math2
scoreboard players tag @s add temp.guild.list
execute @a[score_guild.math=0,score_guild.math_min=0,score_guild_min=1] ~ ~ ~ scoreboard players add @a[tag=temp.guild.list] guild.math2 1
scoreboard players tag @s remove temp.guild.list

tellraw @s [{"text":"公会成员:","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[score_guild.math=0,score_guild.math_min=0,score_guild_min=1]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n共计","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"guild.math2","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"人","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]