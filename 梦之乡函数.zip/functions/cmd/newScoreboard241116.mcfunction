## 计算
scoreboard objectives add math.attack4 dummy

## 每秒恢复
scoreboard objectives add regeneration dummy
scoreboard objectives add a.regeneration dummy
scoreboard objectives add d.regeneration dummy
scoreboard objectives add w.regeneration dummy
scoreboard objectives add n.regeneration dummy
scoreboard objectives add p.regeneration dummy

## 吸血倍率
scoreboard objectives add vampirism.rate dummy
scoreboard objectives add a.vampirism.rate dummy
scoreboard objectives add d.vampirism.rate dummy
scoreboard objectives add w.vampirism.rate dummy
scoreboard objectives add n.vampirism.rate dummy
scoreboard objectives add p.vampirism.rate dummy

## 命中
scoreboard objectives add hit dummy
scoreboard objectives add a.hit dummy
scoreboard objectives add d.hit dummy
scoreboard objectives add w.hit dummy
scoreboard objectives add n.hit dummy
scoreboard objectives add p.hit dummy

## 混乱
scoreboard objectives add slow dummy
scoreboard objectives add a.slow dummy
scoreboard objectives add d.slow dummy
scoreboard objectives add w.slow dummy
scoreboard objectives add n.slow dummy
scoreboard objectives add p.slow dummy

## 破败
scoreboard objectives add break dummy
scoreboard objectives add a.break dummy
scoreboard objectives add d.break dummy
scoreboard objectives add w.break dummy
scoreboard objectives add n.break dummy
scoreboard objectives add p.break dummy

## 巨力
scoreboard objectives add strong dummy
scoreboard objectives add a.strong dummy
scoreboard objectives add d.strong dummy
scoreboard objectives add w.strong dummy
scoreboard objectives add n.strong dummy
scoreboard objectives add p.strong dummy

## 赏金
scoreboard objectives add reward dummy
scoreboard objectives add a.reward dummy
scoreboard objectives add d.reward dummy
scoreboard objectives add w.reward dummy
scoreboard objectives add n.reward dummy
scoreboard objectives add p.reward dummy

scoreboard objectives add rewardPob dummy
scoreboard objectives add a.rewardPob dummy
scoreboard objectives add d.rewardPob dummy
scoreboard objectives add w.rewardPob dummy
scoreboard objectives add n.rewardPob dummy
scoreboard objectives add p.rewardPob dummy