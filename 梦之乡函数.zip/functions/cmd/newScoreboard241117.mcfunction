
scoreboard objectives add break.rate dummy
scoreboard objectives add a.break.rate dummy
scoreboard objectives add p.break.rate dummy
scoreboard objectives add n.break.rate dummy
scoreboard objectives add w.break.rate dummy
scoreboard objectives add d.break.rate dummy

scoreboard objectives add strong.rate dummy
scoreboard objectives add a.strong.rate dummy
scoreboard objectives add p.strong.rate dummy
scoreboard objectives add n.strong.rate dummy
scoreboard objectives add w.strong.rate dummy
scoreboard objectives add d.strong.rate dummy