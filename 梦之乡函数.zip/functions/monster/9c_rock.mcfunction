
scoreboard players set @s spellAttack 240
scoreboard players set @s health 17000
scoreboard players set @s maxhealth 17000
scoreboard players set @s drop 450
scoreboard players set @s spellResist 600
scoreboard players set @s physicsResist 600
scoreboard players set @s msp.number 16

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura