
execute @e[tag=精英守卫] ~ ~ ~ function monster:1c if @s[tag=monster.math]
execute @e[tag=秘境守卫] ~ ~ ~ function monster:1c2 if @s[tag=monster.math]

execute @e[tag=丛林守军] ~ ~ ~ function monster:2c if @s[tag=monster.math]

execute @e[tag=伪装者] ~ ~ ~ function monster:3c if @s[tag=monster.math]

execute @e[tag=异形体] ~ ~ ~ function monster:4c if @s[tag=monster.math]

execute @e[tag=腐尸] ~ ~ ~ function monster:5c if @s[tag=monster.math]

execute @e[tag=蛮荒行者] ~ ~ ~ function monster:6c if @s[tag=monster.math]

execute @e[tag=静法蛛魔] ~ ~ ~ function monster:7c if @s[tag=monster.math]

execute @e[tag=秋风刀] ~ ~ ~ function monster:8c if @s[tag=monster.math]
execute @e[tag=岁月寒] ~ ~ ~ function monster:8c1 if @s[tag=monster.math]

execute @e[tag=原初·火] ~ ~ ~ function monster:9c_fire if @s[tag=monster.math]

execute @e[tag=原初·水] ~ ~ ~ function monster:9c_water if @s[tag=monster.math]

execute @e[tag=原初·木] ~ ~ ~ function monster:9c_wood if @s[tag=monster.math]

execute @e[tag=原初·岩] ~ ~ ~ function monster:9c_rock if @s[tag=monster.math]

execute @e[tag=流浪商人] ~ ~ ~ function monster:10c if @s[tag=monster.math]

## 活动
execute @e[tag=怒火之卫] ~ ~ ~ function monster:怒火之卫 if @s[tag=monster.math]