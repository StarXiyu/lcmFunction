
scoreboard players set @s physicsResist 550
scoreboard players set @s spellResist 400
scoreboard players set @s phyAttack 35
scoreboard players set @s health 280
scoreboard players set @s maxhealth 280
scoreboard players set @s drop 600

scoreboard players set @s msp.number 5

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura

entitydata @s {CustomName:"§c[敌对] §7异形体 §f<Lv.4>"}