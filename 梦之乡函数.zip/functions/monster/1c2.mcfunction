
scoreboard players set @s physicsResist 50
scoreboard players set @s spellResist 50
scoreboard players set @s phyAttack 3
scoreboard players set @s health 25
scoreboard players set @s maxhealth 25
scoreboard players set @s drop 800

scoreboard players set @s msp.number 2

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura

entitydata @s {CustomName:"§c[敌对] §7秘境守卫 §f<Lv.1>"}