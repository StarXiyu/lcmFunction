
scoreboard players set @s physicsResist 80
scoreboard players set @s spellResist 50
scoreboard players set @s phyAttack 10
scoreboard players set @s health 60
scoreboard players set @s maxhealth 60
scoreboard players set @s drop 800

scoreboard players set @s msp.number 3

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura

entitydata @s {CustomName:"§c[敌对] §7丛林守军 §f<Lv.2>"}