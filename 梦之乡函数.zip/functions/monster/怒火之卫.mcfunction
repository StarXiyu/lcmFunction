
scoreboard players set @s phyAttack 6
scoreboard players set @s health 160
scoreboard players set @s maxhealth 160
scoreboard players set @s drop 750
scoreboard players set @s spellResist 100
scoreboard players set @s physicsResist 70

scoreboard players tag @s remove monster.math

scoreboard players set @s msp.number 11

scoreboard players tag @s add enable.killaura

scoreboard players tag @s add monster

entitydata @s {CustomName:"§c[敌对] §7怒火之卫 §f<Lv.4>"}