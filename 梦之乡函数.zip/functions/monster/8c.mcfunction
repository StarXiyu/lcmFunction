
scoreboard players set @s phyAttack 320
scoreboard players set @s physicsPene 400
scoreboard players set @s health 3200
scoreboard players set @s maxhealth 3200
scoreboard players set @s drop 500
scoreboard players set @s spellResist 200
scoreboard players set @s physicsResist 200

scoreboard players tag @s remove monster.math

scoreboard players set @s msp.number 9

scoreboard players tag @s add enable.killaura

scoreboard players tag @s add monster

entitydata @s {CustomName:"§c[敌对] §7秋风刀 §6<Lv.8>"}

scoreboard players set @s min 1
scoreboard players set @s max 1000
function random:main
function system:10c_summon if @s[score_math.out_min=2,score_math.out=2]