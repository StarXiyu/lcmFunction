
scoreboard players set @s spellAttack 480
scoreboard players set @s health 8500
scoreboard players set @s maxhealth 8500
scoreboard players set @s drop 450
scoreboard players set @s spellResist 600
scoreboard players set @s physicsResist 300
scoreboard players set @s msp.number 12

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura