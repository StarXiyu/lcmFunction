
scoreboard players set @s spellAttack 150
scoreboard players set @s health 4000
scoreboard players set @s maxhealth 4000
scoreboard players set @s drop 500

scoreboard players set @s msp.number 8

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura

entitydata @s {CustomName:"§c[敌对] §7静法蛛魔 §6<Lv.7>"}