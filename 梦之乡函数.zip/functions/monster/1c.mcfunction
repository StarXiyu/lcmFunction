
scoreboard players set @s physicsResist 50
scoreboard players set @s spellResist 50
scoreboard players set @s phyAttack 5
scoreboard players set @s health 35
scoreboard players set @s maxhealth 35
scoreboard players set @s drop 800

scoreboard players set @s msp.number 1

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura

entitydata @s {CustomName:"§c[敌对] §7精英守卫 §f<Lv.1>"}