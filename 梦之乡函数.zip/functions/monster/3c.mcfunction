
scoreboard players set @s physicsResist 10
scoreboard players set @s spellResist 50
scoreboard players set @s spellAttack 5
scoreboard players set @s health 120
scoreboard players set @s maxhealth 120
scoreboard players set @s drop 800

scoreboard players set @s msp.number 4

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura

entitydata @s {CustomName:"§c[敌对] §7伪装者 §f<Lv.3>"}