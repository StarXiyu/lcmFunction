
scoreboard players set @s spellAttack 640
scoreboard players set @s health 15750
scoreboard players set @s maxhealth 15750
scoreboard players set @s dodge 25
scoreboard players set @s drop 500
scoreboard players set @s spellResist 500
scoreboard players set @s spellPene 500
scoreboard players set @s physicsResist 300
scoreboard players set @s msp.number 17

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura

tellraw @a [{"text":"[全服公告]","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >> ","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"text":"Lv10.流浪商人","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 出现在了玩家 ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "},{"selector":"@p","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 附近!","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]