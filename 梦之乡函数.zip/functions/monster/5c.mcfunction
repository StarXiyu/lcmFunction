
scoreboard players set @s physicsResist 280
scoreboard players set @s spellResist 150
scoreboard players set @s phyAttack 75
scoreboard players set @s health 800
scoreboard players set @s maxhealth 800
scoreboard players set @s drop 600

scoreboard players set @s msp.number 6

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura


entitydata @s {CustomName:"§c[敌对] §7腐尸 §f<Lv.5>"}