
scoreboard players set @s spellAttack 320
scoreboard players set @s spellPene 400
scoreboard players set @s health 6000
scoreboard players set @s maxhealth 6000
scoreboard players set @s drop 500
scoreboard players set @s spellResist 500
scoreboard players set @s physicsResist 500
scoreboard players set @s dodge 35

scoreboard players tag @s remove monster.math

scoreboard players set @s msp.number 10

scoreboard players tag @s add enable.killaura

scoreboard players tag @s add monster

entitydata @s {CustomName:"§6§lLv8.§f§l岁月寒"}

scoreboard players set @s min 1
scoreboard players set @s max 1000
function random:main
function system:10c_summon if @s[score_math.out_min=2,score_math.out=2]