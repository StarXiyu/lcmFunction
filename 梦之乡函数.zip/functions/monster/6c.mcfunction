
scoreboard players set @s physicsResist 340
scoreboard players set @s spellResist 180
scoreboard players set @s spellAttack 130
scoreboard players set @s health 1200
scoreboard players set @s maxhealth 1200
scoreboard players set @s drop 550

scoreboard players set @s msp.number 7

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura

entitydata @s {CustomName:"§c[敌对] §7蛮荒行者 §6<Lv.6>"}