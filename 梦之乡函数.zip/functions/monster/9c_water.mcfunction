
scoreboard players set @s phyAttack 480
scoreboard players set @s health 8500
scoreboard players set @s maxhealth 8500
scoreboard players set @s drop 450
scoreboard players set @s spellResist 300
scoreboard players set @s physicsResist 600
scoreboard players set @s msp.number 13

scoreboard players tag @s remove monster.math

scoreboard players tag @s add enable.killaura