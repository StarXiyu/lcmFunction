
## 抛异
function sort:exception unless @a[tag=sort.temp.subject,score_sort.hand_min=-2147483648]

scoreboard objectives remove sort.math
scoreboard objectives add sort.math dummy

scoreboard objectives remove sort.math1
scoreboard objectives add sort.math1 dummy

scoreboard objectives remove sort.out
scoreboard objectives add sort.out dummy

## 开始排序
function sort:AscendingOrder/start if @a[tag=sort.temp.subject,score_sort.hand_min=-2147483648]