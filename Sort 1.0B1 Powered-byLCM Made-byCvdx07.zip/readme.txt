
LIGHTCOMMAND MCFUNCTION RELEASE INFROMATION
 - Dev Cvdx07_
 - Release LIGHTCOMMAND
 - QQGroup 228229419
 - Function Sort
 - Version 1.0B1

[0] 欢迎使用 LIGHTCOMMAND-Sort-System 这是一个完全免费的系统
[1] 这是一个完整的函数功能包,如果您不知道函数如何使用,还请学习后再来使用本系统
[2] 本函数可实现对选中的玩家的计分板分数进行升序/降序排序操作
[3] 所谓升序 即 %待比较计分板% 分数最低的玩家在输出结果计分板中的分数最高
[4] 所谓降序 即 %待比较计分板% 分数最高的玩家在输出结果计分板中的分数最高
[5] 比较前操作: 
[ /execute @a ~ ~~ scoreboard players operation @s sort.hand = @s %待比较计分板% ]
[ /scoreboard players tag @a add sort.temp.subject ]
[6] 比较后: %sort.out% 计分板的分数即为排序结果
[7] 升序排序: [ /function sort:AscendingOrder/main ]
[8] 降序排序: [ /function sort:DescendingOrder/main ] 
[9] 安装本系统后只需输入一次: [ /function sort:init ] 进行初始化操作