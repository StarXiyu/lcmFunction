
function system:hpBar/51-63 if @s[score_hpBar.math_min=51,score_hpBar.math=63]
function system:hpBar/64-75 if @s[score_hpBar.math_min=64,score_hpBar.math=75]