
function system:hpBar/1-13 if @s[score_hpBar.math_min=1,score_hpBar.math=13]
function system:hpBar/14-25 if @s[score_hpBar.math_min=14,score_hpBar.math=25]