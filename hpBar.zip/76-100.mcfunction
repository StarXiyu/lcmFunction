

function system:hpBar/76-88 if @s[score_hpBar.math_min=76,score_hpBar.math=88]
function system:hpBar/89-100 if @s[score_hpBar.math_min=89,score_hpBar.math=100]