
function system:hpBar/1-25 if @s[score_hpBar.math_min=1,score_hpBar.math=25]
function system:hpBar/26-50 if @s[score_hpBar.math_min=26,score_hpBar.math=50]