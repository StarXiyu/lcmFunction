import nbtlib

# 加载 scoreboard.dat 文件（确保文件路径正确）
try:
    nbt_file = nbtlib.load("scoreboard.dat")
except FileNotFoundError:
    print("错误：未找到 scoreboard.dat 文件，请检查路径。")
    exit()

# 定位到 Teams 列表（data → Teams）
teams = nbt_file["data"]["Teams"]

# 遍历每个队伍
for team in teams:
    # 获取DisplayName（直接使用标签对象）
    display_name = team["DisplayName"]
    # 检查 DisplayName 是否为 "hpBar.数字" 格式
    if display_name.startswith("hpBar."):
        try:
            # 提取数字部分（如 "hpBar.40" → "40"）
            num_str = display_name.split(".")[1]
            n = int(num_str)
            # 确保数字在 1-100 范围内
            if 1 <= n <= 100:
                # 根据数字范围选择颜色代码（Minecraft 颜色代码）
                if 1 <= n <= 20:
                    color_code = "c"  # 红色
                elif 21 <= n <= 40:
                    color_code = "6"  # 橙色
                elif 41 <= n <= 60:
                    color_code = "e"  # 黄色
                elif 61 <= n <= 80:
                    color_code = "b"  # 浅蓝色
                else:  # 81-100
                    color_code = "a"  # 绿色
                
                # 生成带颜色的 Prefix（格式：§7[§{color}{n}%§7]）
                prefix_str = f"§7[§{color_code}{n}%§7] "
                # 关键修复：使用nbtlib.String包装字符串
                team["Prefix"] = nbtlib.String(prefix_str)
        except (ValueError, IndexError):
            # 若数字提取/转换失败，跳过该队伍
            continue

# 保存修改后的文件
try:
    nbt_file.save("scoreboard_modified.dat")
    print("修改完成！已保存到 scoreboard_modified.dat")
except Exception as e:
    print(f"保存文件时出错：{e}")
