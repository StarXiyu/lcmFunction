
function system:hpBar/26-38 if @s[score_hpBar.math_min=26,score_hpBar.math=38]
function system:hpBar/39-50 if @s[score_hpBar.math_min=39,score_hpBar.math=50]