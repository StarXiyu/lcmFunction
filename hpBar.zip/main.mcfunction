
scoreboard players operation @s hpBar.math = @s health
scoreboard players operation @s hpBar.math *= 100 math
scoreboard players operation @s hpBar.math /= @s maxhealth

function system:hpBar/1-50 if @s[score_hpBar.math_min=1,score_hpBar.math=50]
function system:hpBar/51-100 if @s[score_hpBar.math_min=51,score_hpBar.math=100]