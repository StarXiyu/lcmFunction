
a = 1
while a < 101:
    print(f"scoreboard teams join hpBar.{a} @s[score_hpBar.math={a},score_hpBar.math_min={a}]")
    a+=1