
function system:hpBar/51-75 if @s[score_hpBar.math_min=51,score_hpBar.math=75]
function system:hpBar/76-100 if @s[score_hpBar.math_min=76,score_hpBar.math=100]