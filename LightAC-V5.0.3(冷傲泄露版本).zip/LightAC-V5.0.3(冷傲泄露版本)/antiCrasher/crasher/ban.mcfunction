
## 被动防御策略封禁

scoreboard players tag @a[score_crasherCount_min=2] add tempban.ban
scoreboard players set @a[score_crasherCount_min=2] tempBanU3 1
scoreboard players operation @a[score_crasherCount_min=2] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[score_crasherCount_min=2] tempBanT1 2400

scoreboard players set @a[score_crasherCount_min=2] crasherCount 0