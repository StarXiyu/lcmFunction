
scoreboard players tag @a[score_onlinetime=2400] add tempban.ban
scoreboard players set @a[score_onlinetime=2400] tempBanU3 1
scoreboard players operation @a[score_onlinetime=2400] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[score_onlinetime=2400] tempBanT1 20

tellraw @a "§f[§6LightAC§f] §8>> §c由于本小时内累计卡顿次数过多,LightAC系统已启动峰值保护模式,新人玩家暂时无法正常游玩,感谢您的理解"