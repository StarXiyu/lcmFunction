
function antiCrasher:crasher/limitKick if @p[score_onlinetime=2400]

scoreboard players add @s acLimitTime 1
function antiCrasher:crasher/acLimitTime if @s[score_acLimitTime_min=24000]