
## 未移动的玩家
scoreboard players add @s walk 0

## 比率
scoreboard players operation @s math1 = @s walk
scoreboard players operation @s math1 /= 2000 math
scoreboard players operation @s math2 += @s math1

scoreboard players operation @s math1 = @s killCount
scoreboard players operation @s math1 /= 10 math
scoreboard players operation @s math2 += @s math1

scoreboard players operation @s math1 = @s mineDirt
scoreboard players operation @s math1 /= 15 math
scoreboard players operation @s math2 += @s math1

scoreboard players operation @s math3 = @s onlinetime
scoreboard players operation @s math3 /= @s math2