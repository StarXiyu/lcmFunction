
## 被动防御封禁入口

## 选择可疑对象
execute @a[score_onlinetime=36000,tag=!op] ~ ~ ~ function antiCrasher:crasher/selectSubject

scoreboard players tag @a[score_onlinetime_min=2400,score_walk_min=1,score_onlinetime=36000,tag=!op] add sort.temp.subject
execute @a[tag=sort.temp.subject] ~ ~ ~ scoreboard players operation @s sort.hand = @s math3
function sort:DescendingOrder/main

scoreboard players tag @a[score_sort.out_min=1,score_sort.out=3] add antiCrasher.ban
scoreboard players add @a[tag=antiCrasher.ban] crasherCount 1
scoreboard players tag @a[tag=antiCrasher.ban] remove antiCrasher.ban

## 被动防御:无脑防御类踢人
scoreboard players tag @a[score_onlinetime=2400] add tempban.ban
scoreboard players set @a[score_onlinetime=2400] tempBanU3 1
scoreboard players operation @a[score_onlinetime=2400] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[score_onlinetime=2400] tempBanT1 2400

scoreboard players tag @a[score_walk=0,score_walk_min=0] add tempban.ban
scoreboard players set @a[score_walk=0,score_walk_min=0] tempBanU3 1
scoreboard players operation @a[score_walk=0,score_walk_min=0] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[score_walk=0,score_walk_min=0] tempBanT1 2400

## 被动防御:策略封禁主入口
kill @a[score_crasherCount_min=1,score_crasherCount=1]
function antiCrasher:crasher/ban if @p[score_crasherCount_min=2]

## 记录攻击类延迟
function antiCrasher:log/crasher