
scoreboard players set @s acLimitTime 0
scoreboard players set hourCrasher antiCrasherLog 0