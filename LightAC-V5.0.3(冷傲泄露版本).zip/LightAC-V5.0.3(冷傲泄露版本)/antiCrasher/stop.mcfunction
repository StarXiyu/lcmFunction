
## 主动关闭
tellraw @a "§f[§6LightAC§f] §8>> §eAntiCrasher §f模块已被管理员主动关闭!"
scoreboard players set @s antiCrasherCon 4