
scoreboard players add @s acOnLine 1

## 2分钟-玩家在线清除crasherCount
function antiCrasher:reset/crasherCount if @p[score_acOnLine_min=2400]

## 峰值保护
scoreboard players operation @s hourCrasher = hourCrasher antiCrasherLog
function antiCrasher:crasher/limit if @s[score_hourCrasher_min=2500]

## 清除小时延迟
function antiCrasher:reset/hourCrasher if @s[score_acOnLine_min=72000]