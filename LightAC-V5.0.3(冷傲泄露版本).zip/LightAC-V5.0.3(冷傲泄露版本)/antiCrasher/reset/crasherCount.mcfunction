
## 2分钟
scoreboard players set @a[score_crasherCount_min=1,score_acOnLine_min=2400] crasherCount 0
scoreboard players set @a[score_acOnLine_min=2400] acOnLine 0