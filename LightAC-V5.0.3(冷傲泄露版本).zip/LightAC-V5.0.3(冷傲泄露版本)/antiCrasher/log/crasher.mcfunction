
scoreboard players operation hourCrasher antiCrasherLog += @s antiCrasher