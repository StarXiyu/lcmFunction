
## LightAC 被动防御边界检测
function antiCrasher:start if @s[score_antiCrasher_min=1]
worldborder get
scoreboard players operation @s antiCrasher -= worldborder antiCrasher

## 延迟提示及记录
function antiCrasher:log/normal if @s[score_antiCrasher_min=10]

## LightAC:被动防御启动入口
function antiCrasher:crasher/main if @s[score_antiCrasher_min=50]