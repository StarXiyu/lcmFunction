
## 初始化边界
worldborder set 20000000 0
worldborder center 0 0
worldborder add 6000 300

## worldborder 世界边界
scoreboard players set worldborder antiCrasher 20000000
scoreboard players set @s antiCrasher 0

## 绑定stats
stats entity @s set QueryResult @s antiCrasher