
###########################################
## LightAC-AntiCrasher 5.0.3(LA) Alpha06  #
## 2025.1.22                              #
###########################################

## 禁止泄露 禁止泄露 禁止泄露
## LightAC - Version 5.0.3 LA - Alpha06

## 泄漏了我会跟你急眼的

## 主入口

## 被动检测入口
function antiCrasher:passiveMain if @s[score_antiCrasherCon_min=1,score_antiCrasherCon=1,tag=!antiCrasher.stopPassive]

## 主动检测入口
function antiCrasher:activeMain if @s[score_antiCrasherCon_min=1,score_antiCrasherCon=1,tag=!antiCrasher.stopActive]

## 管理员主动关闭提示
function antiCrasher:stop if @s[score_antiCrasherCon_min=3,score_antiCrasherCon=3]

## execute @e[tag=antiCrasher.armor] ~ ~ ~ function anticrasher:main