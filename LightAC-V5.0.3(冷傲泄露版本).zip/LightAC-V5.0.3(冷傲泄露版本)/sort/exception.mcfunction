
tellraw @a "§f[§6§lSort§f] §8>> §c§l异常: §7请将 §e%待比较计分板%§7 分数赋值至计分板 §e%sort.hand%§7 中!"