
#tellraw @a "§f[§6§lSort§f] §8>> §a§l正常: §e降序 §7排序已完成!"

scoreboard players reset var_B sort.out