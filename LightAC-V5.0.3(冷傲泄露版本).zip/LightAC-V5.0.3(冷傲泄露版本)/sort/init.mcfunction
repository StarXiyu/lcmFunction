
scoreboard objectives add sort.hand dummy
scoreboard objectives add sort.count dummy
summon minecraft:armor_stand ~ ~ ~ {CustomName:"§fsort.armor §e此盔甲架用于调用系统，切勿清除！",Tags:["sort.armor"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}

tellraw @a " "
tellraw @a "§f§l| LIGHTCOMMAND FUNCTION"
tellraw @a "§7 - Thank you for you choosing LIGHTCOMMAND_FUNCTION"
tellraw @a "§7 - Function §e§lSort"
tellraw @a "§7 - Dev §e§lCvdx07_"
tellraw @a "§7 - Version §e§l1.0B1"
tellraw @a " "