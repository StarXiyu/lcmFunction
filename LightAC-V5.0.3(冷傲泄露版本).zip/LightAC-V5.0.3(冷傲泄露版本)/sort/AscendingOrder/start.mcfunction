
## 参与比较的人数
scoreboard players set @e[tag=sort.armor] sort.count 0
execute @a[tag=sort.temp.subject] ~ ~ ~ scoreboard players add @e[tag=sort.armor] sort.count 1

## 比较主体
scoreboard players operation var_A sort.math = @r sort.hand
execute @a[tag=sort.temp.subject] ~ ~ ~ scoreboard players operation var_A sort.math < @s sort.hand
execute @a[tag=sort.temp.subject] ~ ~ ~ scoreboard players operation @s sort.math1 = @s sort.hand
execute @a[tag=sort.temp.subject] ~ ~ ~ scoreboard players operation @s sort.math1 -= var_A sort.math

## 最小值
execute @a[tag=sort.temp.subject] ~ ~ ~ scoreboard players tag @s[score_sort.math1_min=0,score_sort.math1=0] add sort.temp.min

## 最小值玩家执行升序排序
execute @a[tag=sort.temp.min] ~ ~ ~ function sort:AscendingOrder/score

## 结束
function sort:AscendingOrder/end unless @e[tag=sort.armor,score_sort.count_min=1]

## 递归
function sort:AscendingOrder/start if @e[tag=sort.armor,score_sort.count_min=1]