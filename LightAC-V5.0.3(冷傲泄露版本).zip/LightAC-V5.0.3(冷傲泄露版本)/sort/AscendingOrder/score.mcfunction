
scoreboard players add var_B sort.out 1
scoreboard players tag @s remove sort.temp.subject
scoreboard players tag @s remove sort.temp.min

scoreboard players operation @s sort.out = var_B sort.out