
execute @e[tag=antiCrasher.armor] ~ ~ ~ function anticrasher:main
function tempban:main