execute @s ~ ~ ~ detect ~ ~-1 ~ air * scoreboard players add @s lightac.fly.test 5

execute @s[score_lightac.fly.test_min=800] ~ ~ ~ function LightAC:system/fly/warn