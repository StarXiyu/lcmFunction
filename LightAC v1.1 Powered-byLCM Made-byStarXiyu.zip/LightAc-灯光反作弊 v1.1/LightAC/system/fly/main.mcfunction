
scoreboard players tag @s add elytra {Inventory:[{Slot:102b,id:"minecraft:elytra"}]}

function LightAC:system/fly/test unless @s[tag=elytra]

scoreboard players tag @s remove elytra