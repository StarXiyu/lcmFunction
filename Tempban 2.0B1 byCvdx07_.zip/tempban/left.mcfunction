
scoreboard players tag @s remove temp.tempban.select

scoreboard players set @s tempban.left 0