
## 查找对应盔甲架
execute @e[tag=tempban.armor.banTime] ~ ~ ~ scoreboard players operation @s tempbanU2 = @s tempbanU1
scoreboard players operation @e[tag=tempban.armor.banTime] tempbanU2 -= @s uid
scoreboard players tag @e[tag=tempban.armor.banTime,score_tempbanU2=0,score_tempbanU2_min=0] add temp.tempban.bantemp

## 情况1 刑满释放
function tempban:ban/release if @e[tag=temp.tempban.bantemp,score_tempbanT2=0]

## 情况2 继续服刑
function tempban:ban/ban if @e[tag=temp.tempban.bantemp,score_tempbanT2_min=1]