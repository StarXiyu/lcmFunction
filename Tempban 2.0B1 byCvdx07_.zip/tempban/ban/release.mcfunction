
scoreboard players tag @s remove tempban.ban
tellraw @s "§bTempban §7>> §a你已自由,请好好做人"
kill @e[tag=temp.tempban.bantemp]