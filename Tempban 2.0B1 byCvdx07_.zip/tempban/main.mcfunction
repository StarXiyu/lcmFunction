
scoreboard players remove @e[tag=tempban.armor.banTime,type=armor_stand,score_tempbanT2_min=1] tempbanT2 1
execute @p[tag=tempban.ban] ~ ~ ~ function tempban:ban/main

execute @p[score_tempban.time_min=1] ~ ~ ~ function tempban:set/main
scoreboard players enable @a[tag=admin] tempban
execute @p[score_tempban_min=1] ~ ~ ~ function tempban:start

execute @p[score_tempban.left_min=1] ~ ~ ~ function tempban:left

function tempban:time/main if @e[tag=tempban.armor.main,score_tempbanT1_min=1]

scoreboard players add @e[tag=tempban.armor.banTime,type=armor_stand,score_tempbanT2_min=1] tempbanU1 0
kill @e[tag=tempban.armor.banTime,type=armor_stand,score_tempbanT2_min=1,score_tempbanU1_min=0,score_tempbanU1=0]