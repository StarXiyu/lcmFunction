
tellraw @a [{"text":"\nTEMPBAN BAN INFORMATION","color":"white","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n被封禁玩家:","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[tag=temp.tempban.select]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n封禁者:","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n封禁时长:","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"tempban.time","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"ticks","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

summon minecraft:armor_stand ~ ~ ~ {CustomName:"§ftempban.armor.banTime §e临时封禁计时盔甲架",Tags:["tempban.armor.banTime"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,Invisible:1,ShowArms:1,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}

scoreboard players operation @e[tag=tempban.armor.banTime,r=5,c=1] tempbanT2 = @s tempban.time
scoreboard players operation @e[tag=tempban.armor.banTime,r=5,c=1] tempbanU1 = @a[tag=temp.tempban.select] uid
tp @e[tag=tempban.armor.banTime,r=5,c=1] 0 4 0

scoreboard players tag @a[tag=temp.tempban.select] add tempban.ban

function tempban:reset1

tp @e[tag=tempban.armor.banTime] 0 4 0