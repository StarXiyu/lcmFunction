
scoreboard players tag @a remove temp.tempban.select
scoreboard players tag @a remove temp.tempban.op

scoreboard players reset @e[tag=tempban.armor.main] tempbanT1
scoreboard players reset @e[tag=tempban.armor.main] tempban.uid

scoreboard objectives add tempban trigger
scoreboard objectives remove tempban.time

tellraw @a[tag=admin] [{"text":"Tempban ","color":"aqua","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":">> ","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"上一位封禁使用者已经","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"结束使用","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":",现在临时封禁可以","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"正常使用","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]