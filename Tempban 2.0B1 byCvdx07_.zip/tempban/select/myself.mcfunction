
tellraw @s "§bTempban §8>> §f啊啊?你要把自己封了?"

scoreboard players tag @s remove temp.tempban.select