
execute @a ~ ~ ~ scoreboard players operation @s tempban.uid = @s uid
scoreboard players operation @a tempban.uid -= @s tempban
scoreboard players tag @a[score_tempban.uid=0,score_tempban.uid_min=0] add temp.tempban.select

## 未找到对象
function tempban:select/notExist unless @p[tag=temp.tempban.select]

## 选中对象是自己
function tempban:select/myself if @s[tag=temp.tempban.select]

## 成功选中对象
function tempban:select/op if @p[tag=temp.tempban.select]