
scoreboard players tag @s add temp.tempban.select.op

execute @a[tag=op] ~ ~ ~ execute @s[tag=temp.tempban.select] ~ ~ ~ tellraw @a[tag=temp.tempban.select.op] [{"text":"Tempban ","color":"aqua","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":">> ","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"抱歉,您选中的 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[tag=temp.tempban.select]","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 为","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"超级管理员","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":",您无权封禁","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute @a[tag=op] ~ ~ ~ execute @s[tag=temp.tempban.select] ~ ~ ~ scoreboard players tag @s remove temp.tempban.select

scoreboard players tag @s remove temp.tempban.select.op

function tempban:select/success if @p[tag=temp.tempban.select]