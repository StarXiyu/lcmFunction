
scoreboard players remove @e[tag=tempban.armor.main,score_tempbanT1_min=1] tempbanT1 1
function tempban:reset2 if @e[tag=tempban.armor.main,score_tempbanT1=0]