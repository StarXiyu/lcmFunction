
tellraw @s[tag=!admin] "§bTempban §8>> §c抱歉,您没有权限进行临时封禁"

function tempban:select/main if @s[tag=admin]

scoreboard players set @s tempban 0