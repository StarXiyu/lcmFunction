
scoreboard objectives add tempban trigger
scoreboard objectives add tempban.uid dummy

## T1 用于记录玩家协管操作时间
scoreboard objectives add tempbanT1 dummy
## T2 用于记录被封禁玩家剩余封禁时间
scoreboard objectives add tempbanT2 dummy

## U1 用于记录被封禁玩家封禁UID
scoreboard objectives add tempbanU1 dummy
## 计算时储存封禁计时器盔甲架
scoreboard objectives add tempbanU2 dummy

scoreboard objectives add tempban.left stat.leaveGame

summon minecraft:armor_stand ~ ~ ~ {CustomName:"§ftempban.armor.main §e调用函数盔甲架,切勿清除!",Tags:["tempban.armor.main"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,Invisible:1,ShowArms:1,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
