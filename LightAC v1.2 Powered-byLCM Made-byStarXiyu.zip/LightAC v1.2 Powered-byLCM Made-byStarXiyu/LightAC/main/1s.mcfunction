scoreboard players add @e[tag=lightac.time] lightac.time.fly 1
execute @e[tag=lightac.time] ~ ~ ~ function LightAC:system/fly/time if @s[score_lightac.time.fly_min=60]

scoreboard players add @e[tag=lightac.time] lightac.time.kil 1
execute @e[tag=lightac.time] ~ ~ ~ function LightAC:system/killaura/time if @s[score_lightac.time.fly_min=10]
