scoreboard players set @s main 0

scoreboard players enable @a l*****
execute @a[tag=!whitelist] ~ ~ ~ function LightAC:system/ore/main
execute @a[score_l*****=10291,score_l*****_min=10291] ~ ~ ~ function LightAC:system/killaura/db

scoreboard players add @e[tag=lightac.time] lightac.time.ore 1
execute @e[tag=lightac.time] ~ ~ ~ function LightAC:system/killaura/time if @s[score_lightac.time.ore_min=360]