scoreboard players set @s main 0

scoreboard players tag @a[tag=op] add lightac.whitelist