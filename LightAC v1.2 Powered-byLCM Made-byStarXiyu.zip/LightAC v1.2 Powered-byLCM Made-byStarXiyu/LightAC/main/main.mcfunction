scoreboard players add @e[tag=5tick,type=armor_stand] main 1

execute @e[tag=5tick] ~ ~ ~ function LightAC:main/5tick if @s[score_main_min=5,score_main=10]

execute @a[score_lightac.warn_min=10] ~ ~ ~ function LightAC:system/ban1
execute @a[tag=lightac.ban] ~ ~ ~ function LightAC:system/ban

execute @a[tag=!lcm.nam] ~ ~ ~ function LightAC:system/nickname/main