scoreboard players set @a lightac.fly.test 0
scoreboard players set @s lightac.time.fly 0