
scoreboard players tag @s add LightAC.flyTest.Test {FallDistance:0f}

execute @s[tag=LightAC.flyTest.Test] ~ ~ ~ detect ~ ~-2 ~ air * scoreboard players add @s lightac.fly.test 5

execute @s[score_lightac.fly.test_min=800] ~ ~ ~ function LightAC:system/fly/warn

scoreboard players tag @s remove LightAC.flyTest.Test