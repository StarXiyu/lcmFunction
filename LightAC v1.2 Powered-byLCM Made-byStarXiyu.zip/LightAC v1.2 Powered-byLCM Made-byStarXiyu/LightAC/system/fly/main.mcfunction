
scoreboard players tag @s add LightAC.flyTest.tempWhite {Inventory:[{Slot:102b,id:"minecraft:elytra"}]}
execute @s ~ ~ ~ detect ~ ~ ~ ladder * scoreboard players tag @s add LightAC.flyTest.tempWhite
execute @s ~ ~ ~ detect ~ ~ ~ vine * scoreboard players tag @s add LightAC.flyTest.tempWhite

function LightAC:system/fly/test unless @s[tag=LightAC.flyTest.tempWhite]

scoreboard players tag @s remove LightAC.flyTest.tempWhite