scoreboard players set @a lightac.diamond 0
scoreboard players set @a lightac.mine 0
scoreboard players set @s lightac.time.ore 0