scoreboard players operation @s lightac.killaura += @s lightac.use.铁
scoreboard players set @s lightac.use.铁 0