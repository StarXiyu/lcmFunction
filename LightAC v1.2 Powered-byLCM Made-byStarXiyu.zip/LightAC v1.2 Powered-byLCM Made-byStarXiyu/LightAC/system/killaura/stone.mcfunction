scoreboard players operation @s lightac.killaura += @s lightac.use.石
scoreboard players set @s lightac.use.石 0