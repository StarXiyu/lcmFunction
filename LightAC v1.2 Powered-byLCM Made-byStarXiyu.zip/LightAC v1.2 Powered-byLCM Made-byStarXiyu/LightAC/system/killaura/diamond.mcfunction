scoreboard players operation @s lightac.killaura += @s lightac.use.钻
scoreboard players set @s lightac.use.钻 0