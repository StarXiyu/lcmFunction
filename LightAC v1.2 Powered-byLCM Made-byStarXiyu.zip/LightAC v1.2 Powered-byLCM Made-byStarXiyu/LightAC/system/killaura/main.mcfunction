function LightAC:system/killaura/score

function LightAC:system/killaura/warn if @s[score_lightac.killaura_min=80]