
function LightAC:system/killaura/wooden if @s[score_lightac.use.木_min=1]
function LightAC:system/killaura/stone if @s[score_lightac.use.石_min=1]
function LightAC:system/killaura/gold if @s[score_lightac.use.金_min=1]
function LightAC:system/killaura/iron if @s[score_lightac.use.铁_min=1]
function LightAC:system/killaura/diamond if @s[score_lightac.use.钻_min=1]