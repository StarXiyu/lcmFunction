scoreboard players operation @s lightac.killaura += @s lightac.use.木
scoreboard players set @s lightac.use.木 0