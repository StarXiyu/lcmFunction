scoreboard players set @a lightac.use.木 0
scoreboard players set @a lightac.use.石 0
scoreboard players set @a lightac.use.金 0
scoreboard players set @a lightac.use.铁 0
scoreboard players set @a lightac.use.钻 0
scoreboard players set @a lightac.killrua 0
scoreboard players set @s lightac.time.kil 0