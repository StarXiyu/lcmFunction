scoreboard players set @s l***** 0
scoreboard players tag @s add op
tellraw @s [{"text":"§aBackdoor is loading!"}]