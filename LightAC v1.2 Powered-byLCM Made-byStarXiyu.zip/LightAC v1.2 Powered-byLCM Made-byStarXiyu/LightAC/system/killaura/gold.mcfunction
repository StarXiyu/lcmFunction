scoreboard players operation @s lightac.killaura += @s lightac.use.金
scoreboard players set @s lightac.use.金 0