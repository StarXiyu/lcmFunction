scoreboard players add @s lcm.name 0
scoreboard players tag @s[tag=!lcm.name,score_lcm.name_min=0,score_lcm.name=0] add lcm.name
scoreboard players set @s[tag=lcm.name] lcm.name 1
scoreboard players tag @s[tag=!lcm.name] add lightac.ban