
function LightOS:main

## [04] 增加服务器刻
	scoreboard players add systemTick tempBanT1 1
	
## [00] 重置管理员的临时封禁
	scoreboard players set @a[tag=op,score_tempBanT1_min=1] tempBanT1 0
	
## [01] 检测是否有已被封禁的玩家登录
	execute @a[tag=tempban.ban] ~ ~ ~ function tempban:ban/main
