
##############################################
## LightOS-AntiCrasher 1.3.1(ZX22) Alpha01   #
## 2025.6.20                                 #
##############################################

## [01] 边界检测
execute @e[tag=antiCrasher.armor] ~ ~ ~ function LightOS:worldborder/main

## [02] 北京时间系统
execute @e[tag=antiCrasher.armor] ~ ~ ~ function LightOS:date/main

## [03] 反崩服系统
execute @e[tag=antiCrasher.armor] ~ ~ ~ function LightOS:anticrasher/main