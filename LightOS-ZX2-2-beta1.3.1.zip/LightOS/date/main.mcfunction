
execute @s[score_antiCrasher=2] ~ ~ ~ scoreboard players add @s los.tick 1
scoreboard players operation @s[score_antiCrasher_min=3] los.tick += @s[score_antiCrasher_min=3] antiCrasher

function LightOS:date/second if @s[score_los.tick_min=20]