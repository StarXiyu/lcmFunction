
scoreboard players add @s los.hour 1
scoreboard players remove @s[tag=!LightOS.temp.24hCorrect] los.minute 60

tellraw @a " "
tellraw @a [{"text":"[LightOS]","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 整点报时 ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"los.hour","name":"@s"},"color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":":00:00","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
tellraw @a " "

function LightOS:date/day if @s[score_los.hour_min=24]