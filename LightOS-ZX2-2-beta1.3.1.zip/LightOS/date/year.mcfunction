
scoreboard players add @s los.year 1
scoreboard players remove @s los.month 12