
scoreboard players add @s los.minute 1
scoreboard players remove @s los.second 60

function LightOS:date/hour if @s[score_los.minute_min=60]