
scoreboard players reset normal antiCrasherLog
scoreboard players reset crasher antiCrasherLog
scoreboard players reset crasherCount antiCrasherLog

scoreboard players set @e[tag=antiCrasher.armor] los.tick 0
scoreboard players set @e[tag=antiCrasher.armor] los.minute 59
scoreboard players set @e[tag=antiCrasher.armor] los.second 59
scoreboard players set @e[tag=antiCrasher.armor] los.hour 23