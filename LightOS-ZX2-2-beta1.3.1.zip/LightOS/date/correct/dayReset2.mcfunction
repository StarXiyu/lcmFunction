
scoreboard players set * lac.dayReset 1

## 服务器类每日重置
scoreboard players reset * qd