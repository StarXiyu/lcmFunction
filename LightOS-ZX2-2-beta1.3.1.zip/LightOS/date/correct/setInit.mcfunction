
scoreboard players set @e[tag=antiCrasher.armor] los.year 2025
scoreboard players set @e[tag=antiCrasher.armor] los.month 4
scoreboard players set @e[tag=antiCrasher.armor] los.day 6
scoreboard players set @e[tag=antiCrasher.armor] los.hour 11

# scoreboard players set @e[tag=antiCrasher.armor] los.tick 0