
scoreboard players add @s los.month 1
scoreboard players set @s los.day 1

## 年进位
function LightOS:date/year if @s[score_los.month_min=12]