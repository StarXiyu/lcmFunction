
scoreboard players add @s los.second 1
scoreboard players remove @s los.tick 20

function LightOS:date/minute if @s[score_los.second_min=60]