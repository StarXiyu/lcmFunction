
scoreboard players add @s los.day 1
scoreboard players remove @s los.hour 24

## 月进位判断 [需人工校准,默认31]
function LightOS:date/month if @s[score_los.day_min=31]

scoreboard players tag @s remove LightOS.temp.24hCorrect