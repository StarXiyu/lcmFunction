
scoreboard players add @s acOnLine 1

## 入服设活跃值10
function LightOS:antiCrasher/playerInit if @p[tag=!los.activeNumberInit]

## 活跃值检测-离线重置
execute @a[score_los.leave_min=1,tag=los.activeNumberInit] ~ ~ ~ function LightOS:antiCrasher/ACJudge_leave

## 1分钟-玩家在线清除crasherCount
function LightOS:anticrasher/reset/crasherCount if @p[score_acOnLine_min=1200]

## 峰值保护
scoreboard players operation @s hourCrasher = hourCrasher antiCrasherLog
function LightOS:anticrasher/crasher/limit if @s[score_hourCrasher_min=2600]

## 清除小时延迟
function LightOS:anticrasher/reset/hourCrasher if @s[score_acOnLine_min=72000]

## 10秒-被动防御小流量发包自动清理
function LightOS:anticrasher/reset/smallPacket if @s[tag=smallPacket]

## AFK检测
#//function LightOS:anticrasher/AFK/main

## 宣传推广成就
function LightOS:antiCrasher/advertisement if @a[tag=!lac.adver]