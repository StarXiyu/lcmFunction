
advancement grant @a[tag=!lac.adver] only 灯光框架:宣传推广
scoreboard players tag @a[tag=!lac.adver] add lac.adver