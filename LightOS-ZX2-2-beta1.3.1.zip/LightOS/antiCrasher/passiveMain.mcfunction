
## 延迟提示及记录
function LightOS:anticrasher/log/normal if @s[score_antiCrasher_min=10]

## LightAC:间接性被动防御入口
function LightOS:anticrasher/crasher/smallPacket if @s[score_antiCrasher_min=5,score_antiCrasher=49]

## LightAC:直接性被动防御启动入口
function LightOS:anticrasher/crasher/main if @s[score_antiCrasher_min=50]