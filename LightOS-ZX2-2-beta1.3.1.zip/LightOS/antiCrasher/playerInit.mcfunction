
scoreboard players set @a[tag=!los.activeNumberInit] lac.activeNumber 10
scoreboard players tag @a[tag=!los.activeNumberInit] add los.activeNumberInit