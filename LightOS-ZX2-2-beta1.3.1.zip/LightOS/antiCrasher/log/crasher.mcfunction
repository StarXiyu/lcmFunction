
scoreboard players operation hourCrasher antiCrasherLog += @s antiCrasher
scoreboard players operation crasher antiCrasherLog += @s antiCrasher
scoreboard players add crasherCount antiCrasherLog 1

scoreboard players operation normal antiCrasherLog -= @s antiCrasher