
scoreboard players set hourCrasher antiCrasherLog 0
scoreboard players set @s acOnLine 0
scoreboard players set @s acLimitTime 0
scoreboard players set @s hourCrasher 0