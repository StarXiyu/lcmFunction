
scoreboard players add @s smallPacketTime 1

scoreboard players set @s[score_smallPacketTime_min=200] smallPacket 0
scoreboard players tag @s[score_smallPacketTime_min=200] remove smallPacket
scoreboard players set @s[score_smallPacketTime_min=200] smallPacketTime 0