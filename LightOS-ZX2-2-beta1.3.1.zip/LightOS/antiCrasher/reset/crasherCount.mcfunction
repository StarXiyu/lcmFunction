
## 1分钟
scoreboard players set @a[score_crasherCount_min=1,score_acOnLine_min=1200] crasherCount 0
scoreboard players set @a[score_acOnLine_min=1200] acOnLine 0