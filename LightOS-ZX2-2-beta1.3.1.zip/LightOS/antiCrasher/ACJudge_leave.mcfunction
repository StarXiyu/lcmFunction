
## 策略判定
function LightOS:antiCrasher/crasher/selectSubject

## 判定后的白名单
    
    # 游戏时长 > 48h 免检
    scoreboard players tag @s[score_onlinetime_min=3456000,tag=!los.ACwhitelist] add los.ACwhitelist
    
    # 达到0 立刻免检
    scoreboard players tag @s[score_lac.activeNumber=0,tag=!los.ACwhitelist] add los.ACwhitelist

    # 每次达到5分 免检分+1 免检分加到2免检
    scoreboard players add @s[score_lac.activeNumber=5,score_lac.activeNumber_min=5,tag=!los.ACwhitelist] lac.acWhiteCount 1
    scoreboard players set @s[score_lac.activeNumber=5,score_lac.activeNumber_min=5,tag=!los.ACwhitelist] lac.activeNumber 4
    scoreboard players tag @s[score_lac.acWhiteCount_min=2,tag=!los.ACwhitelist] add los.ACwhitelist

scoreboard players set @s los.leave 0

## 重置每日活跃值
execute @s[score_lac.dayReset_min=1,tag=!los.ACwhitelist] ~ ~ ~ function LightOS:antiCrasher/ACJudge_setActiveNumber