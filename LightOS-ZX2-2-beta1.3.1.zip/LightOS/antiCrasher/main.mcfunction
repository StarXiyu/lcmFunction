
## 主入口

## 被动检测入口
function LightOS:anticrasher/passiveMain if @s[score_antiCrasherCon_min=1,score_antiCrasherCon=1,tag=!antiCrasher.stopPassive]

## 主动检测入口
function LightOS:anticrasher/activeMain if @s[score_antiCrasherCon_min=1,score_antiCrasherCon=1,tag=!antiCrasher.stopActive]

## 管理员主动关闭提示
function LightOS:anticrasher/stop if @s[score_antiCrasherCon_min=3,score_antiCrasherCon=3]

## execute @e[tag=antiCrasher.armor] ~ ~ ~ function LightOS:anticrasher/main