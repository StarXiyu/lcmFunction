
## 设定数值
scoreboard players set 60 math 60
scoreboard players set 100 math 100
scoreboard players set 70000 math 70000

## 打怪 100 个 -1
scoreboard players set @s math1 0
scoreboard players operation @s math1 = @s ac.killCount
scoreboard players operation @s math1 /= 100 math
scoreboard players operation @s lac.activeNumber -= @s math1
scoreboard players operation @s math1 *= 100 math
scoreboard players operation @s ac.killCount -= @s math1

## 移动 70000 距离 -1
scoreboard players set @s math1 0
scoreboard players operation @s math1 = @s ac.walk
scoreboard players operation @s math1 /= 70000 math
scoreboard players operation @s lac.activeNumber -= @s math1
scoreboard players operation @s math1 *= 70000 math
scoreboard players operation @s ac.walk -= @s math1

## 和村民对话 60 次 -1
scoreboard players set @s math1 0
scoreboard players operation @s math1 = @s ac.villagerTalk
scoreboard players operation @s math1 /= 60 math
scoreboard players operation @s lac.activeNumber -= @s math1
scoreboard players operation @s math1 *= 60 math
scoreboard players operation @s ac.villagerTalk -= @s math1