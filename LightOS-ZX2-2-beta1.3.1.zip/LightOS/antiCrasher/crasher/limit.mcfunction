
function LightOS:anticrasher/crasher/limitKick if @p[score_onlinetime=2400]

scoreboard players add @s acLimitTime 1
function LightOS:anticrasher/crasher/acLimitTime if @s[score_acLimitTime_min=24000]