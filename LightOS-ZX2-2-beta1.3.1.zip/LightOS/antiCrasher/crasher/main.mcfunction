
## 被动防御封禁入口

##// 被动防御:AFK策略1
##//execute @a[score_onlinetime=72000,score_lac.AFKLog_min=8400,tag=!op] ~ ~ ~ scoreboard players operation @s onlinetime -= @s lac.AFKLog

## OP检测白名单
scoreboard players tag @a[tag=op] add los.ACwhitelist

## 选择可疑对象
execute @a[score_onlinetime_min=2400,tag=!los.ACwhitelist] ~ ~ ~ function LightOS:antiCrasher/crasher/selectSubject

## 选择可疑对象后的白名单
    
    # 游戏时长 > 48h 免检
    scoreboard players tag @a[score_onlinetime_min=3456000,tag=!los.ACwhitelist] add los.ACwhitelist
    
    # 达到0 立刻免检
    scoreboard players tag @a[score_lac.activeNumber=0,tag=!los.ACwhitelist] add los.ACwhitelist

    # 每次达到5分 免检分+1 免检分加到2免检
    scoreboard players add @a[score_lac.activeNumber=5,score_lac.activeNumber_min=5,tag=!los.ACwhitelist] lac.acWhiteCount 1
    scoreboard players set @a[score_lac.activeNumber=5,score_lac.activeNumber_min=5,tag=!los.ACwhitelist] lac.activeNumber 4
    scoreboard players tag @a[score_lac.acWhiteCount_min=2,tag=!los.ACwhitelist] add los.ACwhitelist

scoreboard players tag @a[score_lac.activeNumber_min=8,tag=!los.ACwhitelist] add antiCrasher.ban
scoreboard players add @a[tag=antiCrasher.ban] crasherCount 1
scoreboard players tag @a[tag=antiCrasher.ban] remove antiCrasher.ban

## 被动防御:无脑防御类踢人
scoreboard players tag @a[score_onlinetime=2400,tag=!los.ACwhitelist] add tempban.ban
scoreboard players set @a[score_onlinetime=2400,tag=!los.ACwhitelist] tempBanU3 1
scoreboard players operation @a[score_onlinetime=2400,tag=!los.ACwhitelist] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[score_onlinetime=2400,tag=!los.ACwhitelist] tempBanT1 2400

scoreboard players tag @a[score_walk=15000,tag=!los.ACwhitelist] add tempban.ban
scoreboard players set @a[score_walk=15000,tag=!los.ACwhitelist] tempBanU3 1
scoreboard players operation @a[score_walk=15000,tag=!los.ACwhitelist] tempBanT1 = systemTick tempBanT1
scoreboard players add @a[score_walk=15000,tag=!los.ACwhitelist] tempBanT1 2400

##// 被动防御:策略AFK入口
##//scoreboard players add @a[score_onlinetime=144000,score_lac.AFKLog_min=12000,tag=temp.AFK] crasherCount 1

## 被动防御:策略封禁主入口
kill @a[score_crasherCount_min=1,score_crasherCount=1]
function LightOS:antiCrasher/crasher/ban if @p[score_crasherCount_min=2]

## 记录攻击类延迟
function LightOS:antiCrasher/log/crasher