
#//execute @a[score_lac.AFKTime_min=1200,tag=!temp.AFK] ~ ~ ~ tellraw @a [{"text":"[AFK] ","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 正在挂机!","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard players tag @a[score_lac.AFKTime_min=1200,tag=!temp.AFK] add temp.AFK