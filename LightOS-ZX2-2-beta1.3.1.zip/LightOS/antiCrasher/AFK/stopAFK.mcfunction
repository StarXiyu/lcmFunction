
#//execute @a[score_lac.walkTest_min=1,tag=temp.AFK] ~ ~ ~ tellraw @a [{"text":"[AFK] ","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 回到了游戏!","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

execute @a[score_lac.walkTest_min=1,tag=temp.AFK] ~ ~ ~ scoreboard players operation @s lac.AFKLog += @s lac.AFKTime

scoreboard players tag @a[score_lac.walkTest_min=1,tag=temp.AFK] remove temp.AFK