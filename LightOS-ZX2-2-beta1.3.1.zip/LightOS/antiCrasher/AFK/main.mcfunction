
scoreboard players add @a lac.AFKTime 1

function LightOS:antiCrasher/AFK/nowAFK if @p[score_lac.AFKTime_min=1200,tag=!temp.AFK]
function LightOS:antiCrasher/AFK/stopAFK if @p[score_lac.walkTest_min=1,tag=temp.AFK]

function LightOS:antiCrasher/AFK/resetAFK if @p[score_lac.AFKTime_min=1]