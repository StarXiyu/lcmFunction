
scoreboard players reset @a[score_lac.walkTest_min=1] lac.AFKTime
scoreboard players reset @a[score_AFK.mineLog_min=1] lac.AFKTime

scoreboard players reset @a[score_lac.walkTest_min=1] lac.walkTest
scoreboard players reset @a[score_AFK.mineLog_min=1] AFK.mineLog