
scoreboard players set @s lac.activeNumber 10
scoreboard players reset @s lac.dayReset