
## LightOS 边界检测
function LightOS:anticrasher/start if @s[score_antiCrasher_min=1]
worldborder get
scoreboard players operation @s antiCrasher -= worldborder antiCrasher