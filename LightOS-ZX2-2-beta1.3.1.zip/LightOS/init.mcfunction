
scoreboard objectives remove antiCrasher
scoreboard objectives add antiCrasher dummy
scoreboard objectives add crasherCount dummy
scoreboard objectives add hourCrasher dummy
scoreboard objectives add antiCrasherCon dummy
scoreboard objectives add antiCrasherLog dummy
scoreboard objectives add acOnLine stat.playOneMinute
scoreboard objectives add acLimitTime dummy
scoreboard objectives add smallPacket dummy
scoreboard objectives add smallPacketTime dummy
##//scoreboard objectives add lac.walkTest stat.walkOneCm
##//scoreboard objectives add lac.AFKTime dummy
##//scoreboard objectives add lac.AFKLog dummy

scoreboard objectives add lac.activeNumber dummy
scoreboard objectives add lac.acWhiteCount dummy
scoreboard objectives add lac.dayReset dummy

# 年月日 时分秒 刻
scoreboard objectives add los.tick dummy
scoreboard objectives add los.second dummy
scoreboard objectives add los.minute dummy
scoreboard objectives add los.hour dummy
scoreboard objectives add los.day dummy
scoreboard objectives add los.month dummy
scoreboard objectives add los.year dummy

scoreboard objectives add los.leave stat.leaveGame

summon minecraft:armor_stand ~ ~1 ~ {CustomName:"§fantiCrasher.armor §e此盔甲架用于反崩，切勿清除！",Tags:["antiCrasher.armor"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,DisabledSlots:2039583,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}

## execute @e[tag=antiCrasher.armor] ~ ~ ~ /function LightOS:anticrasher/start