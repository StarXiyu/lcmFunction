
function gather:condition/acceptOrDeny_targetNotOnline unless @a[tag=temp.gather.nowApplying]
function gather:condition/acceptOrDeny_targetOnline if @a[tag=temp.gather.nowApplying]