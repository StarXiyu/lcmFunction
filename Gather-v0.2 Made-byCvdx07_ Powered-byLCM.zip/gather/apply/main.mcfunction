
## 调用者:申请者
function gather:apply/messageToApplicant if @s[tag=!temp.gather.mta]
function gather:applt/messageToStarter if @a[tag=temp.gather.starter,score_gather.deal_min=0,score_gather.deal=0]