
tellraw @s "§d『召唤』 §a申请发送成功"
scoreboard players tag @s add temp.gather.mta