
tellraw @s "§d『召唤』 §f该玩家不在线，已为您跳过并按照顺序继续推送申请"

scoreboard players set @s gather.deal 0
scoreboard players set @s gather.ad 0