## 攻击动画
	particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a[r=10] 152
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 2 1

## 玩家伤害运算
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ function LightRPG:system/pvp/playerAttack

## 物理属性
	function LightRPG:system/pvp/physics if @p[tag=LightRPG.temp.pvp.attackPlayer,score_phyAttack_min=1,r=10]

## 法术属性
	function LightRPG:system/pvp/spell if @p[tag=LightRPG.temp.pvp.attackPlayer,score_spellAttack_min=1,r=10]

## 闪避
	function LightRPG:system/pvp/dodge if @s[score_dodge_min=1]
	
## 攻击总数
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ scoreboard players set @s math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack1
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack2

## 暴击运算
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,score_critPob_min=1,r=10] ~ ~ ~ function LightRPG:system/pvp/crit
	
## 怪物生命
	execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ scoreboard players set @s[score_math.attack3=-1] math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ scoreboard players operation @s health -= @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] math.attack3

## 吸血
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ function LightRPG:system/pvp/vampirism if @s[score_vampirism_min=1]
	
## 攻击提示
	scoreboard players set @s[score_health=-1] health 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ title @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"⚔","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] ~ ~ ~ title @s[tag=LightRPG.temp.crit] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"☣","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ title @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] subtitle [{"score":{"objective":"math.attack3","name":"@p[tag=LightRPG.temp.pvp.attackPlayer,r=10]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" / ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=LightRPG.temp.dodge] ~ ~ ~ tellraw @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] [{"selector":"@p[tag=LightRPG.temp.pvp.hurtPlayer,r=10]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 闪避","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"了您的攻击","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

## 受伤提示
	tellraw @s[tag=LightRPG.temp.dodge] [{"text":"您","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"闪避","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@p[tag=LightRPG.temp.pvp.attackPlayer,r=10]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 的攻击","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "}]
	tellraw @s[tag=!LightRPG.temp.dodge] [{"text":"您损失了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math.attack3","name":"@p[tag=LightRPG.temp.pvp.attackPlayer,r=10]"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "}]
	
## 怪物死亡
	function LightRPG:playerDie/main if @s[score_health=0]
	
## 删除标签
	scoreboard players tag @a[tag=LightRPG.temp.pvp.attackPlayer] remove LightRPG.temp.crit
	scoreboard players reset @a[tag=LightRPG.temp.pvp.attackPlayer] MCdamage
	scoreboard players reset @a[tag=LightRPG.temp.pvp.hurtPlayer] MCdamage
	scoreboard players tag @a[tag=LightRPG.temp.pvp.attackPlayer] remove LightRPG.temp.pvp.attackPlayer
	scoreboard players tag @s remove LightRPG.temp.pvp.hurtPlayer
	scoreboard players tag @s remove LightRPG.temp.dodge