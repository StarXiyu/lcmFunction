
scoreboard players set @s min 1
scoreboard players set @s max 100
function LightRPG:system/random/main
scoreboard players operation @s math.out += @p[tag=LightRPG.temp.pvp.attackPlayer,r=10] hit

scoreboard players operation @s math.out -= @s dodge
execute @s[score_math.out=0] ~ ~ ~ scoreboard players tag @s add LightRPG.temp.dodge