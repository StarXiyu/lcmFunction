## 攻击动画
	particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a[r=10] 152
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 2 1

## 玩家伤害运算
	execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/playerAttack

## 物理属性
	function LightRPG:system/monsterHurt/physics if @p[tag=LightRPG.temp.attackMonster,score_phyAttack_min=1,r=10]

## 法术属性
	function LightRPG:system/monsterHurt/spell if @p[tag=LightRPG.temp.attackMonster,score_spellAttack_min=1,r=10]

## 闪避
	function LightRPG:system/monsterHurt/dodge if @s[score_dodge_min=1]
	
## 攻击总数
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players set @s math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack1
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack2

## 暴击运算
	execute @p[tag=LightRPG.temp.attackMonster,score_critPob_min=1,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/crit
	
## 怪物生命
	execute @p[tag=LightRPG.temp.attackMonster,r=10,r=10] ~ ~ ~ scoreboard players set @s[score_math.attack3=-1] math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ scoreboard players operation @s health -= @p[tag=LightRPG.temp.attackMonster,r=10] math.attack3

## 吸血
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ function LightRPG:system/monsterHurt/vampirism if @s[score_vampirism_min=1]
	
## 攻击提示
	scoreboard players set @s[score_health=-1] health 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ title @p[tag=LightRPG.temp.attackMonster,r=10] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"⚔","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @p[tag=LightRPG.temp.attackMonster,r=10] ~ ~ ~ title @s[tag=LightRPG.temp.crit] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"☣","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ title @p[tag=LightRPG.temp.attackMonster,r=10] subtitle [{"score":{"objective":"math.attack3","name":"@p[tag=LightRPG.temp.attackMonster,r=10]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" / ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @s[tag=LightRPG.temp.dodge] ~ ~ ~ tellraw @p[tag=LightRPG.temp.attackMonster,r=10] [{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 闪避","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"了您的攻击","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

## 怪物死亡
	function LightRPG:monsterDie/main if @s[score_health=0]
	
## 删除标签
	scoreboard players tag @s remove LightRPG.temp.hurtMonster
	scoreboard players tag @s remove LightRPG.temp.dodge
	scoreboard players tag @p[tag=LightRPG.temp.attackMonster] remove LightRPG.temp.crit
	scoreboard players tag @p[tag=LightRPG.temp.attackMonster] remove LightRPG.temp.attackMonster