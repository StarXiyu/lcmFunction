
## 选择攻击的怪物
scoreboard players tag @e[r=10,tag=腐恶僵尸] add LightRPG.temp.pve.attackPlayer

scoreboard players tag @s add LightRPG.temp.pve.hurtPlayer

execute @p[tag=LightRPG.temp.pve.hurtPlayer,r=10] ~ ~ ~ function LightRPG:system/pve/main