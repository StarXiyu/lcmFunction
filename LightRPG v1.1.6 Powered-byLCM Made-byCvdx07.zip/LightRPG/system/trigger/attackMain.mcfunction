
function LightRPG:system/trigger/attackMonster if @s[score_§7LightRPG=1,score_§7LightRPG_min=1]

scoreboard players reset @s §7LightRPG