
function LightRPG:system/trigger/pvp if @s[score_§8LightRPG=1,score_§8LightRPG_min=1]
function LightRPG:system/trigger/monsterAttack01 if @s[score_§8LightRPG=2,score_§8LightRPG_min=2]

scoreboard players reset @s §8LightRPG

advancement revoke @s only lightrpg:pvp
advancement revoke @s only lightrpg:monsterattack01

##! 注意
# 此处执行删除成就指令是由于有时玩家会同时受到多种怪物攻击
# 一种怪物成就被删了，另一种还在，所以全部放到main里
# 优化很简单，把一个地方的怪物放到一个文件里跑 比如1-3是一个副本的怪物 那么就function LightRPG:system/trigger/revokeAdvan/1-3 if @s[score_§8LightRPG_min=1,score_§8LightRPG=3]