
scoreboard players tag @s add LightRPG.temp.pvp.hurtPlayer
advancement revoke @s only lightrpg:pvp

## 选择攻击的玩家
scoreboard players tag @a[r=10,score_MCdamage_min=0,tag=!LightRPG.temp.pvp.hurtPlayer] add LightRPG.temp.pvp.attackPlayer

execute @a[tag=LightRPG.temp.pvp.hurtPlayer,r=10] ~ ~ ~ function LightRPG:system/pvp/main