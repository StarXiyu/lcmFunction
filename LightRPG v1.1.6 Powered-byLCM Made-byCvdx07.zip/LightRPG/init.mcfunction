
## LightRPG 1.1
## byCvdx07
## Powered by LCM

## 基础属性
	scoreboard objectives add health dummy
	scoreboard objectives add maxhealth dummy
	scoreboard objectives add phyAttack dummy
	scoreboard objectives add spellAttack dummy
	scoreboard objectives add critPob dummy
	scoreboard objectives add critAttack dummy

## 物理/法术/暴击抵抗
	scoreboard objectives add physicsResist dummy
	scoreboard objectives add spellResist dummy
	scoreboard objectives add critResist dummy

## 物理/法术穿透
	scoreboard objectives add physicsPene dummy
	scoreboard objectives add spellPene dummy

## 吸血概率
	scoreboard objectives add vampirism dummy
	scoreboard objectives add vampirism.rate dummy

## 闪避/命中概率
	scoreboard objectives add dodge dummy
	scoreboard objectives add hit dummy

## 掉落/抢夺
	scoreboard objectives add drop dummy
	scoreboard objectives add seize dummy

## 接口
	scoreboard objectives add §7LightRPG trigger
	scoreboard objectives add §8LightRPG trigger
	scoreboard objectives add MCdamage stat.damageDealt

## 随机数
	scoreboard objectives add math dummy
	scoreboard objectives add math.out dummy
	scoreboard objectives add max dummy
	scoreboard objectives add min dummy
	scoreboard objectives add onlinetime stat.playOneMinute
	scoreboard players set seedA math 1839654598
	scoreboard players set seedB math -1963624475
	scoreboard players set seedC math -1267732239
	scoreboard players set seedD math 1963199636

## 计算
	scoreboard objectives add math.attack1 dummy
	scoreboard objectives add math.attack2 dummy
	scoreboard objectives add math.attack3 dummy
	scoreboard objectives add physics.math1 dummy
	scoreboard objectives add physics.math2 dummy
	scoreboard objectives add spell.math1 dummy
	scoreboard objectives add spell.math2 dummy
	scoreboard objectives add temp.math1 dummy
	scoreboard objectives add temp.math2 dummy
	scoreboard players set 100 math 100
	scoreboard players set 1000 math 1000
	scoreboard players set 5 math 5
	scoreboard players set 15 math 15

tellraw @a "§6LightRPG §7>> §f感谢您使用§eLIGHTRPG§f,函数已为您初始化完成,祝您游戏愉快"
tellraw @a "§6LightRPG §7>> §f接下来,您可以选择循环调用函数§bLightRPG:main/main§f来激活函数"