
scoreboard players set @s min 1
scoreboard players set @s max 10
function LightRPG:system/random/main

execute @s[score_math.out_min=1,score_math.out=1] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"}," 被 ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 击败了"," §7[From: Cvdx07]"]
execute @s[score_math.out_min=2,score_math.out=2] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"}," 被 ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 一剑封喉"," §7[From: Cvdx07]"]
execute @s[score_math.out_min=3,score_math.out=3] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"}," 在与 ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 的战斗中落败了"," §7[From: 路遥知马力88]"]
execute @s[score_math.out_min=4,score_math.out=4] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"}," 在逃离 ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 的追杀时不幸堕入了地府"," §7[From: 红叶]"]
execute @s[score_math.out_min=5,score_math.out=5] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 收走了 ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"}," 的头颅"," §7[From: Cvdx07]"]
execute @s[score_math.out_min=6,score_math.out=6] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 夺走了 ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"}," 的性命"," §7[From: Cvdx07]"]
execute @s[score_math.out_min=7,score_math.out=7] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 获得了物品 | ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"},"的心脏*1 | "," §7[From: Cvdx07]"]
execute @s[score_math.out_min=8,score_math.out=8] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"}," 逃脱未果，终陨于 ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 之手"," §7[From: 红叶]"]
execute @s[score_math.out_min=9,score_math.out=9] ~ ~ ~ tellraw @a ["\n ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"},"呢喃道:“我错了，我真的知道错了”\n ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"},"摇摇头，“你只是知道自己要死了”\n"," 风雪夜中，又有客至。\n 一位身穿墨青色蟒袍的少年，飞奔而来，他跪在门外雪地里。\n ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"},"持剑横扫，将",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"},"一分为二。","\n §7[From: 烽火戏诸侯]","\n"]
execute @s[score_math.out_min=10,score_math.out=10] ~ ~ ~ tellraw @a [{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1]"}," 对着 ",{"selector":"@e[tag=LightRPG.temp.killFeedBroadcast.died,c=1]"}," 的遗体说道，“有些东西拿了，需要用命来偿还。”"," §7[From: Cvdx07]"]


scoreboard players tag @e[tag=LightRPG.temp.killFeedBroadcast.died,c=1] remove LightRPG.temp.killFeedBroadcast.died
scoreboard players tag @e[tag=LightRPG.temp.killFeedBroadcast.killed,c=1] remove LightRPG.temp.killFeedBroadcast.killed