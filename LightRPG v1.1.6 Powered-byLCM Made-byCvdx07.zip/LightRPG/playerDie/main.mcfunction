
scoreboard players tag @s add LightRPG.temp.killFeedBroadcast.died
scoreboard players tag @p[tag=LightRPG.temp.pvp.attackPlayer] add LightRPG.temp.killFeedBroadcast.killed

function LightRPG:killFeed_broadcast/main

function LightRPG:playerDie/init unless @s[score_maxhealth_min=0]
scoreboard players operation @s health = @s maxhealth

kill @s