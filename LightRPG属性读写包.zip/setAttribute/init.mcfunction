
## 创建get/set属性计分板

scoreboard objectives add n.maxhealth dummy
scoreboard objectives add n.phyAttack dummy
scoreboard objectives add n.spellAttack dummy
scoreboard objectives add n.critPob dummy
scoreboard objectives add n.critAttack dummy 
scoreboard objectives add n.physicsResist dummy
scoreboard objectives add n.spellResist dummy
scoreboard objectives add n.critResist dummy
scoreboard objectives add n.physicsPene dummy
scoreboard objectives add n.spellPene dummy
scoreboard objectives add n.vampirism dummy
scoreboard objectives add n.dodge dummy
scoreboard objectives add n.seize dummy
scoreboard objectives add n.hit dummy
scoreboard objectives add n.vampirism.rate dummy

scoreboard objectives add a.maxhealth dummy
scoreboard objectives add a.phyAttack dummy
scoreboard objectives add a.spellAttack dummy
scoreboard objectives add a.critPob dummy
scoreboard objectives add a.critAttack dummy 
scoreboard objectives add a.physicsResist dummy
scoreboard objectives add a.spellResist dummy
scoreboard objectives add a.critResist dummy
scoreboard objectives add a.physicsPene dummy
scoreboard objectives add a.spellPene dummy
scoreboard objectives add a.vampirism dummy
scoreboard objectives add a.dodge dummy
scoreboard objectives add a.seize dummy
scoreboard objectives add a.hit dummy
scoreboard objectives add a.vampirism.rate dummy

scoreboard objectives add s.maxhealth dummy
scoreboard objectives add s.phyAttack dummy
scoreboard objectives add s.spellAttack dummy
scoreboard objectives add s.critPob dummy
scoreboard objectives add s.critAttack dummy 
scoreboard objectives add s.physicsResist dummy
scoreboard objectives add s.spellResist dummy
scoreboard objectives add s.critResist dummy
scoreboard objectives add s.physicsPene dummy
scoreboard objectives add s.spellPene dummy
scoreboard objectives add s.vampirism dummy
scoreboard objectives add s.dodge dummy
scoreboard objectives add s.seize dummy
scoreboard objectives add s.hit dummy
scoreboard objectives add s.vampirism.rate dummy

scoreboard objectives add math dummy
scoreboard objectives add temp1 dummy

scoreboard objectives add d.maxhealth dummy
scoreboard objectives add d.phyAttack dummy
scoreboard objectives add d.spellAttack dummy
scoreboard objectives add d.critPob dummy
scoreboard objectives add d.critAttack dummy 
scoreboard objectives add d.physicsResist dummy
scoreboard objectives add d.spellResist dummy
scoreboard objectives add d.critResist dummy
scoreboard objectives add d.physicsPene dummy
scoreboard objectives add d.spellPene dummy
scoreboard objectives add d.vampirism dummy
scoreboard objectives add d.dodge dummy
scoreboard objectives add d.seize dummy
scoreboard objectives add d.hit dummy
scoreboard objectives add d.vampirism.rate dummy

scoreboard objectives add regeneration dummy
scoreboard objectives add d.regeneration dummy