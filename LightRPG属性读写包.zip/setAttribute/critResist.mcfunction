scoreboard players set 2 math 2

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{0:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{0:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{1:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{1:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{2:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{2:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{3:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{3:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{4:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{4:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{5:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{5:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{6:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{6:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{7:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{7:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{8:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{8:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{9:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{9:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{10:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{10:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{11:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{11:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{12:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{12:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math

scoreboard players operation @s temp1 = @s s.critResist
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critResist:{13:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critResist:{13:0b}}}}}
scoreboard players operation @s s.critResist /= 2 math