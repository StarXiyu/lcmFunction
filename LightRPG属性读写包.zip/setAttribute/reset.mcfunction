
scoreboard players set @s s.maxhealth 0
scoreboard players set @s s.phyAttack 0
scoreboard players set @s s.spellAttack 0
scoreboard players set @s s.critPob 0
scoreboard players set @s s.critAttack 0 
scoreboard players set @s s.physicsResist 0
scoreboard players set @s s.spellResist 0
scoreboard players set @s s.critResist 0
scoreboard players set @s s.physicsPene 0
scoreboard players set @s s.spellPene 0
scoreboard players set @s s.vampirism 0
scoreboard players set @s s.dodge 0
scoreboard players set @s s.drop 0
scoreboard players set @s s.seize 0
scoreboard players set @s s.hit 0
scoreboard players set @s s.vampirism.rate 0