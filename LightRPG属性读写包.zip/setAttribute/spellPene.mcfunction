scoreboard players set 2 math 2

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{0:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{0:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{1:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{1:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{2:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{2:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{3:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{3:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{4:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{4:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{5:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{5:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{6:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{6:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{7:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{7:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{8:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{8:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{9:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{9:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{10:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{10:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{11:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{11:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{12:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{12:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math

scoreboard players operation @s temp1 = @s s.spellPene
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellPene:{13:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellPene:{13:0b}}}}}
scoreboard players operation @s s.spellPene /= 2 math