scoreboard players set 2 math 2

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{0:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{0:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{1:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{1:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{2:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{2:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{3:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{3:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{4:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{4:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{5:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{5:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{6:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{6:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{7:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{7:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{8:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{8:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{9:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{9:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{10:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{10:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{11:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{11:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{12:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{12:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math

scoreboard players operation @s temp1 = @s s.maxhealth
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{maxhealth:{13:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{maxhealth:{13:0b}}}}}
scoreboard players operation @s s.maxhealth /= 2 math