scoreboard players set 2 math 2

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{0:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{0:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{1:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{1:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{2:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{2:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{3:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{3:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{4:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{4:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{5:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{5:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{6:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{6:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{7:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{7:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{8:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{8:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{9:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{9:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{10:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{10:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{11:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{11:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{12:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{12:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math

scoreboard players operation @s temp1 = @s s.vampirism
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{vampirism:{13:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{vampirism:{13:0b}}}}}
scoreboard players operation @s s.vampirism /= 2 math