scoreboard players set 2 math 2

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{0:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{0:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{1:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{1:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{2:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{2:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{3:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{3:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{4:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{4:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{5:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{5:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{6:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{6:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{7:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{7:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{8:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{8:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{9:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{9:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{10:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{10:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{11:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{11:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{12:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{12:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math

scoreboard players operation @s temp1 = @s s.spellAttack
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{spellAttack:{13:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{spellAttack:{13:0b}}}}}
scoreboard players operation @s s.spellAttack /= 2 math