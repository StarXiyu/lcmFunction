scoreboard players set 2 math 2

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{0:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{0:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{1:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{1:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{2:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{2:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{3:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{3:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{4:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{4:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{5:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{5:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{6:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{6:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{7:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{7:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{8:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{8:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{9:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{9:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{10:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{10:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{11:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{11:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{12:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{12:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math

scoreboard players operation @s temp1 = @s s.critPob
scoreboard players operation @s temp1 %= 2 math
entitydata @s[score_temp1_min=1] {Item:{tag:{dat:{critPob:{13:1b}}}}}
entitydata @s[score_temp1=0] {Item:{tag:{dat:{critPob:{13:0b}}}}}
scoreboard players operation @s s.critPob /= 2 math