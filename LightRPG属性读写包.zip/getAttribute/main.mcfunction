
## 读取值

    # maxhealth
    function API:getAttribute/maxhealth

    # phyAttack
    function API:getAttribute/phyAttack

    # spellAttack
    function API:getAttribute/spellAttack

    # critPob
    function API:getAttribute/critPob

    # critAttack
    function API:getAttribute/critAttack

    # physicsResist
    function API:getAttribute/physicsResist

    # spellResist
    function API:getAttribute/spellResist

    # critResist
    function API:getAttribute/critResist

    # physicsPene
    function API:getAttribute/physicsPene

    # spellPene
    function API:getAttribute/spellPene

    # vampirism
    function API:getAttribute/vampirism

    # dodge
    function API:getAttribute/dodge

    # seize
    function API:getAttribute/seize

    # hit
    function API:getAttribute/hit

    # vampirism.rate
    function API:getAttribute/vampirism.rate