scoreboard players add @s a.seize 1 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{0:1b}}}}]}
scoreboard players add @s a.seize 2 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{1:1b}}}}]}
scoreboard players add @s a.seize 4 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{2:1b}}}}]}
scoreboard players add @s a.seize 8 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{3:1b}}}}]}
scoreboard players add @s a.seize 16 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{4:1b}}}}]}
scoreboard players add @s a.seize 32 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{5:1b}}}}]}
scoreboard players add @s a.seize 64 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{6:1b}}}}]}
scoreboard players add @s a.seize 128 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{7:1b}}}}]}
scoreboard players add @s a.seize 256 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{8:1b}}}}]}
scoreboard players add @s a.seize 512 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{9:1b}}}}]}
scoreboard players add @s a.seize 1024 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{10:1b}}}}]}
scoreboard players add @s a.seize 2048 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{11:1b}}}}]}
scoreboard players add @s a.seize 4096 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{12:1b}}}}]}
scoreboard players add @s a.seize 8192 {Inventory:[{Slot:103b,tag:{Tags:["armor"],dat:{seize:{13:1b}}}}]}

scoreboard players add @s a.seize 1 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{0:1b}}}}]}
scoreboard players add @s a.seize 2 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{1:1b}}}}]}
scoreboard players add @s a.seize 4 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{2:1b}}}}]}
scoreboard players add @s a.seize 8 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{3:1b}}}}]}
scoreboard players add @s a.seize 16 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{4:1b}}}}]}
scoreboard players add @s a.seize 32 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{5:1b}}}}]}
scoreboard players add @s a.seize 64 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{6:1b}}}}]}
scoreboard players add @s a.seize 128 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{7:1b}}}}]}
scoreboard players add @s a.seize 256 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{8:1b}}}}]}
scoreboard players add @s a.seize 512 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{9:1b}}}}]}
scoreboard players add @s a.seize 1024 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{10:1b}}}}]}
scoreboard players add @s a.seize 2048 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{11:1b}}}}]}
scoreboard players add @s a.seize 4096 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{12:1b}}}}]}
scoreboard players add @s a.seize 8192 {Inventory:[{Slot:102b,tag:{Tags:["armor"],dat:{seize:{13:1b}}}}]}

scoreboard players add @s a.seize 1 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{0:1b}}}}]}
scoreboard players add @s a.seize 2 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{1:1b}}}}]}
scoreboard players add @s a.seize 4 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{2:1b}}}}]}
scoreboard players add @s a.seize 8 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{3:1b}}}}]}
scoreboard players add @s a.seize 16 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{4:1b}}}}]}
scoreboard players add @s a.seize 32 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{5:1b}}}}]}
scoreboard players add @s a.seize 64 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{6:1b}}}}]}
scoreboard players add @s a.seize 128 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{7:1b}}}}]}
scoreboard players add @s a.seize 256 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{8:1b}}}}]}
scoreboard players add @s a.seize 512 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{9:1b}}}}]}
scoreboard players add @s a.seize 1024 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{10:1b}}}}]}
scoreboard players add @s a.seize 2048 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{11:1b}}}}]}
scoreboard players add @s a.seize 4096 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{12:1b}}}}]}
scoreboard players add @s a.seize 8192 {Inventory:[{Slot:101b,tag:{Tags:["armor"],dat:{seize:{13:1b}}}}]}

scoreboard players add @s a.seize 1 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{0:1b}}}}]}
scoreboard players add @s a.seize 2 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{1:1b}}}}]}
scoreboard players add @s a.seize 4 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{2:1b}}}}]}
scoreboard players add @s a.seize 8 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{3:1b}}}}]}
scoreboard players add @s a.seize 16 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{4:1b}}}}]}
scoreboard players add @s a.seize 32 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{5:1b}}}}]}
scoreboard players add @s a.seize 64 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{6:1b}}}}]}
scoreboard players add @s a.seize 128 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{7:1b}}}}]}
scoreboard players add @s a.seize 256 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{8:1b}}}}]}
scoreboard players add @s a.seize 512 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{9:1b}}}}]}
scoreboard players add @s a.seize 1024 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{10:1b}}}}]}
scoreboard players add @s a.seize 2048 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{11:1b}}}}]}
scoreboard players add @s a.seize 4096 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{12:1b}}}}]}
scoreboard players add @s a.seize 8192 {Inventory:[{Slot:100b,tag:{Tags:["armor"],dat:{seize:{13:1b}}}}]}

scoreboard players add @s a.seize 1 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{0:1b}}}}]}
scoreboard players add @s a.seize 2 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{1:1b}}}}]}
scoreboard players add @s a.seize 4 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{2:1b}}}}]}
scoreboard players add @s a.seize 8 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{3:1b}}}}]}
scoreboard players add @s a.seize 16 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{4:1b}}}}]}
scoreboard players add @s a.seize 32 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{5:1b}}}}]}
scoreboard players add @s a.seize 64 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{6:1b}}}}]}
scoreboard players add @s a.seize 128 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{7:1b}}}}]}
scoreboard players add @s a.seize 256 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{8:1b}}}}]}
scoreboard players add @s a.seize 512 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{9:1b}}}}]}
scoreboard players add @s a.seize 1024 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{10:1b}}}}]}
scoreboard players add @s a.seize 2048 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{11:1b}}}}]}
scoreboard players add @s a.seize 4096 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{12:1b}}}}]}
scoreboard players add @s a.seize 8192 {Inventory:[{Slot:-106b,tag:{Tags:["offhand"],dat:{seize:{13:1b}}}}]}

scoreboard players add @s a.seize 1 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{0:1b}}}}}
scoreboard players add @s a.seize 2 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{1:1b}}}}}
scoreboard players add @s a.seize 4 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{2:1b}}}}}
scoreboard players add @s a.seize 8 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{3:1b}}}}}
scoreboard players add @s a.seize 16 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{4:1b}}}}}
scoreboard players add @s a.seize 32 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{5:1b}}}}}
scoreboard players add @s a.seize 64 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{6:1b}}}}}
scoreboard players add @s a.seize 128 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{7:1b}}}}}
scoreboard players add @s a.seize 256 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{8:1b}}}}}
scoreboard players add @s a.seize 512 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{9:1b}}}}}
scoreboard players add @s a.seize 1024 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{10:1b}}}}}
scoreboard players add @s a.seize 2048 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{11:1b}}}}}
scoreboard players add @s a.seize 4096 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{12:1b}}}}}
scoreboard players add @s a.seize 8192 {SelectedItem:{tag:{Tags:["mainhand"],dat:{seize:{13:1b}}}}}

## 恭喜你看到了这里
## github项目地址:https://github.com/StarXiyu/lcmFunction
## 这上面可是有价值500的反崩和原理详解哦