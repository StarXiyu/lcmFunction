本算法仅作测试用，非正式版，没有使用教程，需要请自己理解
LIGHTCOMMAND-灯光命令团队 公益作品
byCvdx07(183923232)
出品:LIGHTCOMMAND(228229419)

[1] 部分变量名字及用途
	health 生命
	maxhealth 最大生命
	phyAttack 物理攻击
	spellAttack 法术攻击
	critPob 暴击概率 1=1%
	critAttack 暴击伤害 1=1%
	physicsResist 物理抗性 每点提供0.1%物理免伤
	spellResist 法术抗性 每点提供0.1%法术免伤
	critResist 暴击抵抗 1=1%
	physicsPene 物理穿透 每点削弱0.1%物理免伤
	spellPene 	法术穿透 每点削弱0.1%法术免伤
	vampirism 吸血概率 1=1%
	dodge 闪避概率 1=1%
	drop 怪物掉落物掉落概率 10=1%
	seize 抢夺倍数 10=1%
	hit 命中率 1=1%
	vampirism.rate 吸血倍率 1=1%

[2] 特别鸣谢
	PFS_Godcommands 提供原版成就替换包、随机数判定思路
	hacn 提供数据化设计思路
	vk 提供数据化设计思路
	BadChen 提供数据化设计思路
	星之柒 提供数据化判定思路
	冷冷I02 提供数据化设计思路
	吟游诗人Sir 提供数据化设计思路
	兰心书院 提供算法测试环境、提供数据化设计思路
	ACE 提供同时被攻击/攻击时成就异常的严重问题
	
LightRPG Version beta 1.1.3 2024/12/29