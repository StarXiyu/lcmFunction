
scoreboard players tag @s add LightRPG.temp.pvp.hurtPlayer
advancement revoke @s only lightrpg:pvp

## 选择攻击的玩家
scoreboard players tag @a[c=1,r=10,score_MCdamage_min=0,tag=!LightRPG.temp.pvp.hurtPlayer] add LightRPG.temp.pvp.attackPlayer

execute @p[tag=LightRPG.temp.pvp.hurtPlayer] ~ ~ ~ function LightRPG:system/pvp/main