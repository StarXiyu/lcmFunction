
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ give @p[tag=LightRPG.temp.attackMonster] minecraft:rotten_flesh 1 0 {display:{Name:"§7[> §e腐恶的肉 §7<]",Lore:["§8* §7类型 §b材料","§8* §7获取途径 §f腐恶僵尸"]},HideFlags:1,ench:[{id:70s,lvl:1s}]}
execute @s[tag=LightRPG.temp.drop] ~ ~ ~ tellraw @p[tag=LightRPG.temp.attackMonster] "§f[§6物品获得§f] §e腐恶的肉"
