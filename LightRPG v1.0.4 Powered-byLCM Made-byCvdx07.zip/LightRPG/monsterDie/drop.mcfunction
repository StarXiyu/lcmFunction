
	scoreboard players set @s min 1
	scoreboard players set @s max 100
	function LightRPG:system/random/main

	scoreboard players operation @s math.out += @p[tag=LightRPG.temp.attackMonster] seize
	scoreboard players operation @s math.out -= @s drop
	scoreboard players tag @s[score_math.out=0] add LightRPG.temp.drop