
## 掉落概率运算
function LightRPG:monsterDie/drop

## 死亡音效
execute @p[tag=LightRPG.temp.attackMonster] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 1 1

## 死亡怪物类型判定
function LightRPG:monsterDie/腐恶僵尸 if @s[tag=腐恶僵尸]



kill @s