
scoreboard players enable @a §7LightRPG
execute @a[score_§7LightRPG_min=1] ~ ~ ~ function LightRPG:system/trigger/main

execute @a ~ ~ ~ title @s actionbar [{"text":">> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"HP ","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"[ ","color":"black","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" / ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"maxhealth","name":"@s"},"color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" ] ","color":"black","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<<","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

effect @a minecraft:regeneration 10 255 true
effect @a minecraft:resistance 10 3 true

effect @e[tag=monster] minecraft:resistance 10 4 true