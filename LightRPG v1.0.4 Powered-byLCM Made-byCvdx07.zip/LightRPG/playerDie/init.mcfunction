
scoreboard players set @s maxhelath 20