
## 选择攻击的玩家
scoreboard players tag @a[c=1,r=10,score_MCdamage_min=0] add LightRPG.temp.pvp.attackPlayer

scoreboard players tag @s add LightRPG.temp.pvp.hurtPlayer

execute @p[tag=LightRPG.temp.pvp.hurtPlayer] ~ ~ ~ function LightRPG:system/pvp/main

advancement revoke @s only lightrpg:pvp