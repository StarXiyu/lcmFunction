
## 选择受伤的怪物
scoreboard players tag @e[r=10,c=1,tag=monster] add LightRPG.temp.hurtMonster {HurtTime:9s}

scoreboard players tag @s add LightRPG.temp.attackMonster

execute @e[tag=LightRPG.temp.hurtMonster,c=1] ~ ~ ~ function LightRPG:system/monsterHurt/main

advancement revoke @s only lightrpg:attackmonster