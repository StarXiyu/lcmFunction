
function LightRPG:system/trigger/attackMonster if @s[score_§7LightRPG=1,score_§7LightRPG_min=1]

function LightRPG:system/trigger/pvp if @s[score_§7LightRPG=2,score_§7LightRPG_min=2]

function LightRPG:system/trigger/monsterAttack01 if @s[score_§7LightRPG=3,score_§7LightRPG_min=3]


scoreboard players reset @s §7LightRPG