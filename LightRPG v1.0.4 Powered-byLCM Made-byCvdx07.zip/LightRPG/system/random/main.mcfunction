# 本方法适用于取自定义范围随机数
	# %max% 为最大值 %min% 为最小值
	# 本函数默认范围为 %1-100% 最终 [@s] 在 %math.out% 计分板中的结果 即为所求
	
	# [01] 设置默认范围 %1-100%
	scoreboard players add @s max 0
	scoreboard players add @s min 0
	execute @s[score_max=0,score_max_min=0] ~ ~ ~ execute @s[score_min=0,score_min_min=0] ~ ~ ~ function LightRPG:system/set1
	
	# [02] 定义范围
	scoreboard players set 1 math 1
	scoreboard players operation @s max -= @s min
	scoreboard players operation @s max += 1 math
	
	# [03] 开始取不可控随机
	scoreboard players set 10 math 10
	scoreboard players add seedA math 1
	scoreboard players add seedB math 1
	scoreboard players add seedC math 1
	scoreboard players add seedD math 1
		
		## seedA-C都是种子
		## seedD其实就是不完全的计算结果了
	
	scoreboard players operation @s math = seedA math
	execute @s[score_math_min=-1000000000,score_math=-99999995] ~ ~ ~ scoreboard players set seedA math 1956347898
	scoreboard players operation @s math = seedB math
	execute @s[score_math_min=-1000000000,score_math=-99999995] ~ ~ ~ scoreboard players set seedB math 1000647898
	scoreboard players operation @s math = seedC math
	execute @s[score_math_min=-1000000000,score_math=-99999995] ~ ~ ~ scoreboard players set seedC math 1000214568
	
	scoreboard players operation seedE math = @s[type=player] onlinetime
	
	scoreboard players operation seedD math *= seedB math
	scoreboard players operation seedD math += seedC math
	execute @s[type=player] ~ ~ ~ scoreboard players operation seedD math *= seedE math
	scoreboard players operation seedD math %= seedA math
	
	scoreboard players operation @s math.out = seedD math
	scoreboard players operation @s math.out /= 10 math
	
	scoreboard players set -1 math -1
	scoreboard players operation @s[score_math.out=-1] math.out *= -1 math	
	
	# [04] 可控范围修改
	scoreboard players operation @s math.out %= @s max
	scoreboard players operation @s math.out += @s min
	
	# [05] 初始化值
	scoreboard players reset @s min
	scoreboard players reset @s max
	
	