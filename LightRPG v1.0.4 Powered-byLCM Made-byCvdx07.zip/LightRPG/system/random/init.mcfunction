scoreboard objectives add math dummy
scoreboard objectives add math.out dummy
scoreboard objectives add max dummy
scoreboard objectives add min dummy
scoreboard objectives add onlinetime stat.playOneMinute
	
scoreboard players set seedA math 1839654598
scoreboard players set seedB math -1963624475
scoreboard players set seedC math -1267732239
scoreboard players set seedD math 1963199636