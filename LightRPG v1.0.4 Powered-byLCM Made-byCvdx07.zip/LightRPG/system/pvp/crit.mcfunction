
## 暴击运算 true or false
	scoreboard players set @s min 1
	scoreboard players set @s max 100
	function LightRPG:system/random/main
	
	scoreboard players operation @s math.out += @p[tag=LightRPG.temp.pvp.hurtPlayer] critResist
	scoreboard players operation @s math.out -= @s critPob
	
	execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s math.attack3 *= @s critAttack
	execute @s[score_math.out=0] ~ ~ ~ scoreboard players operation @s math.attack3 /= 100 math
	execute @s[score_math.out=0] ~ ~ ~ scoreboard players tag @s add LightRPG.temp.crit
	
	## 100 x 150% = 100 x 150 / 100 = 150