
## 备份当前攻击基数
	scoreboard players set @s math.attack1 0
	scoreboard players set @s math.attack2 0
	
	scoreboard players operation @s math.attack1 = @s phyAttack
	scoreboard players operation @s math.attack2 = @s spellAttack
	
	
## 物理赋值
	scoreboard players operation @s physics.math2 = @s physicsPene
	
## 法术赋值
	scoreboard players operation @s spell.math2 = @s spellPene