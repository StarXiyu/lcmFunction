## 攻击动画
	particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a[r=10] 152
	playsound minecraft:entity.villager.hurt ambient @s

## 怪物伤害运算
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ function LightRPG:system/pve/monsterAttack

## 物理属性
	function LightRPG:system/pve/physics if @e[tag=LightRPG.temp.pve.attackPlayer,c=1,score_phyAttack_min=1]

## 法术属性
	function LightRPG:system/pve/spell if @e[tag=LightRPG.temp.pve.attackPlayer,c=1,score_spellAttack_min=1]

## 闪避
	function LightRPG:system/pve/dodge if @s[score_dodge_min=1]
	
## 攻击总数
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players set @s math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack1
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s math.attack3 += @s math.attack2

## 暴击运算
	execute @p[tag=LightRPG.temp.pve.attackPlayer,score_critPob_min=1] ~ ~ ~ function LightRPG:system/pve/crit
	
## 怪物生命
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players set @s[score_math.attack3=-1] math.attack3 0
	execute @s[tag=!LightRPG.temp.dodge] ~ ~ ~ scoreboard players operation @s health -= @e[tag=LightRPG.temp.pve.attackPlayer,c=1] math.attack3

## 吸血
	execute @s[score_health_min=1] ~ ~ ~ execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ function LightRPG:system/pve/vampirism if @s[score_vampirism_min=1]
	
## 攻击提示
	tellraw @s [{"text":"您损失了 ","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"math.attack3","name":"@e[tag=LightRPG.temp.pve.attackPlayer,c=1]"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 点血","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"insertion":" "}]
	scoreboard players set @s[score_health=-1] health 0
	execute @s[tag=LightRPG.temp.dodge] ~ ~ ~ tellraw @s [{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 对您的攻击","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"被闪避","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

## 玩家死亡
	function LightRPG:playerDie/main1 if @s[score_health=0]
	
## 删除标签
	scoreboard players tag @s remove LightRPG.temp.pve.hurtPlayer
	scoreboard players tag @s remove LightRPG.temp.dodge
	scoreboard players tag @e[tag=LightRPG.temp.pve.attackPlayer,c=1] remove LightRPG.temp.crit
	scoreboard players tag @e[tag=LightRPG.temp.pve.attackPlayer,c=1] remove LightRPG.temp.pve.attackPlayer