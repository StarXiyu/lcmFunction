
## math.attack1 物理攻击基数 @e[tag=LightRPG.temp.pve.attackPlayer,c=1]
## physics.math2 物理穿透 @e[tag=LightRPG.temp.pve.attackPlayer,c=1]
## physics.math1 物理抵抗 @s

## 初始化
	scoreboard players operation @s physics.math1 = @s physicsResist

## 计算物理
	scoreboard players operation @s physics.math1 -= @e[tag=LightRPG.temp.pve.attackPlayer,c=1] physics.math2
	
## 情况1 还是正数
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s temp.math1 = @s math.attack1
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s temp.math2 = @e[tag=LightRPG.temp.pve.hurtPlayer,c=1] physics.math1
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s temp.math1 *= @s temp.math2
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s temp.math1 /= 1000 math
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s math.attack1 -= @s temp.math1