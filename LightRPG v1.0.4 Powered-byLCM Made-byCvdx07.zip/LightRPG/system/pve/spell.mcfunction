
## math.attack2 法术攻击基数 @e[tag=LightRPG.temp.pve.attackPlayer,c=1]
## spell.math2 法术穿透 @e[tag=LightRPG.temp.pve.attackPlayer,c=1]
## spell.math1 法术抵抗 @s

## 初始化
	scoreboard players operation @s spell.math1 = @s spellResist

## 计算法术
	scoreboard players operation @s spell.math1 -= @e[tag=LightRPG.temp.pve.attackPlayer,c=1] spell.math2
	
	
## 情况1 还是正数
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s temp.math1 = @s math.attack2
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s temp.math2 = @e[tag=LightRPG.temp.pve.hurtPlayer,c=1] spell.math1
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s temp.math1 *= @s temp.math2
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s temp.math1 /= 1000 math
	execute @e[tag=LightRPG.temp.pve.attackPlayer,c=1] ~ ~ ~ scoreboard players operation @s math.attack2 -= @s temp.math1