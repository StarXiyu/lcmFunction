summon minecraft:zombie ~ ~ ~ {CustomName:"[DEMO] 腐恶僵尸",Tags:["monster","腐恶僵尸"],CustomNameVisible:1b,Health:100,Attributes:[{Name:"generic.maxHealth",Base:100}]}

execute @e[tag=腐恶僵尸] ~ ~ ~ scoreboard players set @s[tag=!LightRPG.monsterMath] health 50
execute @e[tag=腐恶僵尸] ~ ~ ~ scoreboard players set @s[tag=!LightRPG.monsterMath] critResist 50
execute @e[tag=腐恶僵尸] ~ ~ ~ scoreboard players set @s[tag=!LightRPG.monsterMath] drop 1000
execute @e[tag=腐恶僵尸] ~ ~ ~ scoreboard players set @s[tag=!LightRPG.monsterMath] phyAttack 5
execute @e[tag=腐恶僵尸] ~ ~ ~ scoreboard players tag @s add LightRPG.monsterMath