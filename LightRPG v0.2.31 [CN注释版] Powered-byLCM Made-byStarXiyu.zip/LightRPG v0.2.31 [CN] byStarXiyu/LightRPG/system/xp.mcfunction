xp -1L @s
scoreboard players add @s xp 1