# 删除300经验
	scoreboard players remove @s xp 300
# 加"1"等级
	scoreboard players add @s level 1
# 升级奖励 - 100游戏币
	## 请自行修改
		scoreboard players add @s money 100
# 升级反馈 [声音+消息]
	## 请自行修改
		playsound minecraft:entity.player.levelup ambient @s
		tellraw @s [{"text":"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"1","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":true},{"text":"升级","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":true},{"text":"1","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":true}]
		tellraw @s [{"text":"-金币+100","color":"aqua","bold":true,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]
		tellraw @s [{"text":"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]