#[1] 防止已经数据过的怪物被重置数据
	scoreboard players tag @s add LightRPG.system.mobMath

#[2] 怪物数据,自行调整
	scoreboard players set @s health 80
	scoreboard players set @s damage 3
	scoreboard players set @s armor 2