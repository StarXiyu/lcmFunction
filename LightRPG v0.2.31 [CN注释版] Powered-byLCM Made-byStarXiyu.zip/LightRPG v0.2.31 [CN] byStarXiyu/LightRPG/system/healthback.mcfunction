# 给自己加血"1"
	## 有需要自己改
		scoreboard players add @s health 1