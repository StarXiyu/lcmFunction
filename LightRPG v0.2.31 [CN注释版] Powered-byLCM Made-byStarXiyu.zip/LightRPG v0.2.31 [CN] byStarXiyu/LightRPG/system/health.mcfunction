# 此方法不建议修改
	## [变量]
		## sh2 忘了
		## health = 生命
		## die = 死亡次数

scoreboard players tag @s remove sh2
scoreboard players set @s health 20
scoreboard players set @s die 0