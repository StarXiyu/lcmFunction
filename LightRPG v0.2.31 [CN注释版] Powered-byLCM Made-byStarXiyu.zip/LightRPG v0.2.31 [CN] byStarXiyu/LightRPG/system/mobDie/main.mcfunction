# [1] 怪物"僵尸1" 死亡检测
	function LightRPG:system/mobDie/僵尸1 if @s[tag=僵尸1]