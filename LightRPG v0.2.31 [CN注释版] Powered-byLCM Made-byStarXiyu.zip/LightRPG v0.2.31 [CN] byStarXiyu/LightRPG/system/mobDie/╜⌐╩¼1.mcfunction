#[1] 给予玩家物品
	give @p[c=1,score_damage1_min=0] minecraft:leather 1 0 {display:{Name:"§6腐恶之心",Lore:["§8* §f类型 §e材料","§8* §f出处 §7[Lv.1] §e腐恶丧尸"]},HideFlags:1,ench:[{id:70s,lvl:1s}]} 
#[2] 击杀反馈
	## [01] 给予物品反馈
		tellraw @p[c=1,score_damage1_min=0] [{"text":"[","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"获得物品","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 腐恶之心","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	## [02] 击杀音效
		execute @p[c=1,score_damage1_min=0] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 1 1
#[3] 击杀自己
	kill @s