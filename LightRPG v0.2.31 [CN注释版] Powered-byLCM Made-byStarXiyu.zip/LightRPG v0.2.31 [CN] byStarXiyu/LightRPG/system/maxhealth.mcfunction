# 此方法不建议修改

 ##[1] 备份玩家的数据进行运算
	scoreboard players operation @s maxhealth.math = @s maxhealth
	scoreboard players operation @s healthmax.math = @s health
 ##[2] 将玩家的最大生命减去玩家的当前生命
	## [原理]
		## 当玩家的最大生命小于等于 -1 时 即判定玩家生命＞玩家最大生命,减去玩家生命
		scoreboard players operation @s maxhealth.math -= @s healthmax.math

 ##[3] 减去玩家生命
	scoreboard players remove @s[score_maxhealth.math=-1] health 1

 ##[4] 重置所用到的变量
	scoreboard players set @s healthmax.math 0
	scoreboard players set @s maxhealth.math 0