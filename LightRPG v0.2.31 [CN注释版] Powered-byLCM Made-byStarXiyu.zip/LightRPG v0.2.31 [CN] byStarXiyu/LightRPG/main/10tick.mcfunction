# 清空自己的降频计分板分数以便下一次执行
	scoreboard players set @s main 0

# 防止玩家自身生命超过玩家最大生命 
	## [变量]
		## health = 生命
		## maxhealth = 最大生命
		## die = 玩家死亡次数

	execute @a[tag=math] ~ ~ ~ function LightRPG:system/maxhealth if @s[score_die_min=0,score_die=0]