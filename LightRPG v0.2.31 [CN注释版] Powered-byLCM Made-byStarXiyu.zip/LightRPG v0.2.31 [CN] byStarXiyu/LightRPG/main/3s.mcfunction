#[1] 清空自己的降频计分板分数以便下一次执行
	scoreboard players set @s main 0
	
#[2] 防止新玩家没有数据化数据
	execute @a ~ ~ ~ function LightRPG:system/math if @s[tag=!math]
	
#[3] 自然回血
	execute @a ~ ~ ~ function LightRPG:system/healthback