#[1] 清空自己的降频计分板分数以便下一次执行
	scoreboard players set @s main 0

#[2] 经验类:达到指定经验升级
	## 300 为指定经验 , 如需更改自行修改
	execute @a[score_xp_min=300] ~ ~ ~ function LightRPG:system/level

#[3] 经验类:将原版的经验数据化
	execute @a[score_经验计算_min=1] ~ ~ ~ function LightRPG:system/xp