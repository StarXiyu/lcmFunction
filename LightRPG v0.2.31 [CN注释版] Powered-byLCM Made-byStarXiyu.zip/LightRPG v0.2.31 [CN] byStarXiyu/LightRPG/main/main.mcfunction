		#############################
		#Power by LCM				#
		#Dec -- maxblock.cn			#
		#By.Xiyu&Xiaoxiang			#
		#############################

#[1] 降频主类计分板
	## 具体原理:给盔甲架加分,达到一定分数执行命令
		## 刻级加分
			scoreboard players add @e[tag=tick,type=armor_stand] main 1
	## 调用激活
		execute @e[tag=10tick] ~ ~ ~ function LightRPG:main/10tick if @s[score_main_min=10,score_main=20]
		execute @e[tag=20tick] ~ ~ ~ function LightRPG:main/20tick if @s[score_main_min=20,score_main=40]
	
#[2] 数据化主类:防止玩家/怪物自然死亡
	effect @e[tag=mob] minecraft:resistance 9999 255 true
	effect @a minecraft:regeneration 999 255 true

#[3] 数据化主类:玩家/怪物数据化触发[总触发部分]
	## [1] 玩家受伤
		execute @a[score_sh_min=0] ~ ~ ~ function LightRPG:system/playersh
	## [2] 怪物受伤
		# [01] 给受伤怪物加tag
		execute @a[score_damage1_min=0] ~ ~ ~ execute @e[tag=mob,c=1] ~ ~ ~ scoreboard players tag @s add sh {HurtTime:10s}
		# [02] 让受伤怪物执行怪物受伤
		execute @a[score_damage1_min=0] ~ ~ ~ execute @e[tag=sh] ~ ~ ~  function LightRPG:system/mobsh