		#############################
		#Power by LCM				#
		#Dec -- maxblock.cn			#
		#By.Xiyu&Xiaoxiang			#
		#############################

#[1] 等级经验系统计分板
	scoreboard objectives add xp dummy
	scoreboard objectives add level dummy
	scoreboard objectives add 经验计算 level
	
#[2] 数据化主部分:伤害/防御/生命 数据计分板
	scoreboard objectives add damage dummy
	scoreboard objectives add armor dummy
	scoreboard objectives add health dummy
	scoreboard objectives add maxhealth dummy
	
#[3] 数据化计算计分板
	scoreboard objectives add 计算 dummy
	scoreboard objectives add damage.math dummy
	scoreboard objectives add armor.math dummy
	scoreboard objectives add health.math dummy
	scoreboard objectives add healthmax.math dummy
	scoreboard objectives add maxhealth.math dummy
	
#[4] 其他计分板
	scoreboard objectives add leave stat.leaveGame

#[5] 数据化主部分:触发判定计分板
	scoreboard objectives add die deathCount
	scoreboard objectives add damage1 stat.damageDealt
	scoreboard objectives add sh stat.damageTaken

#[6] 版权信息
	tellraw @a [{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTRPG-MATH","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n执行:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"初始化模块","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n作者:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"夕羽","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n㪊:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"245684797","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTRPG-MATH","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	playsound block.note.pling block @p

#[7] 降频计分板初始化
function LightRPG:main/scoreboard