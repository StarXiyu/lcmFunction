#[1] 清空自己的降频计分板分数以便下一次执行
	scoreboard players set @s main 0

#[2] 添加3s,5s降频级的分数
	scoreboard players add @e[tag=main,type=armor_stand] main 1

#[3] 当3s,5s的降频级分数达到一定程度触发该级的函数
	execute @e[tag=3s] ~ ~ ~ function LightRPG:main/3s if @s[score_main_min=3,score_main=10]
	execute @e[tag=5s] ~ ~ ~ function LightRPG:main/5s if @s[score_main_min=5,score_main=10]

#[4] 执行1s降频级的函数
	function LightRPG:main/1s
	
 ## [TIP] 20tick = 1s
 ## 将20tick与1s分开是为了方便命令书写