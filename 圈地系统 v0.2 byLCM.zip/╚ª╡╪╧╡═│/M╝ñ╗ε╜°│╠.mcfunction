# 本版本系统待优化
	## 优化思路:同一分数所执行操作放在一起即可
		# 懒得优化了,但是分成可以帮你们分好
	
	# 防止删除失败,注意执行顺序
	execute @e[tag=领地中心,type=armor_stand] ~ ~ ~ scoreboard players tag @a[r=32] add 领地中

scoreboard players enable @a lcm.领地
	# 1-5 一个函数分别执行
	execute @a[score_lcm.领地_min=1,score_lcm.领地=3] ~ ~ ~ function 圈地系统:r领地介绍
	execute @e[tag=主城] ~ ~ ~ execute @a[r=282,score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:f创建失败
	execute @e[tag=末地] ~ ~ ~ execute @a[r=282,score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:f创建失败
	execute @a[score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:f创建失败 if @s[tag=主人]
	execute @a[score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:j创建成功 if @s[tag=!主人]
	execute @e[tag=领地中心] ~ ~ ~ execute @a[r=64,score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:f创建失败
	execute @a[tag=主人,score_lcm.领地=5,score_lcm.领地_min=5] ~ ~ ~ function 圈地系统:d删除成功 if @s[tag=领地中]

	# 防止删除失败,注意执行顺序
	scoreboard players tag @a remove 领地中

function 圈地系统:p领地保护

	#待降频
	execute @e[tag=领地中心] ~ ~ ~ particle endRod ~ ~ ~ 32 32 32 0.1 20