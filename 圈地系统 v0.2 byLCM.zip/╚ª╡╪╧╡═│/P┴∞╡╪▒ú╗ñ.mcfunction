
# 这几条放到一个函数里由一个execute调用就行,防止不必要的for循环@e搜索消耗
	execute @e[tag=领地中心] ~ ~ ~ execute @a[r=35] ~ ~ ~ /scoreboard players operation @s lcm.领地保护 = @s lcm.领地进程
	execute @e[tag=领地中心] ~ ~ ~ execute @a ~ ~ ~ /scoreboard players operation @s lcm.领地保护 -= @e[tag=领地中心,r=32] lcm.领地进程
	execute @e[tag=领地中心] ~ ~ ~ gamemode 3 @a[score_lcm.领地保护_min=1,r=32,tag=!op,m=!3]
	execute @e[tag=领地中心] ~ ~ ~ gamemode 3 @a[score_lcm.领地保护=-1,r=32,tag=!op,m=!3]
	execute @e[tag=领地中心] ~ ~ ~ gamemode 0 @a[tag=!op,rm=23,r=32,m=3]
	
# 让没有初始化的调用即可
	scoreboard players set @a[tag=!入侵初始化] lcm.领地保护 0
	scoreboard players tag @a[tag=!入侵初始化,score_lcm.领地保护_0,score_lcm.领地保护_min=0] add 入侵初始化