scoreboard players operation @s lcm.领地删除 = @s lcm.领地进程
execute @e[tag=领地中心] ~ ~ ~ scoreboard players operation @s lcm.领地中心删除 = @s lcm.领地进程
scoreboard players operation @e[tag=领地中心] lcm.领地中心删除 -= @s lcm.领地删除
scoreboard players tag @e[tag=领地中心,score_lcm.领地中心删除=0,score_lcm.领地中心删除_min=0] add 删除领地
scoreboard players set @s lcm.领地 0
kill @e[tag=删除领地]
scoreboard players tag @s remove 主人
tellraw @s [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> 欢迎使用LIGHTCOMMAND圈地系统，领地","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"删除成功！","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n-你现在可以重新建立领地","color":"yellow","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]