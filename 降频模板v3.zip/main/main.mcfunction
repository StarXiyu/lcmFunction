scoreboard players add @e[tag=5tick,type=armor_stand] main 1

execute @e[tag=5tick] ~ ~ ~ function main:5tick if @s[score_main_min=5,score_main=10]