
scoreboard players set @s tempBanT1 0
scoreboard players reset @s tempBanT2

scoreboard players tag @s remove tempban.ban

tellraw @s "§6Tempban §f>> §a您已自由,请好好做人\n§7(Tempban System Powered by Cvdx07_)"