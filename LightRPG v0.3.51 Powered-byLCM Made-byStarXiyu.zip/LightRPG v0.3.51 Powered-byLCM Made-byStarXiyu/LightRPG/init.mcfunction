
# 储存
	scoreboard objectives add damage dummy
	scoreboard objectives add armor dummy
	scoreboard objectives add health dummy
	scoreboard objectives add maxhealth dummy
	scoreboard objectives add crit.pob dummy
	scoreboard objectives add crit.armor dummy

# 运算
	scoreboard objectives add damage.math dummy
	scoreboard objectives add armor.math dummy
	scoreboard objectives add health.math dummy
	scoreboard objectives add healthmax.math dummy
	scoreboard objectives add maxhealth.math dummy
	scoreboard objectives add crit.math dummy
	
# 判定 
	scoreboard objectives add leave stat.leaveGame
	scoreboard objectives add die deathCount
	scoreboard objectives add damage1 stat.damageDealt
	##scoreboard objectives add hurt stat.damageTaken
	##scoreboard objectives add hurtuid dummy
	scoreboard objectives add max dummy
	scoreboard objectives add min dummy
	scoreboard objectives add armor.time dummy
	scoreboard objectives add roll dummy
	scoreboard objectives add math dummy
	scoreboard objectives add LightRPG.tr trigger
	scoreboard players set seedA math 1839654598
	scoreboard players set seedB math -1963624475
	scoreboard players set seedC math -1267732239
	scoreboard players set seedD math 1963199636
	scoreboard objectives add onlinetime stat.playOneMinute

tellraw @a [{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTRPG-MATH","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n执行:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"初始化模块","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n作者:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"夕羽","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n㪊:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"245684797","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTRPG-MATH","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
playsound block.note.pling block @p

scoreboard objectives add main dummy

summon minecraft:armor_stand ~ ~ ~1 {CustomName:"3s",Tags:["3s","main"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
summon minecraft:armor_stand ~ ~ ~2 {CustomName:"10tick",Tags:["10tick"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
summon minecraft:armor_stand ~ ~ ~3 {CustomName:"20tick",Tags:["20tick"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
summon minecraft:armor_stand ~ ~ ~4 {CustomName:"5tick",Tags:["5tick"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}