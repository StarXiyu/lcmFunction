summon minecraft:zombie ~ ~1 ~ {CustomName:"§7[DEMO] §c僵尸1",Tags:["mob","僵尸1"],CustomNameVisible:1b,Health:99999,DeathLootTable:"entities/empty",Attributes:[{Name:"generic.maxHealth",Base:99999},{Name:"generic.armor",Base:9999},{Name:"generic.armorToughness",Base:9999}]}

execute @e[tag=僵尸1] ~ ~ ~ function LightRPG:system/mobMath/僵尸1 if @s[tag=!LightRPG.system.mobMath]