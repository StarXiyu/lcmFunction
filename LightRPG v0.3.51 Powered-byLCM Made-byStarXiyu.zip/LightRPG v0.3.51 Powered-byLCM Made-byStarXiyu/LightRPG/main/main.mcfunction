scoreboard players add @e[tag=5tick,type=armor_stand] main 1
execute @e[tag=5tick] ~ ~ ~ function LightRPG:main/5tick if @s[score_main_min=5,score_main=10]

scoreboard players enable @a LightRPG.tr
execute @a[score_LightRPG.tr_min=1] ~ ~ ~ function LightRPG:system/trigger/main

##execute @a[score_hurt_min=0] ~ ~ ~ function LightRPG:system/playerHurt
##execute @a[score_damage1_min=0] ~ ~ ~ function LightRPG:system/damage