scoreboard players set @s main 0

scoreboard players add @e[tag=20tick,type=armor_stand] main 10
execute @e[tag=20tick] ~ ~ ~ function LightRPG:main/20tick if @s[score_main_min=20,score_main=40]