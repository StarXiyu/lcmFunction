# 击杀反馈
particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a 152

# 赋值
scoreboard players operation @s health.math = @s health
scoreboard players operation @s[tag=system.temp.allow.armor] armor.math = @s armor

# 计算
##scoreboard players operation @e[c=1,tag=mob,r=2] damage.math = @e[c=1,tag=mob,r=2] damage

scoreboard players operation @s damage.math -= @s armor.math
execute @s[score_damage.math=-1] ~ ~ ~ scoreboard players set @s damage.math 0

scoreboard players operation @s health -= @s damage.math

# 击杀
kill @s[score_health=0]

# 重置
scoreboard players tag @s[score_armor.math=0] remove system.temp.allow.armor
scoreboard players reset @s armor.math 
scoreboard players reset @s health.math
scoreboard players reset @s damage.math

##scoreboard players reset @s hurt