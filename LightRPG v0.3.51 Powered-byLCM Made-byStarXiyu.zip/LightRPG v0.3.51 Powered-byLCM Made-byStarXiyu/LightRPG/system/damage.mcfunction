execute @e[tag=mob] ~ ~ ~ scoreboard players tag @s add sh {HurtTime:9s}

scoreboard players operation @e[tag=sh] hurtuid = @s uid
scoreboard players reset @s damage1

execute @e[tag=sh] ~ ~ ~ function LightRPG:system/mobHurt