scoreboard players set 2 math 2

scoreboard players tag @s add LightRPG.system.temp.crit
scoreboard players operation @s damage.math *= 2 math