scoreboard players set @s max 100
scoreboard players set @s min 1

scoreboard players add @s crit.pob 0
scoreboard players operation @e[tag=sh] crit.math = @s crit.pob

function LightRPG:random/main
scoreboard players operation @s roll += @e[tag=sh] crit.armor
scoreboard players operation @e[tag=sh] crit.math -= @s roll

function LightRPG:system/crit/crit if @e[tag=sh,score_crit.math_min=0]

scoreboard players reset @s crit.math