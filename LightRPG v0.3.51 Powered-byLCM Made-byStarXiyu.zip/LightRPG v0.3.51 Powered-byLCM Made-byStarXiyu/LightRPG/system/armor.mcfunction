scoreboard players add @s armor.time 5

execute @s[score_armor.time_min=80] ~ ~ ~ scoreboard players tag @e[tag=mob] add system.temp.allow.armor
execute @s[score_armor.time_min=80] ~ ~ ~ scoreboard players tag @a add system.temp.allow.armor
execute @s[score_armor.time_min=80] ~ ~ ~ scoreboard players set @s armor.time 0