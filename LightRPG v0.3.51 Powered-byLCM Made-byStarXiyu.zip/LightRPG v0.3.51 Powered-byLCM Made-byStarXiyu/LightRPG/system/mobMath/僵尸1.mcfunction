scoreboard players tag @s add LightRPG.system.mobMath

scoreboard players set @s health 80
scoreboard players set @s damage 3
scoreboard players set @s armor 2
scoreboard players set @s crit.armor 50