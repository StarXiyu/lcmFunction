function LightRPG:system/mobDie/僵尸1 if @s[tag=僵尸1]

kill @s