function LightRPG:system/trigger/mobHurt if @s[score_LightRPG.tr=1,score_LightRPG.tr_min=1]

function LightRPG:system/trigger/playerHurt/01 if @s[score_LightRPG.tr=2,score_LightRPG.tr_min=2]
## 怪物01攻击玩家

function LightRPG:system/trigger/playerHurt/02 if @s[score_LightRPG.tr=3,score_LightRPG.tr_min=3]
## 玩家攻击玩家
scoreboard players reset @s LightRPG.tr