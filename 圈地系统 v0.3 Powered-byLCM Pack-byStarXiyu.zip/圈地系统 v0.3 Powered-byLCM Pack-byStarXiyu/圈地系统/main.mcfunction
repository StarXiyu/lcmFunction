	# 防止删除失败,注意执行顺序
	execute @e[tag=领地中心,type=armor_stand] ~ ~ ~ scoreboard players tag @a[r=32] add 领地中

scoreboard players enable @a lcm.领地
	# 1-5 一个函数分别执行
	
	execute @a[score_lcm.领地_min=1] ~ ~ ~ function 圈地系统:cd
	
	# 防止删除失败,注意执行顺序
	scoreboard players tag @a remove 领地中

function 圈地系统:p领地保护

	# 待降频
		# 要降频的话自己把粒子数量加大
	execute @e[tag=领地中心] ~ ~ ~ particle endRod ~ ~ ~ 32 32 32 0.1 20