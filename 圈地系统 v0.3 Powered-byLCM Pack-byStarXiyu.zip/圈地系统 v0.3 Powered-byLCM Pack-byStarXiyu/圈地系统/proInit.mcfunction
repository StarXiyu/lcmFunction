	
	scoreboard players set @s lcm.领地保护 0
	scoreboard players tag @s add 入侵初始化