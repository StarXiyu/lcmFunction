
# 这几条放到一个函数里由一个execute调用就行,防止不必要的for循环@e搜索消耗
	execute @e[tag=领地中心] ~ ~ ~ function 圈地系统:protect
	
# 让没有初始化的调用即可
	function 圈地系统:proInit unless @s[tag=入侵初始化]