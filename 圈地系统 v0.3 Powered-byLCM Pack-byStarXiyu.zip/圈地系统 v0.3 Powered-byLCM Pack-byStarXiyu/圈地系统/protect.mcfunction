execute @a[r=35] ~ ~ ~ scoreboard players operation @s lcm.领地保护 = @s lcm.领地进程
execute @a ~ ~ ~ scoreboard players operation @s lcm.领地保护 -= @e[tag=领地中心,r=32] lcm.领地进程
gamemode 3 @a[score_lcm.领地保护_min=1,r=32,tag=!op,m=!3]
gamemode 3 @a[score_lcm.领地保护=-1,r=32,tag=!op,m=!3]
gamemode 0 @a[tag=!op,rm=23,r=32,m=3]