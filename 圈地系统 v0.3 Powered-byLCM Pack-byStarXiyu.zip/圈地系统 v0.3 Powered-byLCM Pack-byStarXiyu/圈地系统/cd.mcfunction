	
	execute @s[score_lcm.领地_min=1,score_lcm.领地=3] ~ ~ ~ function 圈地系统:r领地介绍
	execute @e[tag=主城] ~ ~ ~ execute @a[r=282,score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:f创建失败
	execute @e[tag=末地] ~ ~ ~ execute @a[r=282,score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:f创建失败
	execute @s[score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:f创建失败 if @s[tag=主人]
	execute @s[score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:j创建成功 if @s[tag=!主人]
	execute @e[tag=领地中心] ~ ~ ~ execute @a[r=64,score_lcm.领地_min=4,score_lcm.领地=4] ~ ~ ~ function 圈地系统:f创建失败
	execute @s[tag=主人,score_lcm.领地=5,score_lcm.领地_min=5] ~ ~ ~ function 圈地系统:d删除成功 if @s[tag=领地中]