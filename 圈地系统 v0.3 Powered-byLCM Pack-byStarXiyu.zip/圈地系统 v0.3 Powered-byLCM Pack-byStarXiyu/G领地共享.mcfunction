# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃

 # 废弃
	execute @a[score_lcm.ldgx_min=1,tag=!主人] ~ ~ ~ tellraw @a [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"欢迎使用LIGHTCOMMAND圈地系统，很遗憾的是","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"领地共享失败","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"，可能是以下原因\n","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"-你没有领地","color":"yellow","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @a[score_lcm.ldgx_min=1,tag=!主人] ~ ~ ~ scoreboard players set @s lcm.ldgx 0
	
	scoreboard players reset @e[tag=ldgx.armor] lcm.ldgx.pe
	execute @a ~ ~ ~ scoreboard players add @e[tag=ldgx.armor] lcm.ldgx.pe 1

	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=1,score_lcm.ldgx.pe=1] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ scoreboard players set @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=1,score_lcm.ldgx.pe=1] lcm.ldgx.min 9
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=1,score_lcm.ldgx.pe=1] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ /tellraw @s [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> 欢迎使用LIGHTCOMMAND领地共享系统，很遗憾的是","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"你一个人没有办法启动领地共享系统","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=1,score_lcm.ldgx.pe=1] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ scoreboard players set @s lcm.ldgx 0

	scoreboard players enable @a lcm.ldgx
	scoreboard players enable @a lcm.ldgx.ad

	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ scoreboard players set @a lcm.ldgx.ad 0
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ execute @a ~ ~ ~ scoreboard players operation @s lcm.ldgx.uid = @s uid
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ scoreboard players operation @a lcm.ldgx.uid -= @p[score_lcm.ldgx_min=1] lcm.ldgx
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ scoreboard players set @a[score_lcm.ldgx.uid_min=0,score_lcm.ldgx.uid=0] lcm.ldgx.min 1
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ scoreboard players set @a[score_lcm.ldgx_min=1] lcm.ldgx.min 2
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ tellraw @a [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 正在使用领地共享系统，期间其余人无法使用","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx_min=1] ~ ~ ~ scoreboard players set @s lcm.ldgx 0

	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=2,score_lcm.ldgx.min_min=2] ~ ~ ~ tellraw @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 邀请你使用他的领地，请仔细阅读后再做决定","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n-若同意,你将失去你的领地所有权\n-1分钟后自动取消倒计时","color":"yellow","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n『同意』","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger lcm.ldgx.ad 1"}},{"text":"  『拒绝』","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger lcm.ldgx.ad 2"}}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=2,score_lcm.ldgx.min_min=2] ~ ~ ~ tellraw @s [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1]","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 已经接受到你发送的请求","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=2,score_lcm.ldgx.min_min=2] ~ ~ ~ scoreboard players set @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] lcm.ldgx.min 3
	
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=3,score_lcm.ldgx.min_min=3] ~ ~ ~ scoreboard players set @e[tag=ldgx.armor] lcm.ldgx.min 1200
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=3,score_lcm.ldgx.min_min=3] ~ ~ ~ scoreboard players remove @e[tag=ldgx.armor] lcm.ldgx.min 1
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=3,score_lcm.ldgx.min_min=3] ~ ~ ~ scoreboard objectives remove lcm.ldgx
	
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=1,score_lcm.ldgx.ad=1,c=1] ~ ~ ~ tp @s @a[score_lcm.ldgx.min_min=3]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=1,score_lcm.ldgx.ad=1,c=1] ~ ~ ~ scoreboard players operation @s lcm.领地进程 = @a[score_lcm.ldgx.min_min=3] lcm.领地进程
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=1,score_lcm.ldgx.ad=1,c=1] ~ ~ ~ tellraw @a[score_lcm.ldgx.min_min=3,score_lcm.ldgx.min=3] [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 已经同意了你的请求","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=1,score_lcm.ldgx.ad=1,c=1] ~ ~ ~ tellraw @s [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"请求同意成功","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=1,score_lcm.ldgx.ad=1,c=1] ~ ~ ~ scoreboard objectives add lcm.ldgx trigger
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=1,score_lcm.ldgx.ad=1,c=1] ~ ~ ~ tellraw @a [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"现在领地共享系统可以正常使用！","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=1,score_lcm.ldgx.ad=1,c=1] ~ ~ ~ scoreboard players set @a lcm.ldgx.ad 0
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=1,score_lcm.ldgx.ad=1,c=1] ~ ~ ~ scoreboard players set * lcm.ldgx.min 0
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ tellraw @s [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"请求拒绝成功","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ tellraw @a[score_lcm.ldgx.min_min=3,score_lcm.ldgx.min=3] [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 拒绝了你的邀请","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ scoreboard objectives add lcm.ldgx trigger
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ tellraw @a [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"现在领地共享系统可以正常使用！","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ scoreboard players set @a lcm.ldgx.ad 0
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @a[score_lcm.ldgx.min=1,score_lcm.ldgx.min_min=1] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ scoreboard players set * lcm.ldgx.min 0

	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @s[score_lcm.ldgx.min_min=9,score_lcm.ldgx.min=9] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ scoreboard players set @a lcm.ldgx.ad 0
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @s[score_lcm.ldgx.min_min=9,score_lcm.ldgx.min=9] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ tellraw @a [{"text":"LIGHTCOMMAND-领地系统","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" >>> ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"现在领地共享系统可以重新使用！","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @s[score_lcm.ldgx.min_min=9,score_lcm.ldgx.min=9] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ scoreboard players set * lcm.ldgx.min 0
	execute @e[tag=ldgx.armor,score_lcm.ldgx.pe_min=2] ~ ~ ~ execute @s[score_lcm.ldgx.min_min=9,score_lcm.ldgx.min=9] ~ ~ ~ execute @s[score_lcm.ldgx.ad_min=2,score_lcm.ldgx.ad=2,c=1] ~ ~ ~ scoreboard objectives add lcm.ldgx trigger

 # 废弃

# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃
# 本函数已废弃