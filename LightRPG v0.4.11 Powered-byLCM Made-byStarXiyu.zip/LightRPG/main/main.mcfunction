scoreboard players add @e[tag=5tick,type=armor_stand] main 1
execute @e[tag=5tick] ~ ~ ~ function LightRPG:main/5tick if @s[score_main_min=5,score_main=10]

scoreboard players enable @a LightRPG.tr
execute @a[score_LightRPG.tr_min=1] ~ ~ ~ function LightRPG:system/trigger/main

# LightRPG v0.4.11
# byCvdx07(183923232)
# LCM 出品