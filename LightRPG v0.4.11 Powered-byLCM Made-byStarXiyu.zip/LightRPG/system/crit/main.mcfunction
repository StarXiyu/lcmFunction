scoreboard players set @s max 100
scoreboard players set @s min 1

scoreboard players add @s crit.pob 0
scoreboard players operation @e[tag=LightRPG.temp.mob.hurt] crit.math = @s crit.pob

function LightRPG:random/main
scoreboard players operation @s roll += @e[tag=LightRPG.temp.mob.hurt] crit.armor
scoreboard players operation @e[tag=LightRPG.temp.mob.hurt] crit.math -= @s roll

function LightRPG:system/crit/crit if @e[tag=LightRPG.temp.mob.hurt,score_crit.math_min=0]

scoreboard players reset @s crit.math