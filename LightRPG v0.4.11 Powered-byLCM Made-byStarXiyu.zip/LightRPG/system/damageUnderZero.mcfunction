scoreboard players set @s damage.math 0
scoreboard players operation @e[tag=LightRPG.temp.mob.hurt,r=8] armor.math -= @s damage

scoreboard players set @e[tag=LightRPG.temp.mob.hurt,r=8,score_armor.math=-1] armor.math 0