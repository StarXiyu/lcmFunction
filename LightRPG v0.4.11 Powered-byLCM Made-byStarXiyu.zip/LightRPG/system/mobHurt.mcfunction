

# 击杀反馈
	particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a 152
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 2 1

# 赋值
	scoreboard players operation @s health.math = @s health

# 暴击
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ function LightRPG:system/crit/main

# 计算
	
	scoreboard players operation @a[tag=LightRPG.system.temp.damage] damage.math = @a[tag=LightRPG.system.temp.damage] damage
	execute @s[score_armor.math_min=0] ~ ~ ~ scoreboard players operation @a[tag=LightRPG.system.temp.damage] damage.math -= @s armor.math
	
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ execute @s[score_damage.math=0] ~ ~ ~ function LightRPG:system/damageUnderZero
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ scoreboard players operation @s[tag=LightRPG.system.temp.crit] crit.math = @s[tag=LightRPG.system.temp.crit] damage.math
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ scoreboard players operation @s[tag=LightRPG.system.temp.crit] crit.math *= @s[tag=LightRPG.system.temp.crit] crit.damage
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ scoreboard players operation @s[tag=LightRPG.system.temp.crit] crit.math /= 100 math
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ scoreboard players operation @s[tag=LightRPG.system.temp.crit] damage.math += @s crit.math
	
	scoreboard players operation @s armor.math -= @a[tag=LightRPG.system.temp.damage] damage.math
	scoreboard players operation @s health -= @a[tag=LightRPG.system.temp.damage] damage.math

# 伤害数显
	title @a[tag=LightRPG.system.temp.damage] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"⚔","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ title @s[tag=LightRPG.system.temp.crit] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"☣","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	title @a[tag=LightRPG.system.temp.damage] subtitle [{"score":{"objective":"damage.math","name":"@a[tag=LightRPG.system.temp.damage]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" / ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
# 怪物死亡
	execute @s ~ ~ ~ function LightRPG:system/mobDie/main unless @s[score_health_min=1]

# 重置
	scoreboard players reset @a[tag=LightRPG.system.temp.damage] damge.math
	##scoreboard players set @s hurtuid 0
	scoreboard players set @s health.math 0
	scoreboard players tag @s remove LightRPG.temp.mob.hurt
	scoreboard players tag @a remove LightRPG.system.temp.damage
	scoreboard players tag @a remove LightRPG.system.temp.crit