# 击杀反馈
particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a 152

# 计算
execute @s[score_armor.math_min=0] ~ ~ ~ scoreboard players operation @s damage.math -= @s armor.math
function LightRPG:system/playerDamageUnderZero if @s[score_damage.math=0]

scoreboard players operation @s armor.math -= @s damage.math
scoreboard players operation @s health -= @s damage.math

# 击杀
kill @s[score_health=0]

# 重置
scoreboard players reset @s health.math
scoreboard players reset @s damage.math

##scoreboard players reset @s hurt