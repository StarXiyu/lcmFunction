setblock ~-1 ~ ~-1 minecraft:air
setblock ~-1 ~ ~1 minecraft:air
setblock ~1 ~ ~1 minecraft:air
setblock ~1 ~ ~-1 minecraft:air
setblock ~ ~ ~-1 minecraft:air
setblock ~1 ~ ~ minecraft:air
setblock ~ ~ ~1 minecraft:air
setblock ~-1 ~ ~ minecraft:air
setblock ~ ~ ~ minecraft:air

execute @p[dy=2,rx=-90,rxm=-90] ~ ~ ~ function blockfun:machine/steamPower/give
tellraw @a[r=10] {"text":"§f[§6方块科技§f] §c火力发电机§7拆除完成!"}

kill @s