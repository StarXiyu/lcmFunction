setblock ~-1 ~ ~-1 minecraft:iron_trapdoor
setblock ~-1 ~ ~1 minecraft:iron_trapdoor
setblock ~1 ~ ~1 minecraft:iron_trapdoor
setblock ~1 ~ ~-1 minecraft:iron_trapdoor
setblock ~ ~ ~-1 minecraft:stone_slab
setblock ~1 ~ ~ minecraft:stone_slab
setblock ~ ~ ~1 minecraft:stone_slab
setblock ~-1 ~ ~ minecraft:stone_slab
setblock ~ ~ ~ minecraft:furnace

summon minecraft:armor_stand ~ ~ ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:0,Tags:["ic.steamPower","blockfun"]}
tellraw @a[r=10] {"text":"§f[§6方块科技§f] §c火力发电机§7放置完成,您可以站在熔炉上抬头拆除该机器!"}

kill @s