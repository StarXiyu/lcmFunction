execute @s[tag=ic.icWorkBench.summon] ~ ~ ~ function blockfun:machine/icWorkBench/summon

execute @s[tag=ic.steamPower.summon] ~ ~ ~ function blockfun:machine/steamPower/summon
