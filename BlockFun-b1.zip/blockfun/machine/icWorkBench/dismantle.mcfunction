fill ~-1 ~ ~1 ~1 ~ ~-1 minecraft:air
setblock ~ ~1 ~-1 minecraft:air
setblock ~1 ~1 ~ minecraft:air
setblock ~ ~1 ~1 minecraft:air
setblock ~-1 ~1 ~ minecraft:air
setblock ~ ~1 ~ minecraft:air

execute @p[dy=2,rx=-90,rxm=-90] ~ ~ ~ function blockfun:machine/icWorkBench/give
tellraw @a[r=10] {"text":"§f[§6方块科技§f] §c工业工作台§7拆除完成!"}

kill @s