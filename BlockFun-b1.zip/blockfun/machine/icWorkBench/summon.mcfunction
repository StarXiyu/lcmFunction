fill ~-1 ~ ~1 ~1 ~ ~-1 minecraft:iron_block
setblock ~ ~1 ~-1 minecraft:stone_slab
setblock ~1 ~1 ~ minecraft:stone_slab
setblock ~ ~1 ~1 minecraft:stone_slab
setblock ~-1 ~1 ~ minecraft:stone_slab
setblock ~ ~1 ~ minecraft:dropper 1

summon minecraft:armor_stand ~ ~ ~ {Marker:1,NoGravity:1,Invisible:1,CustomNameVisible:0,Tags:["ic.icWorkBench","blockfun"]}
tellraw @a[r=10] {"text":"§f[§6方块科技§f] §c工业工作台§7放置完成,您可以站在发射器上抬头拆除该机器!"}

kill @s