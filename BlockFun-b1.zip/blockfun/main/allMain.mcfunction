execute @a[rx=-90,rxm=-90] ~ ~ ~ function blockfun:machine/main1
execute @e[tag=blockfun] ~ ~ ~ function blockfun:particle/machine
function blockfun:synthesis/main/main
execute @e[tag=ic.summon] ~ ~ ~ function blockfun:machine/main