scoreboard players add @e[tag=tick,type=armor_stand] main 1

execute @e[tag=10tick] ~ ~ ~ function blockfun:main/10tick if @s[score_main_min=10,score_main=20]
execute @e[tag=20tick] ~ ~ ~ function blockfun:main/20tick if @s[score_main_min=20,score_main=40]

# Blockfun-byStarXiyu&XiaoXiang
# Power-byLIGHTCOMMAND(LCM-LightCommand)
# Post-byFISHFUNCTION(fishFunction)