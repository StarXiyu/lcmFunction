scoreboard players set @s main 0

execute @a[rx=-90,rxm=-90] ~ ~ ~ function blockfun:machine/main1