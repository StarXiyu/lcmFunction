scoreboard players set @s main 0

execute @e[tag=blockfun] ~ ~ ~ function blockfun:particle/machine