scoreboard players set @s main 0

execute @e[tag=ic.summon] ~ ~ ~ function blockfun:machine/main