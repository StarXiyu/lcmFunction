testforblock ~ ~1 ~ minecraft:dropper -1 {Items:[{id:"minecraft:iron_ingot",Count:1b,Damage:0s,Slot:0b},{id:"minecraft:iron_ingot",Count:1b,Damage:0s,Slot:1b},{id:"minecraft:iron_ingot",Count:1b,Damage:0s,Slot:2b},{id:"minecraft:iron_ingot",Count:1b,Damage:0s,Slot:3b},{id:"minecraft:iron_ingot",Count:1b,Damage:0s,Slot:4b},{id:"minecraft:iron_ingot",Count:1b,Damage:0s,Slot:5b},{id:"minecraft:stick",Count:1b,Damage:0s,Slot:7b}]}
function blockfun:synthesis/icWorkBench/ironHammer if @s[score_blockfun.syn_min=1]

testforblock ~ ~1 ~ minecraft:dropper -1 {Items:[{id:"minecraft:iron_ingot",Count:1b,Damage:0s,Slot:1b},{id:"minecraft:iron_pickaxe",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§f铁锤§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e工具","§8* §7用法 §c将矿物等物品液压"]},Unbreakable:1b},Slot:4b}]}
function blockfun:synthesis/icWorkBench/ironPanel if @s[score_blockfun.syn_min=1]

testforblock ~ ~1 ~ minecraft:dropper -1 {Items:[{id:"minecraft:gold_ingot",Count:1b,Damage:0s,Slot:1b},{id:"minecraft:iron_pickaxe",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§f铁锤§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e工具","§8* §7用法 §c将矿物等物品液压"]},Unbreakable:1b},Slot:4b}]}
function blockfun:synthesis/icWorkBench/goldPanel if @s[score_blockfun.syn_min=1]

testforblock ~ ~1 ~ minecraft:dropper -1 {Items:[{id:"minecraft:diamond",Count:1b,Damage:0s,Slot:1b},{id:"minecraft:iron_pickaxe",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§f铁锤§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e工具","§8* §7用法 §c将矿物等物品液压"]},Unbreakable:1b},Slot:4b}]}
function blockfun:synthesis/icWorkBench/diamondPanel if @s[score_blockfun.syn_min=1]

testforblock ~ ~1 ~ minecraft:dropper -1 {Items:[{id:"minecraft:dye",Count:1b,Damage:4s,Slot:1b},{id:"minecraft:iron_pickaxe",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§f铁锤§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e工具","§8* §7用法 §c将矿物等物品液压"]},Unbreakable:1b},Slot:4b}]}
function blockfun:synthesis/icWorkBench/lapisPanel if @s[score_blockfun.syn_min=1]

testforblock ~ ~1 ~ minecraft:dropper -1 {Items:[{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:0b},{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:1b},{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:2b},{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:3b},{id:"minecraft:furnace",Count:1b,Damage:0s,Slot:4b},{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:5b},{id:"minecraft:iron_block",Count:1b,Damage:0s,Slot:6b},{id:"minecraft:iron_block",Count:1b,Damage:0s,Slot:7b},{id:"minecraft:iron_block",Count:1b,Damage:0s,Slot:8b}]}
function blockfun:synthesis/icWorkBench/steamPower if @s[score_blockfun.syn_min=1]

testforblock ~ ~1 ~ minecraft:dropper -1 {Items:[{id:"minecraft:stone_button",Count:1b,Damage:0s,Slot:1b},{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:3b},{id:"minecraft:redstone",Count:1b,Damage:0s,Slot:4b},{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:5b},{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:6b},{id:"minecraft:redstone",Count:1b,Damage:0s,Slot:7b},{id:"minecraft:stained_glass_pane",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§e粗制铁板§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:8b}]}
function blockfun:synthesis/icWorkBench/battery if @s[score_blockfun.syn_min=1]

testforblock ~ ~1 ~ minecraft:dropper -1 {Items:[{id:"minecraft:stained_glass",Count:1b,Damage:14s,tag:{display:{Name:"§c§l<!> §e请等待10秒后自动变为电池,期间请勿取出!"}},Slot:4b}]}
function blockfun:synthesis/icWorkBench/battery1 if @s[score_blockfun.syn_min=1]