testforblock ~ ~ ~ minecraft:furnace -1 {Items:[{id:"minecraft:dye",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§b初级电池§c(需充电)§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:0b},{id:"minecraft:coal",Count:1b,Damage:0s,Slot:1b}]}
function blockfun:synthesis/steamPower/battery if @s[score_blockfun.syn_min=1]

testforblock ~ ~ ~ minecraft:furnace -1 {Items:[{id:"minecraft:stained_glass_pane",Count:1b,Damage:14s,tag:{display:{Name:"§c§l §e等待15秒后自动充电完成,期间请勿拿出"}},Slot:2b}]}
function blockfun:synthesis/steamPower/battery1 if @s[score_blockfun.syn_min=1]