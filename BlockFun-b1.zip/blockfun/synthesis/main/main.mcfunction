execute @e[tag=blockfun] ~ ~ ~ function blockfun:synthesis/main/stats

execute @e[tag=ic.icWorkBench] ~ ~ ~ function blockfun:synthesis/main/icWorkBench
execute @e[tag=ic.steamPower] ~ ~ ~ function blockfun:synthesis/main/steamPower

execute @e[score_blockfun.syn_min=1] ~ ~ ~ function blockfun:synthesis/main/restats