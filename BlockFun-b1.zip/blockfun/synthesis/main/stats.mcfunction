scoreboard players add @s blockfun.syn 0

stats entity @s set AffectedBlocks @s blockfun.syn