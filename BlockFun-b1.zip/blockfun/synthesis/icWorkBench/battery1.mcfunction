scoreboard players add @s blockfun.time.2 1
scoreboard players set @s blockfun.syn 0

execute @s[score_blockfun.time.2_min=10] ~ ~ ~ blockdata ~ ~1 ~ {Items:[{id:"minecraft:dye",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§b初级电池§c(需充电)§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]}},Slot:4b}]}
execute @s[score_blockfun.time.2_min=10] ~ ~ ~ scoreboard players set @s blockfun.time.2 0