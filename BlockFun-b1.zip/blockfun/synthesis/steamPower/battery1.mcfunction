scoreboard players set @s blockfun.syn 0
scoreboard players add @s blockfun.time.2 1

execute @s[score_blockfun.time.2_min=15] ~ ~ ~ blockdata ~ ~ ~ {Items:[{id:"minecraft:dye",Count:1b,Damage:0s,tag:{display:{Name:"§6<--§7[§b初级电池§c(满电)§7]§6-->",Lore:["§a >-------------------<","§8* §7类型 §e材料"]},HideFlags:1,ench:[{id:70s,lvl:1s}]},Slot:2b}]}
execute @s[score_blockfun.time.2_min=15] ~ ~ ~ scoreboard players set @s blockfun.time.2 0