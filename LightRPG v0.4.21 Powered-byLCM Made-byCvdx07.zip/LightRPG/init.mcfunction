
## 储存
	scoreboard objectives add damage dummy 伤害
	scoreboard objectives add armor dummy 护盾
	scoreboard objectives add health dummy 生命
	scoreboard objectives add maxhealth dummy 最大生命
	scoreboard objectives add crit.pob dummy 暴击概率
	scoreboard objectives add crit.armor dummy 暴击抵抗
	scoreboard objectives add crit.damage dummy 暴击伤害
	scoreboard objectives add extra.drop dummy 额外掉落概率
	scoreboard objectives add drop dummy 掉落概率
	scoreboard objectives add money dummy 金币
	scoreboard objectives add get.money dummy 金币奖励

## 运算
	scoreboard objectives add damage.math dummy
	scoreboard objectives add armor.math dummy 怪物现有护盾
	scoreboard objectives add armorMath1 dummy 怪物护盾计算1
	scoreboard objectives add health.math dummy
	scoreboard objectives add healthmax.math dummy
	scoreboard objectives add maxhealth.math dummy
	scoreboard objectives add crit.math dummy
	scoreboard objectives add drop.math dummy
	scoreboard objectives add healthMath dummy 怪物死亡前伤害
	
## 判定 
	scoreboard objectives add leave stat.leaveGame
	scoreboard objectives add die deathCount
	scoreboard objectives add damage1 stat.damageDealt
	##scoreboard objectives add hurt stat.damageTaken
	##scoreboard objectives add hurtuid dummy
	scoreboard objectives add max dummy
	scoreboard objectives add min dummy
	scoreboard objectives add armor.time dummy
	scoreboard objectives add roll dummy
	scoreboard objectives add math dummy
	scoreboard objectives add LightRPG.tr trigger
	scoreboard players set seedA math 1839654598
	scoreboard players set seedB math -1963624475
	scoreboard players set seedC math -1267732239
	scoreboard players set seedD math 1963199636
	scoreboard objectives add onlinetime stat.playOneMinute

tellraw @a [{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTRPG-MATH","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n执行:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"初始化模块","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n作者:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"夕羽","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n㪊:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"245684797","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTRPG-MATH","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
playsound block.note.pling block @p

scoreboard objectives add main dummy
scoreboard players set 100 math 100

summon minecraft:armor_stand ~ ~ ~1 {CustomName:"3s",Tags:["3s","main"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
summon minecraft:armor_stand ~ ~ ~2 {CustomName:"10tick",Tags:["10tick"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
summon minecraft:armor_stand ~ ~ ~3 {CustomName:"20tick",Tags:["20tick"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
summon minecraft:armor_stand ~ ~ ~4 {CustomName:"5tick",Tags:["5tick"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}