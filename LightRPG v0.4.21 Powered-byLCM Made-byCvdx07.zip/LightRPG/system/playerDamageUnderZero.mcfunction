scoreboard players set @s damage.math 0
scoreboard players operation @s armor.math -= @e[c=1,tag=mob,r=5] damage

scoreboard players set @s[score_armor.math=-1] armor.math 0