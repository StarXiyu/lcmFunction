scoreboard players tag @e[tag=mob,r=10] add LightRPG.temp.mob.hurt {HurtTime:9s}
scoreboard players tag @s add LightRPG.system.temp.damage

execute @e[tag=LightRPG.temp.mob.hurt] ~ ~ ~ function LightRPG:system/mobHurt

advancement revoke @s only LightRPG:LightRPG_mobHurt