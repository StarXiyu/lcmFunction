scoreboard players operation @s damage.math = @e[tag=zombie1,c=1] damage
function LightRPG:system/playerHurt

advancement revoke @s only LightRPG:LightRPG_playerHurt01