scoreboard players operation @s damage.math = @p[score_damage1_min=0] damage
function LightRPG:system/playerHurt

scoreboard players reset @a damage1

advancement revoke @s only LightRPG:LightRPG_playerHurt02