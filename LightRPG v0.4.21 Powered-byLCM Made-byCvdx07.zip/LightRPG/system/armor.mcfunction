scoreboard players add @s armor.time 3

execute @s[score_armor.time_min=80] ~ ~ ~ execute @e[tag=mob] ~ ~ ~ scoreboard players operation @s armor.math = @s armor
execute @s[score_armor.time_min=80] ~ ~ ~ execute @a ~ ~ ~ scoreboard players operation @s armor.math = @s armor
execute @s[score_armor.time_min=80] ~ ~ ~ scoreboard players set @s armor.time 0