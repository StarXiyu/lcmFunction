
## [01] 击杀反馈
	particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a 152
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 2 1

## [02] 赋值
	scoreboard players operation @s health.math = @s health

## [03] 计算
	
	#{
	## [01] 将玩家的 %damage% 赋值给 %damage.math%
	scoreboard players operation @a[tag=LightRPG.system.temp.damage] damage.math = @a[tag=LightRPG.system.temp.damage] damage
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ execute @s[tag=LightRPG.system.debug.tellrawOpen] ~ ~ ~ 
	
	## [02] 暴击运算
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ function LightRPG:system/crit/main
	
	## [03] 如果怪物的护盾小于等于玩家的攻击则怪物护盾抵消玩家攻击,如玩家攻击扔有余则扣除怪物血量
		
		## 将自己的护盾赋值
		scoreboard players operation @s armorMath1 = @s armor.math
		
		## 自己的护盾减去玩家的攻击
		scoreboard players operation @s armorMath1 -= @a[tag=LightRPG.system.temp.damage] damage.math
		
		## 如果赋值护盾等于0 清空自己的护盾和玩家的攻击
		execute @s[score_armorMath1=0] ~ ~ ~ scoreboard players set @s armor.math 0
		execute @s[score_armorMath1=0,score_armorMath1_min=0] ~ ~ ~ scoreboard players set @a[tag=LightRPG.system.temp.damage] damage.math 0 
		
		## 如果赋值的护盾小于0,将超出的部分设置为玩家的攻击
		function LightRPG:system/armorMath_UnderZero if @s[score_armorMath1=-1]

	## [04] 若自己的护盾大于等于 1 则将玩家的 %damage.math% 减去自己的 %armor.math%
	execute @s[score_armor.math_min=1] ~ ~ ~ scoreboard players operation @a[tag=LightRPG.system.temp.damage] damage.math -= @s armor.math
	
	## [05] 若玩家的 %damage.math% 低于 0 则进入方法 LightRPG:system/damageUnderZero
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ execute @s[score_damage.math=-1] ~ ~ ~ function LightRPG:system/damageUnderZero
	
	## [06] 伤害最终输出运算
	scoreboard players operation @s healthMath = @s health
	scoreboard players operation @s health -= @a[tag=LightRPG.system.temp.damage] damage.math
	execute @s[score_health=-1] ~ ~ ~ scoreboard players operation @a[tag=LightRPG.system.temp.damage] damage.math = @s healthMath
	scoreboard players set @s[score_health=-1] health 0
	#}
	
## [04] 伤害数显
	title @a[tag=LightRPG.system.temp.damage] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"⚔","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	execute @a[tag=LightRPG.system.temp.damage] ~ ~ ~ title @s[tag=LightRPG.system.temp.crit] title [{"text":">","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"> ","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"☣","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" <","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"<","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	title @a[tag=LightRPG.system.temp.damage] subtitle [{"score":{"objective":"damage.math","name":"@a[tag=LightRPG.system.temp.damage]"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" / ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
	
## [05] 怪物死亡
	function LightRPG:system/mobDie/main unless @s[score_health_min=1]

## [06] 重置
	scoreboard players reset @a[tag=LightRPG.system.temp.damage] damge.math
	##scoreboard players set @s hurtuid 0
	scoreboard players set @s health.math 0
	scoreboard players set @s armorMath1 0
	scoreboard players set @s healthMath 0
	scoreboard players tag @s remove LightRPG.temp.mob.hurt
	scoreboard players tag @a remove LightRPG.system.temp.damage
	scoreboard players tag @a remove LightRPG.system.temp.crit