
execute @s[tag=system.temp.allow.drop] ~ ~ ~ give @p[tag=LightRPG.system.temp.damage,r=10] minecraft:leather 1 0 {display:{Name:"§6腐恶之心",Lore:["§8* §f类型 §e材料","§8* §f出处 §7[Lv.1] §e腐恶丧尸"]},HideFlags:1,ench:[{id:70s,lvl:1s}]} 
execute @s[tag=system.temp.allow.drop] ~ ~ ~ tellraw @p[tag=LightRPG.system.temp.damage,r=10] [{"text":"[","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"获得物品","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 腐恶之心","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

execute @p[tag=LightRPG.system.temp.damage,r=10] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 1 1

scoreboard players set @p[tag=LightRPG.system.temp.damage,r=10] get.money 20