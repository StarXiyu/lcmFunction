# 调用者:攻击者

scoreboard players set @s max 1000
scoreboard players set @s min 1
function LightRPG:random/main

scoreboard players operation @e[tag=LightRPG.temp.mob.hurt] drop.math += @s extra.drop
scoreboard players operation @e[tag=LightRPG.temp.mob.hurt] drop.math += @e[tag=LightRPG.temp.mob.hurt] drop
scoreboard players operation @e[tag=LightRPG.temp.mob.hurt] drop.math -= @s roll

scoreboard players tag @e[tag=LightRPG.temp.mob.hurt,score_drop.math_min=0] add system.temp.allow.drop

scoreboard players reset @e[tag=LightRPG.temp.mob.hurt] drop.math