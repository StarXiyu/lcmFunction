scoreboard players set @p[tag=LightRPG.system.temp.damage,r=10] get.money 0

execute @p[tag=LightRPG.system.temp.damage,r=10] ~ ~ ~ function LightRPG:system/mobDie/drop

function LightRPG:system/mobDie/zombie1 if @s[tag=zombie1]

execute @p[tag=LightRPG.system.temp.damage,r=10] ~ ~ ~ function LightRPG:system/mobDie/reward

kill @s