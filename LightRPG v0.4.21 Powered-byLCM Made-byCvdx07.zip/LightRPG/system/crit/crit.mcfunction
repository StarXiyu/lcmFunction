scoreboard players set 100 math 100

## 伤害 * 150% = 伤害 * 150 / 100

scoreboard players tag @s add LightRPG.system.temp.crit
scoreboard players operation @s damage.math *= @s crit.damage
scoreboard players operation @s damage.math /= 100 math