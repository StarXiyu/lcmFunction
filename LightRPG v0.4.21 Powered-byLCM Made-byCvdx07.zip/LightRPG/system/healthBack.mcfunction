scoreboard players operation @s maxhealth.math = @s maxhealth
scoreboard players operation @s healthmax.math = @s health
scoreboard players operation @s maxhealth.math -= @s healthmax.math


scoreboard players add @s[score_maxhealth.math_min=1] health 1



scoreboard players set @s healthmax.math 0
scoreboard players set @s maxhealth.math 0