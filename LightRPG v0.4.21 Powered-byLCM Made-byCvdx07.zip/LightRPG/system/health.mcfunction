scoreboard players tag @s remove sh2
scoreboard players operation @s health = @s maxhealth
scoreboard players set @s die 0