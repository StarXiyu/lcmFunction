# 本方法适用于设置默认范围 %1-100%
	# 玩家未设置范围时即触发本函数
	scoreboard players set @s max 100
	scoreboard players set @s min 1