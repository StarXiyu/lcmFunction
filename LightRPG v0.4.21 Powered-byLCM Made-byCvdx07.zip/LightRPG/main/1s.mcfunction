scoreboard players add @a die 0

execute @a ~ ~ ~ function LightRPG:system/health if @s[score_die_min=1]