scoreboard players set @s main 0

execute @a ~ ~ ~ function LightRPG:system/math if @s[tag=!math]

execute @a ~ ~ ~ function LightRPG:system/healthback

execute @e[tag=3s] ~ ~ ~ function LightRPG:system/armor