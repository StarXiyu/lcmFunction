summon minecraft:zombie ~ ~1 ~ {CustomName:"§7[DEMO] §c僵尸1",Tags:["mob","zombie1"],CustomNameVisible:1b,Health:99999,DeathLootTable:"entities/empty",Attributes:[{Name:"generic.maxHealth",Base:99999},{Name:"generic.armor",Base:9999},{Name:"generic.armorToughness",Base:9999}]}

execute @e[tag=zombie1] ~ ~ ~ function LightRPG:system/mobMath/zombie1 if @s[tag=!LightRPG.system.mobMath]

tellraw @a " "
tellraw @a "§6§lLIGHTRPG_Infor §8>> §7[DEMO] §c僵尸1 §f召唤成功"
tellraw @a "§f----------------------------------------------------"
tellraw @a "§fHealth §e80"
tellraw @a "§fMaxHealth §e80"
tellraw @a "§fDamage §e3"
tellraw @a "§fArmor §e20"
tellraw @a "§fCrit.armor §e50 §7(50%)"
tellraw @a "§fDrop §e1000 §7(100%)"
tellraw @a " "