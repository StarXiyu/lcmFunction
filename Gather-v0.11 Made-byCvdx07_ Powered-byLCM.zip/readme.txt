
LIGHTCOMMAND MCFUNCTION RELEASE INFROMATION
 - Dev Cvdx07_
 - Release LIGHTCOMMAND
 - QQGroup 228229419
 - Function Gather
 - Version beta0.11

[0] 欢迎使用 LIGHTCOMMAND-Gather-System 这是一个完全免费的系统
[1] 这是一个完整的函数功能包,如果您不知道函数如何使用,还请学习后再来使用本系统
[2] 本函数可实现玩家大召唤术功能
[3] 函数初始化命令 function gather:init
[4] 函数默认执行频率 1tick 如需修改执行频率,请在 gather:condition/pcountEnough 中修改 1200 为其他数值
[5] 函数主包 gather 文件夹请放置于 functions 文件夹第一层