
scoreboard players set @s gather.left 0

scoreboard players tag @s remove temp.gather.nowApplying
scoreboard players set @s[tag=temp.gather.starter] gather.deal 0

scoreboard players tag @s remove temp.gather.starter