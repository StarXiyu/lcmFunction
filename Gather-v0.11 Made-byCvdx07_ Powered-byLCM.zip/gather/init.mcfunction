
scoreboard objectives add gather.pcount dummy
scoreboard objectives add gather trigger
scoreboard objectives add gather.deal dummy
scoreboard objectives add gather.time dummy

scoreboard objectives add gather.left stat.leaveGame

summon minecraft:armor_stand ~ ~1 ~ {CustomName:"§fgather.armor §e此盔甲架用于调用函数,请勿切除!",Tags:["gather.armor"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}