
function gather:condition/accept if @s[score_gather.ad_min=1,score_gather.ad=1]
function gather:condition/deny if @s[score_gather.ad_min=2,score_gather.ad=2]