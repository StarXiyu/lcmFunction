
scoreboard players reset @e[tag=gather.armor,type=armor_stand] gather.pcount
execute @a ~ ~ ~ scoreboard players add @e[tag=gather.armor,type=armor_stand] gather.pcount 1

function gather:condition/pcountNotEnough unless @e[tag=gather.armor,type=armor_stand,score_gather.pcount_min=2]
function gather:condition/pcountEnough if @e[tag=gather.armor,type=armor_stand,score_gather.pcount_min=2]