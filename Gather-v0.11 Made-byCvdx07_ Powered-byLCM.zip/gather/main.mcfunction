
## 检测是否有人发起
scoreboard players enable @a gather
execute @p[score_gather_min=1] ~ ~ ~ function gather:start

## 检测是否有人申请
execute @p[score_gather.apply_min=1,tag=!temp.gather.starter] ~ ~ ~ function gather:apply if @a[tag=temp.gather.starter,score_gather.deal_min=0,score_gather.deal=0]

## 检测是否有同意申请
execute @p[score_gather.ad_min=1,tag=temp.gather.starter] ~ ~ ~ function gather:acceptOrDenyMain

## 超时检测
scoreboard players remove @e[tag=gather.armor,score_gather.time_min=1,type=armor_stand] gather.time 1
function gather:timeOut if @e[tag=gather.armor,score_gather.time_min=0,score_gather.time=0,type=armor_stand]

## 玩家离线检测
execute @p[score_gather.left_min=1] ~ ~ ~ function gather:left