
tellraw @s [{"text":"§d『召唤』 §a您已同意来自 "},{"selector":"@a[tag=temp.gather.nowApplying]"},{"text":" §a的传送申请"}]
tellraw @a[tag=temp.gather.nowApplying] [{"text":"§d『召唤』 "},{"selector":"@a[tag=temp.gather.starter]"},{"text":" §a已同意来自您的传送申请"}]

scoreboard players set @s gather.deal 0
scoreboard players set @s gather.ad 0

tp @a[tag=temp.gather.nowApplying] @s
scoreboard players tag @a[tag=temp.gather.nowApplying] remove temp.gather.nowApplying