
scoreboard players tag @s add temp.gather.starter
scoreboard players tag @e[tag=gather.armor] add temp.gather.existGatherApply

scoreboard players set @e[tag=gather.armor] gather.time 1200

tellraw @s "§d『召唤』 §a召唤已成功发送"

tellraw @a[tag=!temp.gather.starter] [{"text":"\n","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 发送了大召唤术,您可以","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" [点击此处]","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger gather.apply set 1"}},{"text":"\n向Ta发送传送申请 有效期60秒\n","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard objectives remove gather.apply
scoreboard objectives add gather.apply trigger
scoreboard players enable @a[tag=!temp.gather.starter] gather.apply

scoreboard players set @s gather.deal 0