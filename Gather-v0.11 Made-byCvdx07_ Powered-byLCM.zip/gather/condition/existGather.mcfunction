
tellraw @p[score_gather_min=1] "§d『召唤』 §7已经有人在使用召唤了,等一等再使用吧!"