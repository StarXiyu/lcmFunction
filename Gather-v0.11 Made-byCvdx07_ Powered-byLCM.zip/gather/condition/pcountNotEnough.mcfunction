
tellraw @p[score_gather_min=1] "§d『召唤』 §7等等..你想召唤谁啊?"