
tellraw @s [{"text":"§d『召唤』 §c您已拒绝来自 "},{"selector":"@a[tag=temp.gather.nowApplying]"},{"text":" §c的传送申请"}]
tellraw @a[tag=temp.gather.nowApplying] [{"text":"§d『召唤』 "},{"selector":"@a[tag=temp.gather.starter]"},{"text":" §c已拒绝来自您的传送申请"}]

scoreboard players set @s gather.deal 0
scoreboard players set @s gather.ad 0

scoreboard players tag @a[tag=temp.gather.nowApplying] remove temp.gather.nowApplying