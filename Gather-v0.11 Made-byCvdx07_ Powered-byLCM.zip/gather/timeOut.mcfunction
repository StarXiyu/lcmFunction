
tellraw @a [{"text":"§d『召唤』 §f来自 "},{"selector":"@a[tag=temp.gather.starter]"},{"text":"§f 的大召唤术传送申请已超时!"}]
function gather:reset