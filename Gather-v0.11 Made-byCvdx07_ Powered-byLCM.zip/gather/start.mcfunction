
## [01] 存在
function gather:condition/existGather if @e[tag=temp.gather.existGatherApply,type=armor_stand]

## [02] 不存在
function gather:startGather unless @e[tag=temp.gather.existGatherApply,type=armor_stand]

scoreboard players set @a[score_gather_min=1] gather 0
