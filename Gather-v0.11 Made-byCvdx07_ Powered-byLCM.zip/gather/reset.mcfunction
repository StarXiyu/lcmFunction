
scoreboard players tag @e[tag=gather.armor,type=armor_stand] remove temp.gather.existGatherApply

scoreboard objectives remove gather.apply
scoreboard objectives remove gather.ad

scoreboard players tag @a remove temp.gather.nowApplying
scoreboard players set @a[tag=temp.gather.starter] gather.deal 0

scoreboard players tag @a remove temp.gather.starter

scoreboard players set @e[tag=gather.armor,type=armor_stand] gather.time -1