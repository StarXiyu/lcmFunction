
scoreboard players set @a[tag=temp.gather.starter] gather.deal 1
scoreboard players set @s gather.apply 0

scoreboard players tag @s add temp.gather.nowApplying

tellraw @s "§d『召唤』 §a申请发送成功"
tellraw @a[tag=temp.gather.starter] [{"text":"\n","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"selector":"@s","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 向你发送了传送申请","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n『同意申请』   ","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger gather.ad set 1"},"hoverEvent":{"action":"show_text","value":"点击以同意传送申请"}},{"text":"『拒绝申请』","color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"clickEvent":{"action":"run_command","value":"/trigger gather.ad set 2"},"hoverEvent":{"action":"show_text","value":"点击以拒绝传送申请"}},{"text":"\n","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

scoreboard objectives remove gather.ad
scoreboard objectives add gather.ad trigger
scoreboard players enable @a[tag=temp.gather.starter] gather.ad