
## 降频模板 [双通道执行-1秒频级AB触发]
# 2025.5.11 byCvdx07

## 主方法
# Loop -> 1tick

## 高频级 2tick/5tick
    scoreboard players add @e[tag=tick,type=armor_stand] main 1
    # 2tick
    function main:2tick if @e[tag=2tick,type=armor_stand,c=1,score_main_min=2,score_main=100]
    # 5tick
    function main:5tick if @e[tag=5tick,type=armor_stand,c=1,score_main_min=5,score_main=100]