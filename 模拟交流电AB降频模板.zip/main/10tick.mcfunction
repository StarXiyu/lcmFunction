
scoreboard players set @e[tag=10tick,type=armor_stand,c=1,score_main_min=10,score_main=100] main 0

scoreboard players add @e[tag=20tick,type=armor_stand,c=1] main 1

## 20tick [A]
function main:A/1s if @e[tag=20tick,score_main=1,score_main_min=1,type=armor_stand,c=1]

## 20tick [B]
function main:B/1s if @e[tag=20tick,score_main=2,score_main_min=2,type=armor_stand,c=1]

## 60tick [3s]
function main:3s if @e[tag=3s,type=armor_stand,c=1,score_main_min=6,score_main=100]

## 100tick [5s]
function main:5s if @e[tag=5s,type=armor_stand,c=1,score_main_min=10,score_main=100]