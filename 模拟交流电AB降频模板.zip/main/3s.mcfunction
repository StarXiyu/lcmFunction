
scoreboard players set @e[tag=3s,type=armor_stand,c=1,score_main_min=6,score_main=100] main 0