
scoreboard players set @e[tag=20tick,type=armor_stand,c=1] main 0

scoreboard players add @e[tag=main,type=armor_stand] main 1