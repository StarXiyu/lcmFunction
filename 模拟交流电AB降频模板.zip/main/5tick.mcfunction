
scoreboard players set @e[tag=5tick,type=armor_stand,c=1,score_main_min=5,score_main=100] main 0

## 10tick
scoreboard players add @e[tag=10tick,type=armor_stand,c=1] main 5
function main:10tick if @e[tag=10tick,type=armor_stand,c=1,score_main_min=10,score_main=100]