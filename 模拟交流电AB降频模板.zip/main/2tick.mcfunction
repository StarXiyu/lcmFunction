
scoreboard players set @e[tag=2tick,type=armor_stand,c=1,score_main_min=2,score_main=100] main 0