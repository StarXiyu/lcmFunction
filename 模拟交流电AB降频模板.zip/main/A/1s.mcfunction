
scoreboard players add @e[tag=main,type=armor_stand] main 1