
scoreboard players set @e[tag=5s,type=armor_stand,c=1,score_main_min=10,score_main=100] main 0