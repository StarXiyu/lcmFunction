scoreboard players tag @s remove sh2
scoreboard players set @s health 20
scoreboard players set @s die 0