# 击杀反馈
particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a 152
execute @p[c=1,score_damage1_min=0] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 2 1

# 赋值
scoreboard players operation @s health.math = @s health
scoreboard players operation @s armor.math = @s armor

# 计算
scoreboard players operation @p[c=1,score_damage1_min=0] damage.math = @p[c=1,score_damage1_min=0] damage
scoreboard players operation @p[c=1,score_damage1_min=0] damage.math -= @s armor.math
execute @p[c=1,score_damage1_min=0] ~ ~ ~ execute @s[score_damage.math_min=-2100000000,score_damage.math=-1] ~ ~ ~ scoreboard players set @s damage.math 0
scoreboard players operation @s health -= @p[c=1,score_damage1_min=0] damage.math

# 伤害数显

title @p[c=1,score_damage1_min=0] title [{"text":"▄    ","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"damage.math","name":"@p[c=1,score_damage1_min=0]"},"color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" / ","color":"aqua","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"objective":"health","name":"@s"},"color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"    ▄","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]

# 怪物死亡
execute @s ~ ~ ~ function LightRPG:system/mobDie/main unless @s[score_health_min=0]

# 重置
scoreboard players reset @p[c=1,score_damage1_min=0] damge.math
scoreboard players reset @p[c=1,score_damage1_min=0] damage1
scoreboard players set @s health.math 0
scoreboard players set @s armor.math 0
scoreboard players tag @s remove sh