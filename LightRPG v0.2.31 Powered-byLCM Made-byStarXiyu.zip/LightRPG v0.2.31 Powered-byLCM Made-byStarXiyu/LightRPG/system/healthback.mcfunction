scoreboard players add @s health 1
scoreboard players set @s time.rpg 0