
scoreboard players operation @s maxhealth.math = @s maxhealth
scoreboard players operation @s healthmax.math = @s health
scoreboard players operation @s maxhealth.math -= @s healthmax.math

scoreboard players remove @s[score_maxhealth.math=-1] health 1

scoreboard players set @s healthmax.math 0
scoreboard players set @s maxhealth.math 0