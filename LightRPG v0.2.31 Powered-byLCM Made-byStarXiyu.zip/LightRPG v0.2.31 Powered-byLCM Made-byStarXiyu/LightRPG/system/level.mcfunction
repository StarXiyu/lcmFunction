scoreboard players remove @s xp 300
scoreboard players add @s level 1
scoreboard players add @s money 100
playsound minecraft:entity.player.levelup ambient @s
tellraw @s [{"text":"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"1","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":true},{"text":"升级","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":true},{"text":"1","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":true}]
tellraw @s [{"text":"-金币+100","color":"aqua","bold":true,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]
tellraw @s [{"text":"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]