# 击杀反馈
particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a 152

# 赋值
scoreboard players operation @s health.math = @s health
scoreboard players operation @s armor.math = @s armor

# 计算
scoreboard players operation @e[c=1,tag=mob,r=8] damage.math = @e[c=1,tag=mob,r=8] damage
scoreboard players operation @e[c=1,tag=mob,r=8] damage.math -= @s armor.math
execute @e[c=1,tag=mob,score_damage.math_min=-210000000,score_damage.math=-1] ~ ~ ~ scoreboard players set @e[c=1,tag=mob,r=8] damage.math 0 
scoreboard players operation @s health -= @e[c=1,tag=mob,r=8] damage.math

# 击杀
kill @s[score_health=0]

# 重置
scoreboard players reset @s armor.math 
scoreboard players reset @s health.math 
scoreboard players reset @e[c=1,tag=mob,r=8] damage.math
scoreboard players reset @s sh