scoreboard players add @s maxhealth 20
scoreboard players add @s health 20
scoreboard players add @s damage 5
scoreboard players add @s crit.damage 2
scoreboard players add @s armor 10
scoreboard players add @s xp 0
scoreboard players add @s level 0
tellraw @s [{"text":"[","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"系统","color":"gold","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"]","color":"white","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" 数值初始化完毕","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
scoreboard players tag @s add math