scoreboard players set @s main 0

execute @a[tag=math] ~ ~ ~ function LightRPG:system/maxhealth if @s[score_die_min=0,score_die=0]