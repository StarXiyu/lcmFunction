scoreboard players set @s main 0

execute @a[score_xp_min=300] ~ ~ ~ function LightRPG:system/level
execute @a[score_经验计算_min=1] ~ ~ ~ function LightRPG:system/xp