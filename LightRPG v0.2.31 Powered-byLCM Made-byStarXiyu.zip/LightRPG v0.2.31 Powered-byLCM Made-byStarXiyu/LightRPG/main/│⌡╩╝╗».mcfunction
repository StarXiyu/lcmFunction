scoreboard objectives add xp dummy
scoreboard objectives add level dummy
scoreboard objectives add damage dummy
scoreboard objectives add armor dummy
scoreboard objectives add health dummy
scoreboard objectives add 计算 dummy
scoreboard objectives add damage.math dummy
scoreboard objectives add armor.math dummy
scoreboard objectives add health.math dummy
scoreboard objectives add healthmax.math dummy
scoreboard objectives add time.rpg dummy
scoreboard objectives add maxhealth dummy
scoreboard objectives add maxhealth.math dummy
scoreboard objectives add 经验计算 level
scoreboard objectives add leave stat.leaveGame
scoreboard objectives add die deathCount
scoreboard objectives add damage1 stat.damageDealt
scoreboard objectives add sh stat.damageTaken
tellraw @a [{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTRPG-MATH","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n执行:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"初始化模块","color":"aqua","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n作者:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"夕羽","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n㪊:","color":"gold","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"245684797","color":"green","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"LIGHTRPG-MATH","color":"yellow","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"======","color":"gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
playsound block.note.pling block @p

function LightRPG:main/scoreboard