scoreboard players add @e[tag=tick,type=armor_stand] main 1

execute @e[tag=10tick] ~ ~ ~ function LightRPG:main/10tick if @s[score_main_min=10,score_main=20]
execute @e[tag=20tick] ~ ~ ~ function LightRPG:main/20tick if @s[score_main_min=20,score_main=40]

effect @e[tag=mob] minecraft:resistance 9999 255 true
effect @a minecraft:regeneration 999 255 true

execute @a[score_sh_min=0] ~ ~ ~ function LightRPG:system/playersh
execute @a[score_damage1_min=0] ~ ~ ~ execute @e[tag=mob,c=1] ~ ~ ~ scoreboard players tag @s add sh {HurtTime:10s}
execute @a[score_damage1_min=0] ~ ~ ~ execute @e[tag=sh] ~ ~ ~  function LightRPG:system/mobsh