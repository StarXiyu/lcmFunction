
scoreboard objectives add antiFlight.step dummy
scoreboard objectives add antiFlight.Y1 dummy
scoreboard objectives add antiFlight.Y2 dummy
scoreboard objectives add antiFlight.stats dummy
scoreboard objectives add antiFlight.count dummy
scoreboard objectives add aF.gameTime stat.playOneMinute

tellraw @a "§f[§6AntiFlight§f] §a§l✔ §r§aLoaded successfully "