
tp @s 0 4 0
scoreboard players add @s antiFlight.count 1
tellraw @s "§e§l[AntiFlight] §8>> §f请保持绿色游戏，请勿使用飞行功能，否则可能会受到§4§l封禁处罚§f，感谢您的理解"
tellraw @a[tag=op] ["§e§l[AntiFlight] §8>> §7事件监听|§f玩家 ",{"selector":"@s"}," §f第 ",{"score":{"objective":"antiFlight.count","name":"@s"},"color":"green","bold":"true"}," §f次触发飞行检测"]

function AntiFlight:isFly/ban if @s[score_antiFlight.count_min=3]