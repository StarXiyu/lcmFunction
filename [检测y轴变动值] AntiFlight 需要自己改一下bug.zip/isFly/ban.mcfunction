
scoreboard players set @s antiFlight.count 0
tellraw @a ["§e§l[AntiFlight] §8>> §f玩家 ",{"selector":"@s"}," §f因触发 §4§l反飞行检测 §f被 §a§l封禁1天"]

scoreboard players tag @s add tempban.ban

scoreboard players set @s tempBanU3 -1
scoreboard players operation @s tempBanT1 = systemTick tempBanT1
scoreboard players add @s tempBanT1 1728000