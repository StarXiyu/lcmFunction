
scoreboard players add @s antiFlight.step 0
function AntiFlight:test/2 if @s[score_antiFlight.step=1]
function AntiFlight:test/1 if @s[score_antiFlight.step=0]