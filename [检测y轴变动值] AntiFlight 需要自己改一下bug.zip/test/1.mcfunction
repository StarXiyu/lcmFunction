
scoreboard players reset @s antiFlight.Y1
scoreboard players set @s antiFlight.step 1

scoreboard players set @s antiFlight.stats 0

stats entity @s set AffectedBlocks @s antiFlight.stats
scoreboard players set @s antiFlight.stats 0
testforblocks ~ 0 ~ ~ ~-1 ~ ~ 0 ~
scoreboard players operation @s antiFlight.Y1 = @s antiFlight.stats

stats entity @s clear AffectedBlocks