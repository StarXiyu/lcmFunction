
scoreboard players reset @s antiFlight.Y2
scoreboard players set @s antiFlight.step 0

scoreboard players set @s antiFlight.stats 0

stats entity @s set AffectedBlocks @s antiFlight.stats
scoreboard players set @s antiFlight.stats 0
testforblocks ~ 0 ~ ~ ~-1 ~ ~ 0 ~
scoreboard players operation @s antiFlight.Y2 = @s antiFlight.stats

stats entity @s clear AffectedBlocks

## 判断高度差
#@param: antiFlight.Y2
#@param: antiFlight.Y1 
scoreboard players operation @s antiFlight.Y2 -= @s antiFlight.Y1
function AntiFlight:isFly/main if @s[score_antiFlight.Y2_min=2]