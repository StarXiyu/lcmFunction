
execute @e[type=player,tag=temp.antiFlight.test] ~ ~ ~ function AntiFlight:test/start