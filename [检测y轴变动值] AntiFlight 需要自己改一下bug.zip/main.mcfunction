
## LCM-AntiCheat-AntiFlight
## byCvdx07_ 2025.11.1

function AntiFlight:playerMain if @p[tag=!antiFlight.whiteList]