
scoreboard players set @a[tag=temp.antiFlight.stop] antiFlight.step 0
scoreboard players reset @a[tag=temp.antiFlight.stop] antiFlight.Y1
scoreboard players reset @a[tag=temp.antiFlight.stop] antiFlight.Y2

scoreboard players tag @a[tag=temp.antiFlight.stop] remove temp.antiFlight.stop