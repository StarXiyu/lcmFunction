
scoreboard players tag @a[tag=!antiFlight.whiteList] add temp.antiFlight.test

scoreboard players tag @a[tag=temp.antiFlight.test] add temp.antiFlight.stop {Inventory:[{Slot:102b,id:"minecraft:elytra"}]}
scoreboard players tag @a[tag=temp.antiFlight.test] add temp.antiFlight.stop {ActiveEffects:[{Id:25b}]}
scoreboard players tag @a[tag=temp.antiFlight.test,score_antiFlight.gameTime=300] add temp.antiFlight.stop
scoreboard players tag @a[tag=temp.antiFlight.test,m=1] add temp.antiFlight.stop

function AntiFlight:test/main if @p[tag=!temp.antiFlight.stop]

function AntiFlight:stopReset if @p[tag=temp.antiFlight.stop]

scoreboard players tag @a[tag=temp.antiFlight.test] remove temp.antiFlight.test