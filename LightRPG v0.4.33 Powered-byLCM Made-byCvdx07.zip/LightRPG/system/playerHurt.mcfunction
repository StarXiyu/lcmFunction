
## [01] 击杀反馈
	particle blockcrack ~ ~ ~ 0.25 0.25 0.25 1 30 normal @a 152
	execute @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] ~ ~ ~ playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 2 1

## [02] 赋值
	scoreboard players operation @s health.math = @s health

## [03] 计算
	
	#{
	## [01] 将玩家的 %damage% 赋值给 %damage.math%
	scoreboard players operation @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage.math = @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage
	
	
	## [03] 如果被攻击玩家的护盾小于等于玩家的攻击则被攻击玩家护盾抵消玩家攻击,如玩家攻击扔有余则扣除被攻击玩家血量
		
		## 将自己的护盾赋值
		scoreboard players operation @s armorMath1 = @s armor.math
		
		## 自己的护盾减去玩家的攻击
		scoreboard players operation @s armorMath1 -= @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage.math
		
		## 如果赋值护盾等于0 清空自己的护盾和玩家的攻击
		execute @s[score_armorMath1=0] ~ ~ ~ scoreboard players set @s armor.math 0
		execute @s[score_armorMath1=0,score_armorMath1_min=0] ~ ~ ~ scoreboard players set @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage.math 0
		
		## 如果赋值的护盾小于0,将超出的部分设置为玩家的攻击
		function LightRPG:system/playerArmorMath_UnderZero_FromMob if @s[score_armorMath1=-1]

	## [04] 若自己的护盾大于等于 1 则将玩家的 %damage.math% 减去自己的 %armor.math%
	execute @s[score_armor.math_min=1] ~ ~ ~ scoreboard players operation @s armor.math -= @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage.math
	execute @s[score_armor.math_min=1] ~ ~ ~ scoreboard players set @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage.math 0
	
	## [05] 若玩家的 %damage.math% 低于 0 则进入方法 LightRPG:system/damageUnderZero
	execute @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] ~ ~ ~ execute @s[score_damage.math=-1] ~ ~ ~ function LightRPG:system/playerDamageUnderZero
	
	## [06] 伤害最终输出运算
	scoreboard players operation @s healthMath = @s health
	scoreboard players operation @s health -= @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage.math
	execute @s[score_health=-1] ~ ~ ~ scoreboard players operation @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage.math = @s healthMath
	scoreboard players set @s[score_health=-1] health 0
	#}
	
## [05] 被攻击玩家死亡
	function LightRPG:system/playerDie_FromMob unless @s[score_health_min=1]

## [06] 重置
	scoreboard players reset @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damge.math
	##scoreboard players set @s hurtuid 0
	scoreboard players set @s health.math 0
	scoreboard players set @s armorMath1 0
	scoreboard players set @s healthMath 0
	scoreboard players tag @s remove LightRPG.temp.playerHurt.fromMob