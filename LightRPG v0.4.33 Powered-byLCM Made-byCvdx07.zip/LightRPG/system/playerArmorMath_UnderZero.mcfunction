
scoreboard players set -1 math -1
scoreboard players operation @s armorMath1 *= -1 math
scoreboard players operation @a[tag=LightRPG.system.temp.attackPlayer] damage.math = @s armorMath1	