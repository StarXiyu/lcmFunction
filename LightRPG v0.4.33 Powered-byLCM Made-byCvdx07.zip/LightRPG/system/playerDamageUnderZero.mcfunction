
## 重置攻击
scoreboard players set @s damage.math 0

## 护盾减去攻击
scoreboard players operation @a[tag=LightRPG.temp.player.hurt,r=8] armor.math -= @s damage

## 护盾负数清零
scoreboard players set @a[tag=LightRPG.temp.player.hurt,r=8,score_armor.math=-1] armor.math 0