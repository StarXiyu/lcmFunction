
scoreboard players set @s max 100
scoreboard players set @s min 1

## 将玩家的暴击概率赋值给怪物的暴击运算
scoreboard players add @s crit.pob 0
scoreboard players operation @a[tag=LightRPG.temp.player.hurt] crit.math = @s crit.pob

## 玩家运行随机数
function LightRPG:random/main

## 玩家返回的随机数结果加上怪物的暴击抵抗
scoreboard players operation @s roll += @a[tag=LightRPG.temp.player.hurt] crit.armor

## 怪物的暴击运算减去玩家的随机数
scoreboard players operation @a[tag=LightRPG.temp.player.hurt] crit.math -= @s roll

## 如果怪物的暴击运算大于0就让玩家执行暴击
function LightRPG:system/playerCrit/crit if @a[tag=LightRPG.temp.player.hurt,score_crit.math_min=0]

scoreboard players reset @s crit.math