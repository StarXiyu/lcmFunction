## 调用者 攻击者

scoreboard players tag @a[r=10] add LightRPG.temp.player.hurt {HurtTime:9s}
scoreboard players tag @s add LightRPG.system.temp.attackPlayer

execute @a[tag=LightRPG.temp.player.hurt] ~ ~ ~ function LightRPG:system/playerAttack

advancement revoke @s only LightRPG:LightRPG_attackPlayer
