scoreboard players tag @e[tag=zombie1] add LightRPG.temp.mob.attackPlayer
scoreboard players tag @s add LightRPG.temp.playerHurt.fromMob
function LightRPG:system/playerHurt

advancement revoke @s only LightRPG:LightRPG_playerHurt01