
scoreboard players set -1 math -1
scoreboard players operation @s armorMath1 *= -1 math
scoreboard players operation @e[tag=LightRPG.temp.mob.attackPlayer,c=1,r=10] damage.math = @s armorMath1	