scoreboard players enable @a tpa
scoreboard players enable @a tda

execute @a[score_tpa_min=1] ~ ~ ~ function tpa:tpa
execute @a[score_tpamin=1,score_tpamin_min=1] ~ ~ ~ execute @s[score_tda_min=1] ~ ~ ~ function tpa:chose/4

function tpa:tpaenable

# 作者 Cvdx07_
# 出品 LIGHTCOMMAND
# 交流群号 228229419
# Tpa Version beta0.7