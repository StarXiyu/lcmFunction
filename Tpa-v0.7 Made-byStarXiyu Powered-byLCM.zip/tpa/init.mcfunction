scoreboard objectives add tpa trigger
scoreboard objectives add tda trigger
scoreboard objectives add tpamin dummy
scoreboard objectives add tpauid dummy
scoreboard objectives add tpa人数检测 dummy
scoreboard objectives add tpa.left dummy

summon minecraft:armor_stand ~ ~1 ~ {CustomName:"tpa.armor §e此盔甲架用于调用系统,切勿清除!",Tags:["tpa.armor"],CustomNameVisible:1b,Invulnerable:1b,PersistenceRequired:1b,ShowArms:1,Rotation:[0f],Pose:{Head:[0f,0f,0f],Body:[0f,0f,0f],LeftArm:[0f,0f,0f],RightArm:[0f,0f,0f],LeftLeg:[0f,0f,0f],RightLeg:[0f,0f,0f]}}
tellraw @a [{"text":"§aTpa初始化完成 §ebyStarXiyu"}]
setblock ~ ~ ~ minecraft:repeating_command_block 0 replace {Command:"function tpa:main",auto:true}