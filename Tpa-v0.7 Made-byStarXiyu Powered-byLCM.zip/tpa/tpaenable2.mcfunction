execute @s[score_tpamin_min=2] ~ ~ ~ scoreboard players remove @e[tag=tpa.armor] tpamin 1

execute @e[tag=tpa.armor] ~ ~ ~ function tpa:time unless @s[score_tpamin_min=0]

scoreboard players add @e[tag=tpa.armor] tpa.left 1