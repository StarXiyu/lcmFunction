scoreboard objectives add tpa.temp.i dummy

execute @e[tag=tpa.armor] ~ ~ ~ scoreboard players add @s tpa.temp.i 1

function tpa:information/1 if @e[score_tpa.temp.i_min=1]
function tpa:information/2 unless @e[score_tpa.temp.i_min=1]

scoreboard objectives remove tpa.temp.i