scoreboard players reset @e[tag=tpa.armor] tpa人数检测
execute @a ~ ~ ~ scoreboard players add @e[tag=tpa.armor] tpa人数检测 1

function tpa:count/pun unless @e[tag=tpa.armor,score_tpa人数检测_min=2]
function tpa:count/penough if @e[tag=tpa.armor,score_tpa人数检测_min=2]

scoreboard players set @s tpa 0