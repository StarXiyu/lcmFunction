scoreboard players reset @e[tag=tpa.armor] tpa.left
execute @a[score_tpamin_min=1] ~ ~ ~ function tpa:tpaenable2

execute @e[tag=tpa.armor,score_tpamin_min=0] ~ ~ ~ function tpa:reset2 unless @s[score_tpa.left_min=2,score_tpa.left=2]