scoreboard players set @a tda 0
execute @a ~ ~ ~ scoreboard players operation @s tpauid = @s uid
scoreboard players operation @a tpauid -= @s tpa
scoreboard players tag @s add 传送者
scoreboard players set @s tpamin 2

function tpa:chose/1