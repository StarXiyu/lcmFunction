tellraw @a[score_tpamin=2,score_tpamin_min=2] [{"text":"§bTpa §8>> §7你的互传请求已§c超时"}]

function tpa:reset