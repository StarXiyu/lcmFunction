tellraw @s [{"text":"§bTpa §8>> §e您搁这原地传送呢?"}]
scoreboard players set @s tpamin 0
scoreboard players tag @s remove 传送者
scoreboard players tag @s remove 被传送者
scoreboard players tag @s remove 传送匹配成功