tp @a[score_tpamin_min=2,score_tpamin=2] @s
tellraw @s [{"text":"§bTpa §8>> §7您已成功§a接受 "},{"selector":"@a[score_tpamin=2,score_tpamin_min=2]","color":"yellow"},{"text":"§7 的传送请求"}]
tellraw @a[score_tpamin=2,score_tpamin_min=2] [{"text":"§bTpa §8>> "},{"selector":"@s","color":"yellow"},{"text":"§7 已§a接受§7你的传送请求"}]

function tpa:reset