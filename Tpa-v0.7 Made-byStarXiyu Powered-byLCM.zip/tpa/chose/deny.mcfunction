tellraw @s [{"text":"§bTpa §8>> §7您已成功§c拒绝 "},{"selector":"@a[score_tpamin=2,score_tpamin_min=2]","color":"yellow"},{"text":"§7 的传送请求"}]
tellraw @a[score_tpamin=2,score_tpamin_min=2] [{"text":"§bTpa §8>> "},{"selector":"@s","color":"yellow"},{"text":"§c 拒绝§7了你的传送请求并向你丢了一只§a夕羽"}]

function tpa:reset