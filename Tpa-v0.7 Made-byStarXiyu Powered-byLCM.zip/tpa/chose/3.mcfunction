tellraw @s [{"text":"§bTpa §8>> §c查无此人!"}]

scoreboard players set @s tpamin 0
scoreboard players tag @s remove 传送者