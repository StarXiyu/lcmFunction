function tpa:chose/deny if @s[score_tda_min=2,score_tda=2]
function tpa:chose/accept if @s[score_tda_min=1,score_tda=1]

scoreboard players set @s tda 0