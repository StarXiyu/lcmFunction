scoreboard players tag @a[score_tpauid=0,score_tpauid_min=0] add 被传送者
scoreboard players set @a[tag=被传送者] tpamin 1
execute @a[tag=被传送者] ~ ~ ~ scoreboard players tag @a[tag=传送者] add 传送匹配成功

function tpa:chose/3 if @s[tag=!传送匹配成功]
function tpa:chose/2 if @s[tag=被传送者]
function tpa:tpa2 if @s[tag=传送匹配成功]