scoreboard players reset @a tpamin
scoreboard players reset @e[tag=tpa.armor]
scoreboard objectives add tpa trigger
scoreboard players reset @a tpauid
tellraw @a [{"text":"§bTpa §8>> §7上一位互传使用者已经§e结束使用§7,现在互传可以§a正常使用"}]