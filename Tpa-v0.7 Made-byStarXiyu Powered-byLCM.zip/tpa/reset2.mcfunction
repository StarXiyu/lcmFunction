tellraw @a [{"text":"§bTpa §8>> §7由于§e多人同时使用互传§7或§c互传任意一方离线§7,互传已被截停!"}]

scoreboard objectives remove tpamin
scoreboard objectives remove tpauid

scoreboard objectives add tpa trigger
scoreboard objectives add tpamin dummy
scoreboard objectives add tpauid dummy

tellraw @a [{"text":"§bTpa §8>> §7上一位互传使用者已经§e结束使用§7,现在互传可以§a正常使用"}]