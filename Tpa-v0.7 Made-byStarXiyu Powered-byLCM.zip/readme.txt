
LIGHTCOMMAND MCFUNCTION RELEASE INFROMATION
 - Dev Cvdx07_
 - Release LIGHTCOMMAND
 - QQGroup 228229419
 - Function Tpa
 - Version beta0.7

[0] 欢迎使用 LIGHTCOMMAND-Tpa-System 这是一个完全免费的系统
[1] 这是一个完整的函数功能包,如果您不知道函数如何使用,还请学习后再来使用本系统
[2] 本函数可实现输入玩家UID申请传送到对方身边 不可多人同时使用
[3] 默认玩家编号计分板 uid
[4] 函数初始化命令 function tpa:init
[5] 函数默认执行频率 1tick 如需修改执行频率,请在 tpa:tpa2 中修改 600 为其他数值
[6] 函数装载信息查询命令 function tpa:information
[7] 函数主包 tpa 文件夹请放置于 functions 文件夹第一层